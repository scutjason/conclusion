//
// Created by 10209409 on 3/14/2017.
//
#include <cub/mem/cache_allocator.hxx>

ns_begin(cub)
ns_begin(mem)

cache_allocator* cache_allocator::_instance = nullptr;
std::mutex       cache_allocator::_instance_mutex;

cache_allocator* cache_allocator::Instance()
{
    if (nullptr == _instance)
    {
        std::lock_guard<std::mutex> lock(_instance_mutex);

        if (nullptr == _instance)
        {
            _instance = new cache_allocator();
        }
    }

    return _instance;
}

bool cache_allocator::init(  unsigned int init_cache_num,
                             unsigned int expand_cache_num,
                             unsigned int max_cache_num )
{
    if ( _inited )
    {
        return false;
    }

    for ( int i = 0; i < MAX_CACHE_POOL_NUM; i++ )
    {
        unsigned int object_size = (i + 1) * 256;
        _cache_pool[i].init(object_size,
                            init_cache_num,
                            expand_cache_num,
                            max_cache_num );
    }

    _inited = true;

    return true;
}

// 申请
unsigned int cache_allocator::alloc( cache_data*& data_list,
                                     size_t data_size,
                                     unsigned int alloc_count,
                                     bool block_flag )
{
    assert( data_size > 0 );
    assert( alloc_count > 0 );

    if ( !_inited )
    {
        init();
    }

    unsigned int pool_index = data_size_to_index( data_size );

    // 对象尺寸过大，直接分配失败
    if ( pool_index >= MAX_CACHE_POOL_NUM)
    {
        return 0;
    }

    int alloced_count = 0;

    // 从内存池中分配
    std::unique_lock<std::mutex> lock(_cache_mutex[pool_index]);

    while ( (nullptr == _cache_pool[pool_index].alloc( data_list,
             alloced_count) ) &&
            block_flag )
    {
        _empty_condition[pool_index].wait(lock);
    }

    return alloced_count;
}


// 释放------->必须是同样大小的对象
unsigned int cache_allocator::free(cache_data*& data_list,
                                   unsigned int free_count)
{
    assert( _inited );

    if (0 == free_count)
    {
        return 0;
    }

    if (!_inited)
    {
        return 0;
    }

    if ( nullptr == data_list )
    {
        return 0;
    }

    unsigned int pool_index = data_size_to_index( data_list->size );

    if ( pool_index >= MAX_CACHE_POOL_NUM)
    {
        return 0;
    }

    std::unique_lock<std::mutex> lock(_cache_mutex[pool_index]);

    unsigned int free_cache_count = _cache_pool[pool_index].free_cache_count();
    _cache_pool[pool_index].free(data_list, free_count);
    data_list = nullptr;

    if ( free_cache_count <= 0 )
    {
        _empty_condition[pool_index].notify_all();
    }

    return free_count;
}
ns_end(mem)
ns_end(cub)