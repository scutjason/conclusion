//
// Created by 10209409 on 3/14/2017.
//
#include <cstddef>
#include <cub/mem/thread_cache_allocator.hxx>

ns_begin(cub)
ns_begin(mem)

thread_local std::shared_ptr<thread_cache_allocator>
thread_cache_allocator::_instance;
std::mutex thread_cache_allocator::_instance_mutex;

// 使用内存池标记
bool g_used_memory_pool = false;

// 根据配置从内存池中申请或从glic中 申请内存
char* cub_alloc( unsigned int size, unsigned int args, bool block_flag)
{
    if ( 0 == size )
    {
        return nullptr;
    }

    char* data = nullptr;

    if (g_used_memory_pool)
    {
        if ( !thread_cache_allocator::Instance()->alloc(data, size, args, block_flag))
        {
            return nullptr;
        }
    }

    else
    {
        data = (char*)malloc(size);
    }

    return data;
}

//  根据配置将内存释放到内存池中或glic中
void cub_free( char* data)
{
    if (nullptr == data)
    {
        return;
    }

    if (g_used_memory_pool)
    {
        thread_cache_allocator::Instance()->free(data);
    }

    else
    {
        free((void*)data);
    }
}

thread_cache_allocator* thread_cache_allocator::Instance()
{
    if (nullptr == _instance.get())
    {
        std::lock_guard<std::mutex> lock(_instance_mutex);

        if (nullptr == _instance.get())
        {
            _instance.reset( new thread_cache_allocator() );
        }
    }

    return _instance.get();
}

thread_cache_allocator::thread_cache_allocator()
    : _max_thread_cache_size(DEFAULT_THREAD_CACHE_SIZE),
      _batch_free_size(DEFAULT_BATCH_FREE_SIZE),
      _batch_alloc_size(DEFAULT_BATCH_ALLOC_SIZE)
{
    for (int i = 0; i < MAX_CACHE_POOL_NUM; i++)
    {
        _cache_count[i] = 0;
        _cache_pool[i]  = nullptr;

    }
}

thread_cache_allocator::~thread_cache_allocator()
{
    for (unsigned int i = 0; i < MAX_CACHE_POOL_NUM; i++)
    {
        if (_cache_count[i] > 0)
        {
            cache_allocator::Instance()->free(_cache_pool[i], _cache_count[i]);
        }
    }
}

// 申请
bool thread_cache_allocator::alloc(char*& data,
                                   unsigned int data_len,
                                   unsigned int args,
                                   bool block_flag)
{
    if (0 == data_len)
    {
        return false;
    }

    data = nullptr;

    unsigned int pool_index = data_size_to_index(data_len);

    // 对象尺寸过大，直接从glibc中分配
    if (pool_index >= MAX_CACHE_POOL_NUM)
    {
        cache_data* cache = nullptr;
        size_t data_size = sizeof(cache_data) + data_len;

        try
        {
            cache = (cache_data*)(new char[data_size]);
        }

        catch (const std::bad_alloc& e)
        {
            return false;
        }

        cache->next       = nullptr;
        cache->size       = data_len;
        cache->magic_data = CACHE_MAGIC;
        data              = cache->data;
        return true;
    }

    // 本地已无缓存，则从全局缓冲池批量获取
    if (nullptr == _cache_pool[pool_index])
    {
        _cache_count[pool_index] += cache_allocator::Instance()->alloc(
                                        _cache_pool[pool_index],
                                        data_len,
                                        _batch_alloc_size,
                                        block_flag );
    }

    if (nullptr == _cache_pool[pool_index])
    {
        return false;
    }

    cache_data* cache_data  = _cache_pool[pool_index];
    assert( CACHE_MAGIC == cache_data->magic_data);
    _cache_pool[pool_index] = _cache_pool[pool_index]->next;
    cache_data->next        = nullptr;
    cache_data->custom_args = args;
    data                    = cache_data->data;
    _cache_count[pool_index]--;

    return true;
}

// 释放
void thread_cache_allocator::free(char* data)
{
    if (nullptr == data)
    {
        return ;
    }

    cache_data* cache       = (cache_data*)(data - offsetof(cache_data, data));
    assert( CACHE_MAGIC == cache->magic_data);
    unsigned int pool_index = data_size_to_index(cache->size);

    if (pool_index >= MAX_CACHE_POOL_NUM)
    {
        delete []((char*)cache);
        return;
    }

    unsigned int custom_args = cache->custom_args;
    cache->next              = _cache_pool[pool_index];
    _cache_pool[pool_index]  = cache;
    _cache_count[pool_index]++;

    // 本地缓存过多，批量释放到全局缓存中
    if (_cache_count[pool_index] >= _max_thread_cache_size)
    {
        _cache_count[pool_index] -= cache_allocator::Instance()->free(
                                        _cache_pool[pool_index],
                                        _cache_count[pool_index]);
    }
}

ns_end(mem)
ns_end(cub)
