//
// Created by 10209409 on 3/23/2017.
//

#ifndef __NET_HXX__
#define __NET_HXX__

#include <cub/base_types.hxx>
#include <cub/base.hxx>
#include <cub/endian.hxx>
#include <iostream>

ns_begin(cub)
template<typename T>
static inline uint16 encode(char *buffer, T value)
{
    uint16 size = sizeof(T);
    char *dest = buffer;

    #ifdef CUB_BIG_ENDIAN
    const char* src = reinterpret_cast< char*>(&value) + sizeof(T) - 1;

    for (uint16 idx = 0; idx < size; idx++, dest++, src--)
    {
        *dest = *src;
    }

    #else
    *(T*) dest = value;
    #endif
    return size;
}

template<typename T>
static inline uint16 decode(const char *buffer, T &value)
{
    uint16 size = sizeof(T);
    const char *src = buffer;
    #ifdef CUB_BIG_ENDIAN
    char* dest = reinterpret_cast<char*>(&value) + sizeof(T) - 1;

    for (uint16 idx = 0; idx < size; idx++, dest--, src++)
    {
        *dest = *src;
    }

    #else
    value = *(T*) src;

    return size;
    #endif
}

static inline uint16 encode_string(char *buffer, const std::string &value)
{
    char *dest = buffer;
    uint16 length = static_cast<uint16>(value.length());
    dest += encode(buffer, length);
    memcpy(reinterpret_cast<void *>(dest),
           reinterpret_cast<const void *>(value.c_str()),
           value.length());

    return sizeof(length) + length;
}

static inline uint16 decode_string(const char *buffer, std::string &value)
{
    const char *src = buffer;
    uint16 length;
    decode(buffer, length);
    value = std::string(buffer + sizeof(length), length);
    return sizeof(length) + length;
}
ns_end(cub)
#endif /* __NET_HXX__ */
