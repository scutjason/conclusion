//
// Created by 10209409 on 2/9/2017.
//

#ifndef __OS_UTILS_H__
#define __OS_UTILS_H__

#include <string>
#include <cstring>
#include <vector>
#include <cctype>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <cub/base.hxx>

const char   path_sep      = '/';
const size_t max_path_len  = 256;
const int    HEX           =  16;

ns_begin(cub)

// parse pathname components, equivalent to linux basename command

static  std::string basename(const std::string &path)
{
    size_t pos = path.find_last_of("\\/");

    if (pos == std::string::npos)
    {
        return path;
    }

    else
    {
        return path.substr(pos + 1);
    }
}

// parse current executable directory, equivalent to linux pwd command
static inline std::string get_exec_path()
{
    char      exec_path[max_path_len] = {0};
    char *    tail;
    ssize_t   buff_size;

    /* */
    buff_size = readlink("/proc/self/exe", exec_path, max_path_len);

    if (buff_size != -1)
    {
        exec_path[buff_size] = 0;

        tail = strrchr(exec_path, path_sep);

        if (tail != NULL)
        {
            *tail = 0;
        }

        return std::string(exec_path);
    }

    #ifdef __CYGWIN__
    return std::string(getcwd(exec_path, max_path_len));
    #else
    return std::string(get_current_dir_name());
    #endif
}

static inline std::string read_link(std::string& path)
{
    char      link_path[max_path_len] = {0};
    ssize_t   buff_size;

    buff_size = readlink(path.c_str(), link_path, max_path_len);

    if (buff_size != -1)
    {
        return std::string(link_path);
    }

    return std::string("");
}


static bool mkdir(const ::std::string& dirpath)
{
    std::vector<std::string> subdirs;
    std::vector<std::string>::const_iterator iter;
    std::string dir;

    if (dirpath.at(0) == '/')
    {
        dir = "/";
    }

    int pos = dirpath.find_first_not_of("\\/");
    int next = 0;

    while (pos != ::std::string::npos)
    {
        next = dirpath.find_first_of("\\/", pos);
        std::string tmp = dirpath.substr(pos, next - pos);
        subdirs.push_back(tmp);
        pos = dirpath.find_first_not_of("\\/", next);
    }

    for ( iter = subdirs.begin(); iter != subdirs.end(); iter++ )
    {
        if (*iter == "")
        {
            continue;
        }

        if (dir == "")
        {
            dir = *iter;
        }

        else
        {
            dir = dir + "/" + *iter;
        }

        if (dir == "")
        {
            continue;
        }

        struct stat st;

        if (::lstat(dir.c_str(), &st) != 0 )
        {
            const int ret = ::mkdir(dir.c_str(),
                                    S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP);

            if ( ret != 0 )
            {
                return false;
            }
        }
    }

    return true;
}

inline size_t hash(const std::string& data)
{
    size_t h = 0, idx = 0, length = data.length();

    while (idx < length)
    {
        h = h * 0xf4243 ^ data.at(idx);
        idx++;
    }

    return h;
}


inline size_t hash(const char* data, size_t length)
{
    size_t h = 0, idx = 0;
    const char * p = data;

    while (idx < length)
    {
        h = h * 0xf4243 ^ *p++;
        idx++;
    }

    return h;
}

static bool hex2bytes(char * dest, const std::string& hex, size_t length)
{

    if (hex.length() != (2 * length))
    {
        return false;
    };

    for (auto chr : hex)
    {
        if (!isxdigit(chr))
        {
            return false;
        }
    }

    for (size_t i = 0; i < length; i++)
    {
        std::string byteString = hex.substr(2 * i, 2);
        dest[i] = static_cast<char>(strtol(byteString.c_str(), NULL, HEX));
    }

    return true;
}
/*
 * Like read(2) but make sure 'count' is read before to return
* (unless error or EOF condition is encountered)
*/
static int block_read(int fd, char* buf, int count, int& read_count)
{
    read_count = 0;

    while (read_count != count)
    {
        int read_bytes = read(fd, buf, count - read_count);

        if (read_bytes == 0)
        {
            errno = 0;
            return 0;
        }

        if (read_bytes == -1)
        {
            if (errno == EAGAIN)
            {
                return read_count;
            }

            return -1;
        }

        read_count += read_bytes;
        buf += read_bytes;
    }

    return read_count;
}
const int mod_adler = 65521;

/*
 * where data is the location of the data in physical memory
 * and length is the length of the data in bytes
 */
static inline unsigned int adler32(char *data, size_t len)
{
    unsigned int a = 1, b = 0;
    size_t index;

    /* Process each byte of the data in order */
    for (index = 0; index < len; ++index)
    {
        a = (a + data[index]) % mod_adler;
        b = (b + a) % mod_adler;
    }

    return (b << 16) | a;
}

static inline std::string dirname(const std::string &path)
{
    size_t pos = path.find_last_of("\\/");

    if (pos == std::string::npos)
    {
        return path;
    }

    else
    {
        return path.substr(0, pos);
    }
}

static inline bool directory_exists(const std::string & path)
{
    DIR* dir = opendir(path.c_str());

    if (dir)
    {
        /* Directory exists. */
        closedir(dir);
        return true;
    }

    else if (ENOENT == errno)
    {
        /* Directory does not exist. */
        return false;
    }

    else
    {
        /* opendir() failed for some other reason. */
        return true;
    }
}
ns_end(cub)
#endif /* __OS_UTILS_H__ */
