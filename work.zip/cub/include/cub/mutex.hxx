#ifndef __MUTEX_HXX__
#define __MUTEX_HXX__
#include <mutex>

#include <cub/base.hxx>
ns_begin(cub)
typedef std::unique_lock<std::mutex> scoped_lock;
ns_end(cub)
#endif