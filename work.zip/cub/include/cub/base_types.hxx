//
// Created by 10209409 on 3/14/2017.
//
#ifndef __BASE_TYPE_HXX__
#define __BASE_TYPE_HXX__

#include <cstdint>

#ifdef _MSC_VER
typedef unsigned __int8    byte;
typedef          __int8    int8;
typedef         __int16   int16;
typedef         __int32   int32;
typedef         __int64   int64;

typedef unsigned __int8   uint8;
typedef unsigned __int16 uint16;
typedef unsigned __int32 uint32;
typedef unsigned __int64 uint64;
#else
typedef unsigned char      byte;
typedef        int8_t      int8;
typedef       int16_t     int16;
typedef       int32_t     int32;
typedef       int64_t     int64;

typedef       uint8_t     uint8;
typedef      uint16_t    uint16;
typedef      uint32_t    uint32;
typedef      uint64_t    uint64;
#endif

const uint64  builtin_uint64  = 0xffffffffffffffff;
const uint32  builtin_uint32  = 0xffffffff;
const uint16  builtin_uint16  = 0xffff;
const uint8   builtin_uint8   = 0xff;

#define  CUB_SEND_TO_BUF        3
#define  CUB_SEND_PART          2
#define  CUB_READ_PART          1
#define  CUB_OK                 0
#define  CUB_ERROR             -1
#define  CUB_BUF_FULLED        -2
#define  CUB_TIMEOUT           -3
#define  CUB_PORT_USED         -4
#define  CUB_NOT_RUNNING       -5
#define  CUB_MSG_TOO_BIG       -6

#endif /* __BASE_TYPE_HXX__ */
