//
// Created by 10209409 on 3/17/2017.
//

#ifndef __STRING_UTILS_HXX__
#define __STRING_UTILS_HXX__

#include <iomanip>
#include <sstream>
#include <iosfwd>
#include <iostream>
#include <cub/base.hxx>

ns_begin(cub)
static inline void hex_dump(std::stringstream &out, const char* data,
                            size_t len, bool new_line = false)
{
    const char * p = data;
    unsigned int i;

    for (i = 0; i < len; i++)
    {
        out << std::setfill('0') << std::setw(2) << std::hex << (unsigned int)(
                unsigned char)p[i] << " ";

        if (new_line && (i % 16 == 15 || (i == len - 1)))
        {
            out << std::endl;
        }
    }
}

static std::string hex_dump(const char* data, size_t len)
{
    std::stringstream out;
    hex_dump(out, data, len);
    return out.str();
}

static std::string hex_dump(const char* data)
{
    return hex_dump(data, strlen(data));
}
ns_end(cub)
#endif /* __STRING_UTILS_HXX__ */
