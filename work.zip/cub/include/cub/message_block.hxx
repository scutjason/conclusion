//
// Created by 10209409 on 3/14/2017.
//

#ifndef __MESSAGE_BLOCK_HXX__
#define __MESSAGE_BLOCK_HXX__

#include <new>
#include <assert.h>
#include <cstdlib>
#include <cstring>
#include <cub/mem/thread_cache_allocator.hxx>
#include <cub/base_types.hxx>

ns_begin(cub)

class message_block: public noncopyable
{
public:
    message_block() : _data(nullptr), _size(0), _read_ptr(0),
        _write_ptr(0), _tag_ptr(0), _use_memory_pool( false ), _data_count(0)
    {
    }

    ~message_block()
    {
        if (_data != nullptr)
        {
            if (_use_memory_pool)
            {
                mem::cub_free(_data);
            }

            else
            {
                free(_data);
            }

            _data = nullptr;
        }
    }

    int init( size_t size, bool use_memory_pool = true)
    {
        assert( size > 0 );

        if (_data != nullptr)
        {
            assert(size == _size);
            _read_ptr   = 0;
            _write_ptr  = 0;
            _tag_ptr    = 0;
            _data_count = 0;
            return CUB_OK;
        }

        if (use_memory_pool)
        {
            _data = mem::cub_alloc(size);
        }

        else
        {
            _data = (char*)malloc(size);
        }

        if ( nullptr == _data )
        {
            return CUB_ERROR;
        }

        _size = size;
        _read_ptr = 0;
        _write_ptr = 0;
        _tag_ptr = 0;
        _data_count = 0;
        _use_memory_pool = use_memory_pool;

        return CUB_OK;
    }

    char* read_ptr() const
    {
        return (_data + _read_ptr);
    }

    void read_ptr(size_t n)
    {
        assert((_read_ptr + n) <= _size);
        _read_ptr += n;
    }

    int copy(const char* buf, size_t n)
    {
        if (space() < n)
        {
            return CUB_ERROR;
        }

        memcpy(_data + _write_ptr, buf, n);
        _write_ptr += n;

        return CUB_OK;
    }

    char* write_ptr() const
    {
        return (_data + _write_ptr);
    }

    void write_ptr(size_t n)
    {
        assert( (_write_ptr + n) <= _size);
        _write_ptr += n;
    }

    void reset()
    {
        _read_ptr   = 0;
        _write_ptr  = 0;
        _tag_ptr    = 0;
        _data_count = 0;
    }

    char* release()
    {
        char* tmp_data_ptr = _data;

        _data       = nullptr;
        _size       = 0;
        _read_ptr   = 0;
        _write_ptr  = 0;
        _tag_ptr    = 0;
        _data_count = 0;

        return tmp_data_ptr;
    }

    int expand_space()
    {
        assert(_size > 0);
        assert(_data != nullptr);

        size_t size = _size * 2;

        char* new_data = nullptr;

        if (_use_memory_pool)
        {
            new_data = mem::cub_alloc(size);
        }

        else
        {
            new_data = (char*)malloc(size);
        }

        if (nullptr == new_data)
        {
            return CUB_ERROR;
        }

        memcpy(new_data, _data, _write_ptr);

        if (_use_memory_pool)
        {
            mem::cub_free(_data);
        }

        else
        {
            free(_data);
        }

        _data = new_data;
        _size = size;

        return CUB_OK;
    }

    // readable size
    inline size_t length() const
    {
        return (_write_ptr - _read_ptr);
    }

    // 是否初始化
    bool inited() const
    {
        return (_data != nullptr);
    }

    // 获取可写空间大小
    size_t space() const
    {
        return (_size - _write_ptr);
    }

    // 检查是否存在可读消息
    bool empty() const
    {
        return (0 == length());
    }

    // 直接获取数据
    char* data()
    {
        return _data;
    }

    // 标签位向后移动
    void tag_ptr(size_t n)
    {
        _tag_ptr += n;
    }

    // 标签位消息长度
    size_t tag_length() const
    {
        return (_write_ptr - _tag_ptr);
    }

    // 碎片整理，将缓冲区后部数据移动到缓冲区头
    void tidy()
    {
        if (0 == _read_ptr)
        {
            return ;
        }

        if (0 == length())
        {
            reset();
            return ;
        }

        size_t move_len = _read_ptr;
        memmove(_data, _data + move_len, length());

        _read_ptr  -= move_len;
        _write_ptr -= move_len;
        _tag_ptr   -= move_len;
    }

    size_t size()
    {
        return _size;
    }

    size_t data_count()
    {
        return _data_count;
    }

    void increment_data_count()
    {
        ++_data_count;
    }

private:
    char*     _data;
    size_t    _size;
    size_t    _read_ptr;
    size_t    _write_ptr;
    size_t    _tag_ptr;          // 标签位
    bool      _use_memory_pool;
    size_t    _data_count;       // 数据块个数

};

ns_end(cub)
#endif /* __MESSAGE_BLOCK_HXX__ */