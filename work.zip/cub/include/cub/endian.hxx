//
// Created by 10209409 on 3/23/2017.
//

#ifndef __ENDIAN_HXX__
#define __ENDIAN_HXX__
#include <endian.h>

#if BYTE_ORDER == LITTLE_ENDIAN
#    define CUB_LITTLE_ENDIAN
#elif BYTE_ORDER == BIG_ENDIAN
#    define CUB_BIG_ENDIAN
#endif
#endif /* __ENDIAN_HXX__ */
