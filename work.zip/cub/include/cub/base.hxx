//
// Created by 10209409 on 3/14/2017.
//

#ifndef __BASE_HXX__
#define __BASE_HXX__

#define ns_begin(ns)   namespace ns {
#define ns_end(ns)     }

#ifndef safe_free
#define safe_free(x, cb)                                    \
    do                                                      \
    {                                                       \
        if (nullptr != (x))                                 \
        {                                                   \
            (cb) (x);                                       \
            (x) = nullptr;                                  \
        }                                                   \
    } while(0)
#endif

#ifndef safe_delete
#define safe_delete(x)                                      \
    do                                                      \
    {                                                       \
        if (nullptr != (x))                                 \
        {                                                   \
            delete (x);                                     \
            (x) = nullptr;                                  \
        }                                                   \
    } while(0)
#endif

#ifndef safe_delete_array
#define safe_delete_array(x)                                \
    do                                                      \
    {                                                       \
        if (nullptr != (x))                                 \
        {                                                   \
            delete[] (x);                                   \
            (x) = nullptr;                                  \
        }                                                   \
    } while(0)
#endif
#endif /* __BASE_HXX__ */
