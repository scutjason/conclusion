//
// Created by 10209409 on 3/14/2017.
//

#ifndef __NONCOPYABLE_HXX__
#define __NONCOPYABLE_HXX__

#include <cub/base.hxx>

ns_begin(cub)

class noncopyable
{
protected:
    #if (__cplusplus >= 201103L)
    noncopyable()  = default;
    ~noncopyable() = default;
    #else
    noncopyable()  {}
    ~noncopyable() {}
    #endif

    #if (__cplusplus >= 201103L)
    noncopyable(const noncopyable&)            = delete;
    noncopyable& operator=(const noncopyable&) = delete;
    #else
private:  // emphasize the following members are private
    noncopyable(const noncopyable &);
    noncopyable &operator=(const noncopyable &);

    #endif
};


typedef noncopyable noncopyable;

ns_end(cub)
#endif /* __NONCOPYABLE_HXX__ */
