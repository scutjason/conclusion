//
// Created by 10209409 on 3/16/2017.
//

#ifndef __BARRIER_HXX__
#define __BARRIER_HXX__

#include <cub/base_types.hxx>
#include <cub/mutex.hxx>

#include <condition_variable>

ns_begin(cub)

class barrier
{
private:
    std::mutex              _mutex;
    std::condition_variable _cv;
    std::size_t             _count;
public:
    explicit barrier(std::size_t count) : _count{count} { }
    void wait()
    {
        std::unique_lock<std::mutex> lock{_mutex};

        if (--_count == 0)
        {
            _cv.notify_all();
        }

        else
        {
            _cv.wait(lock, [this] { return _count == 0; });
        }
    }
};
ns_end(cub)
#endif /* __BARRIER_HXX__ */
