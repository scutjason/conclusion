//
// Created by 10209409 on 3/14/2017.
//

#ifndef __CACHE_ALLOCATOR_HXX__
#define __CACHE_ALLOCATOR_HXX__

#include <assert.h>
#include <mutex>
#include <condition_variable>

#include <cub/noncopyable.hxx>
#include <cub/mem/cache_pool.hxx>
#include <cub/base.hxx>

ns_begin(cub)
ns_begin(mem)

enum
{
    MAX_CACHE_POOL_NUM = 64,
};

#define data_size_to_index(data_size) ((((data_size) - 1) & 0xffffff00) >> 8)

class cache_allocator : public noncopyable
{
public:
    static cache_allocator* Instance();

    bool init(  unsigned int init_cache_num   = INIT_CACHE_NUM,
                unsigned int expand_cache_num = EXPAND_CACHE_NUM,
                unsigned int max_cache_num    = MAX_CACHE_NUM );

    unsigned int alloc(cache_data*& data_list, size_t data_size,
                       unsigned int alloc_count, bool block_flag = false);

    unsigned int free(cache_data*& data_list, unsigned int free_count);

private:
    cache_allocator(): _inited(false)
    {
    }

private:
    std::mutex                    _cache_mutex[MAX_CACHE_POOL_NUM];
    std::condition_variable       _empty_condition[MAX_CACHE_POOL_NUM];
    cache_pool                    _cache_pool[MAX_CACHE_POOL_NUM];

    static std::mutex             _instance_mutex;
    static cache_allocator*       _instance;

    bool                           _inited;
};
ns_end(mem)
ns_end(cub)
#endif /* __CACHE_ALLOCATOR_HXX__ */
