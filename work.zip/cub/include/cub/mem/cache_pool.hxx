//
// Created by 10209409 on 3/14/2017.
//

#ifndef __CACHE_POOL_XX__
#define __CACHE_POOL_XX__

#include <list>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include <cub/noncopyable.hxx>

ns_begin(cub)
ns_begin(mem)

struct cache_data
{
    unsigned short  magic_data;     // 校验字
    unsigned int    size;           // 数据块大小,含cache_data头部
    unsigned int    custom_args;    // 用户自定义参数
    cache_data*     next;           // 下一个数据块
    char            data[0];
};

const unsigned short CACHE_MAGIC = 0x0823;

struct cache_chunk
{
    cache_chunk()
    {
        reset();
    }

    void reset()
    {
        next      = nullptr;
        cache     = nullptr;
        cache_num = 0;
    }

    int cache_num; // 缓存数据个数
    cache_data* cache;
    cache_chunk* next;
};

enum
{
    ALLOC_TYPE_MEMORY_POOL = 0,
    ALLOC_TYPE_GLIBC = 1,
};

enum
{
    INIT_CACHE_NUM            = 4096,
    EXPAND_CACHE_NUM          = 4096,
    CHUNK_CACHE_NUM           = 4096, // 大块数据块的缓存个数
    // MAX_CACHE_NUM             = 1024 * 1024 * 1024
    MAX_CACHE_NUM             = 500000000,
    DEFAULT_CUSTOM_ARGS_VALUE = 0xffff, // 默认自定义参数值
};

#define align_cache_chunk_num(cache_num) (((cache_num) + CHUNK_CACHE_NUM - 1) / CHUNK_CACHE_NUM * CHUNK_CACHE_NUM )
#define align_cache_object_size(object_size) (((object_size) + 8 - 1) / 8 * 8 )

class cache_pool
{
public:
    cache_pool() : _object_size(0), _expand_cache_num(EXPAND_CACHE_NUM),
        _max_cache_num(MAX_CACHE_NUM), _total_cache_count(0),
        _free_cache_count(0), _free_cache_chunk_list(nullptr),
        _used_cache_chunk_list(nullptr)
    {
    }

    ~cache_pool()
    {
        cache_chunk* chunk = nullptr;

        while (_free_cache_chunk_list != nullptr)
        {
            chunk = _free_cache_chunk_list;
            _free_cache_chunk_list = _free_cache_chunk_list->next;
            delete chunk;
        }

        cache_data* cache = nullptr;
        cache_data* cache_list = nullptr;

        while (_used_cache_chunk_list != nullptr)
        {
            cache_list = _used_cache_chunk_list->cache;

            while (cache_list != nullptr)
            {
                cache      = cache_list;
                cache_list = cache_list->next;
                ::free((void*)cache);
            }

            chunk                  = _used_cache_chunk_list;
            _used_cache_chunk_list = _used_cache_chunk_list->next;
            delete chunk;
        }
    }

    bool init(unsigned int object_size,
              unsigned int init_cache_num   = INIT_CACHE_NUM,
              unsigned int expand_cache_num = EXPAND_CACHE_NUM,
              unsigned int max_cache_num    = MAX_CACHE_NUM)
    {
        assert( object_size > 0 );
        assert( expand_cache_num > 0 );
        assert( max_cache_num > 0 );

        _object_size          = align_cache_object_size(object_size);
        _expand_cache_num     = align_cache_chunk_num(expand_cache_num);
        _max_cache_num        = align_cache_chunk_num(max_cache_num);
        unsigned int init_num = align_cache_chunk_num( init_cache_num);

        if ( init_num > 0 )
        {
            expand( init_num );
        }

        return true;
    }

    cache_data* alloc(cache_data*& cache, int& cache_count)
    {
        if ( (nullptr == _used_cache_chunk_list) && (!expand( _expand_cache_num )) )
        {
            static unsigned long error_count = 0;

            error_count++;
            return nullptr;
        }

        cache                  = _used_cache_chunk_list->cache;
        cache_count            = _used_cache_chunk_list->cache_num;

        cache_chunk* chunk     = _used_cache_chunk_list;
        _used_cache_chunk_list = chunk->next;

        chunk->reset();
        free_cache_chunk(chunk);

        _free_cache_count     -= cache_count;

        return cache;
    }

    void free(cache_data* cache, int cache_count)
    {
        assert(cache != nullptr );
        assert(cache->size == _object_size);

        cache_chunk* chunk = alloc_cache_chunk();
        assert (chunk != nullptr );
        chunk->cache_num = cache_count;
        chunk->cache = cache;
        free_cache_chunk(chunk);

        _free_cache_count += cache_count;
    }

    unsigned int total_cache_count() const
    {
        return _total_cache_count;
    }

    unsigned int free_cache_count() const
    {
        return _free_cache_count;
    }

protected:
    bool expand(unsigned int expand_cache_num)
    {
        if ( _total_cache_count > _max_cache_num )
        {
            return false;
        }

        size_t signal_data_size = sizeof(cache_data) + _object_size;
        char* data_block        = nullptr;
        cache_data* cache_list  = nullptr;
        int cache_count         = 0;

        for ( unsigned int i = 0; i < expand_cache_num; i++ )
        {
            data_block = (char*)malloc(signal_data_size);

            assert (data_block != nullptr);

            cache_data* cache  = (cache_data*)data_block;
            cache->custom_args = DEFAULT_CUSTOM_ARGS_VALUE;
            cache->size        = _object_size;
            cache->magic_data  = CACHE_MAGIC;
            cache->next        = cache_list;
            cache_list         = cache;

            _total_cache_count++;
            _free_cache_count++;
            cache_count++;

            if ( CHUNK_CACHE_NUM == cache_count )
            {
                cache_chunk* chunk = alloc_cache_chunk();
                assert (chunk != nullptr );
                chunk->cache_num = cache_count;
                chunk->cache = cache_list;

                free_cache_chunk( chunk );

                cache_list = nullptr;
                cache_count = 0;
            }
        }

        if ( cache_count > 0)
        {
            cache_chunk* chunk = alloc_cache_chunk();
            assert (chunk != nullptr );
            chunk->cache_num = cache_count;
            chunk->cache = cache_list;

            free_cache_chunk( chunk );

            cache_list = nullptr;
            cache_count = 0;
        }

        return true;
    }

    cache_chunk* alloc_cache_chunk()
    {
        cache_chunk* chunk = nullptr;

        if ( nullptr == _free_cache_chunk_list )
        {
            chunk = new cache_chunk();
        }

        else
        {
            chunk = _free_cache_chunk_list;
            _free_cache_chunk_list = chunk->next;
            chunk->next = nullptr;
        }

        return chunk;
    }

    void free_cache_chunk( cache_chunk* chunk )
    {
        if ( chunk->cache_num > 0 )
        {
            chunk->next = _used_cache_chunk_list;
            _used_cache_chunk_list = chunk;
        }

        else
        {
            chunk->next = _free_cache_chunk_list;
            _free_cache_chunk_list = chunk;
        }
    }

private:
    unsigned int _object_size;
    unsigned int _expand_cache_num;
    unsigned int _max_cache_num;

    unsigned int _total_cache_count;
    unsigned int _free_cache_count;


    cache_chunk* _free_cache_chunk_list;
    cache_chunk* _used_cache_chunk_list;
};

ns_end(mem)
ns_end(cub)
#endif /* __CACHE_POOL_XX__ */
