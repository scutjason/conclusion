//
// Created by 10209409 on 3/14/2017.
//

#ifndef __THREAD_CACHE_ALLOCATOR__
#define __THREAD_CACHE_ALLOCATOR__
#include <cub/noncopyable.hxx>
#include <cub/mutex.hxx>
#include <cub/mem/cache_pool.hxx>
#include <cub/mem/cache_allocator.hxx>

#include <list>
#include <assert.h>

ns_begin(cub)
ns_begin(mem)

class thread_cache_allocator : public noncopyable
{
public:
    enum
    {
        DEFAULT_BATCH_ALLOC_SIZE  = 4096,
        DEFAULT_BATCH_FREE_SIZE   = 4096,
        DEFAULT_THREAD_CACHE_SIZE = 4096,
    };

    static thread_cache_allocator* Instance();

    ~thread_cache_allocator();

    // 申请
    bool alloc( char*& data,
                unsigned int data_len,
                unsigned int args = DEFAULT_CUSTOM_ARGS_VALUE,
                bool block_flag = false );

    // 释放
    void free(char* data);

    void max_thread_cache_size( unsigned int max_thread_cache_size )
    {
        _max_thread_cache_size = max_thread_cache_size;
    }

    void batch_free_size( unsigned int batch_free_size )
    {
        _batch_free_size = batch_free_size;
    }

    void batch_alloc_size( unsigned int batch_alloc_size )
    {
        _batch_alloc_size = batch_alloc_size;
    }

private:
    thread_cache_allocator();

private:
    unsigned int                                _cache_count[MAX_CACHE_POOL_NUM];
    cache_data*                                 _cache_pool[MAX_CACHE_POOL_NUM];

    unsigned int                                _max_thread_cache_size;
    unsigned int                                _batch_free_size;
    unsigned int                                _batch_alloc_size;

    static std::mutex                           _instance_mutex;
    static thread_local std::shared_ptr<thread_cache_allocator> _instance;
};

char* cub_alloc( unsigned int size,
                 unsigned int args = DEFAULT_CUSTOM_ARGS_VALUE,
                 bool block_flag   = false);

// 根据配置将内存释放到内存池中或glic中
void cub_free(char* data);

// 使用内存池标记
extern bool g_used_memory_pool;

ns_end(mem)
ns_end(cub)
#endif /* __${HEADER_FILENAME}_h */
