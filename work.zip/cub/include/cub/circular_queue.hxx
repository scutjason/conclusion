#ifndef __CIRCULAR_QUEUE_HPP__
#define __CIRCULAR_QUEUE_HPP__
#include <iostream>
#include <sstream>
#include <functional>
#include <chrono>
#include <assert.h>
#include <thread>

#include <cub/base.hxx>
#include <cub/base_types.hxx>

#ifndef CACHE_LINE_SIZE
#define CACHE_LINE_SIZE 8
#endif

#define PADDING_SIZE    (2 * CACHE_LINE_SIZE - 1)

using namespace std;
using namespace std::chrono;
using std::chrono::high_resolution_clock;

ns_begin(cub)

typedef size_t  capacity_type;

class sequence
{
public:
    sequence()
    {
        set(INITIAL_VALUE);
    }

    sequence(long init_value)
    {
        set(init_value);
    }

    sequence(const sequence& rh)
    {
        set(rh.get());
    }

    sequence& operator=(const sequence& rh)
    {
        if (this != &rh)
        {
            set(rh.get());
        }

        return *this;
    }

    virtual ~sequence()
    {
    }

    inline uint64 get() const
    {
        return _padded_value[CACHE_LINE_SIZE - 1];
    }

    inline void set(uint64 value)
    {
        _padded_value[CACHE_LINE_SIZE - 1] = value;
    }

    inline bool compare_and_set(uint64 expectedValue, uint64 newValue)
    {
        return __sync_bool_compare_and_swap(&_padded_value[CACHE_LINE_SIZE - 1],
                                            expectedValue, newValue);
    }
public:
    static const uint64 INITIAL_VALUE = 0L;

private:
    uint64 _padded_value[PADDING_SIZE];
};

template<typename T>
class circular_queue
{
public:
    typedef std::function<void (T&)> free_callback;
public:
    static const capacity_type DEFAULT_BUFF_SIZE      = 1024 * 1024;
    static const unsigned short DEFAULT_WAIT_UNTIL_MS = 500;
    static const unsigned short DEFAULT_SPIN_TRIES    = 10;
    static const unsigned short DEFAULT_SLEEP_MS      = 100;

    circular_queue(capacity_type buff_size, free_callback callback = nullptr);

    #ifdef  __SEQUENCE_OVER_FLOW_TEST__
    circular_queue(capacity_type buff_size, uint64 init_seq,
                   free_callback callback = nullptr): _buff_size(buff_size),
        _entry(nullptr), _available_buff(nullptr), _callback(callback)
    {
        init(init_seq);
    }
    #endif

    virtual ~circular_queue();

    inline void reset_counter() const
    {
        _pre_time   = high_resolution_clock::now();
        _push_count = _push_num;
        _pop_count  = _pop_num;
    }

    inline capacity_type push_counter() const
    {
        return _push_num - _push_count;
    }

    inline capacity_type pop_counter() const
    {
        return _pop_num - _pop_count;
    }

    inline capacity_type push_nbr()const
    {
        return _push_num;
    }

    inline capacity_type pop_nbr()const
    {
        return _pop_num;
    }

    inline capacity_type size() const
    {
        int queue_size = _push_num - _pop_num;
        return queue_size > 0 ? queue_size : 0;
    }

    inline capacity_type capacity() const
    {
        return _buff_size;
    }

    inline void set_spin_tries(capacity_type count) const
    {
        _spin_tries = count;
    }

    inline double max_push_speed()const
    {
        return _max_push_speed;
    }

    inline double min_push_speed()const
    {
        return _min_push_speed;
    }

    inline double max_pop_speed()const
    {
        return _max_pop_speed;
    }

    inline double min_pop_speed()const
    {
        return _min_pop_speed;
    }
    inline double push_speed() const
    {
        double cur_speed = speed(_pre_time, push_counter());
        _max_push_speed = (cur_speed > _max_push_speed) ? cur_speed : _max_push_speed;
        _min_push_speed = (cur_speed < _min_push_speed) ? cur_speed : _min_push_speed;
        return cur_speed;
    }

    inline double pop_speed() const
    {
        double cur_speed = speed(_pre_time, pop_counter());
        _max_pop_speed = (cur_speed > _max_pop_speed) ? cur_speed : _max_pop_speed;
        _min_pop_speed = (cur_speed < _min_pop_speed) ?  cur_speed : _min_pop_speed;
        return cur_speed;
    }

    inline double average_push_speed() const
    {
        return speed(_begin_time, push_nbr());
    }

    inline double average_pop_speed() const
    {
        return speed(_begin_time, pop_nbr());
    }

    void push(const T& t);

    bool try_push(const T& t);

    bool timed_push(const T& t,
                    const capacity_type& wait_until = DEFAULT_WAIT_UNTIL_MS);


    void pop(T& t);

    bool try_pop(T& t);

    bool timed_pop(T& t, const capacity_type& wait_until = DEFAULT_WAIT_UNTIL_MS);

    std::string to_string() const
    {
        std::stringstream result;
        result << "[" << std::endl;
        result << "thread            : " << hex << std::this_thread::get_id() <<
               std::endl;
        result << "circular_queue    : " << hex << this << std::endl;
        result << "    size          : " << dec << size() << std::endl;
        result << "    buff_size     : " << dec << _buff_size  << std::endl;
        result << "    push_counter  : " << dec << push_counter() << std::endl;
        result << "    pop_counter   : " << dec << pop_counter() << std::endl;
        result << "    push_speed    : " << push_speed() << std::endl;
        result << "    pop_speed     : " << pop_speed() << std::endl;
        result << "]" << std::endl;
        return result.str();
    }

private:
    circular_queue(const circular_queue &queue);

    circular_queue& operator=(const circular_queue &queue);


    void init(uint64 init_seq);

    inline bool is_pow_of_two(capacity_type num)
    {
        return ((num > 0) && (num & (num - 1))) == 0;
    }

    inline void init_available_buff(uint64  init_seq)
    {
        assert(init_seq < (init_seq + _buff_size));

        for (capacity_type i = init_seq; i < init_seq + _buff_size; ++i)
        {
            _available_buff[(capacity_type) i & _index_mask] = i * 2;
        }
    }

    inline uint32 log2(capacity_type num)
    {
        uint32 n = 0;

        while ((num >>= 1) != 0)
        {
            ++n;
        }

        return n;
    }

    uint64 next();
    bool   try_next(uint64 &next_seq);
    uint64 read_next();
    bool   try_read_next(uint64 &next_seq);


    inline bool writable(uint64 seq)
    {
        return _available_buff[(capacity_type) seq & _index_mask] == seq * 2;
    }

    inline bool readable(uint64 seq)
    {
        return (_available_buff[(capacity_type) seq & _index_mask] - 1) == seq * 2;
    }

    /*
     * set the position readable after write. separate the flag's value as two part:
     * the last bit means readable or writeable (1 means readable,0 means writeable).
     * the second part was the sequence used by read/write thread. only thread get
     * the read sequence as same as the sequence write thread used to set the flag can read.
     */
    inline void set_readable(uint64 seq)
    {
        __sync_synchronize();
        _available_buff[(capacity_type) seq & _index_mask] = seq * 2 + 1;
        __sync_fetch_and_add(&_push_num, 1);
    }

    /*
     * set the position readable after write. separate the flag's value as two part:
     * the last bit means readable or writeable (1 means readable,0 means writeable).
     * the second part was the sequence used by read/write thread. only thread get
     * the read sequence as same as the sequence write thread used to set the flag can read.
     */
    inline void set_writeable(uint64 seq)
    {
        __sync_synchronize();
        _available_buff[(capacity_type) seq & _index_mask] = (seq + _buff_size ) * 2;
        __sync_fetch_and_add(&_pop_num, 1);
    }

    inline capacity_type wait_strategy(capacity_type counter,
                                       const capacity_type& wait_until = 1)
    {
        if (_spin_tries == 0)
        {
            return _spin_tries;
        }

        if (counter == 0)
        {
            timespec t;
            t.tv_sec  = 0;
            t.tv_nsec = wait_until * 1000000L;
            nanosleep(&t, nullptr);
            counter = _spin_tries;
        }

        else
        {
            --counter;
        }

        return counter;
    }

    double speed(const high_resolution_clock::time_point &begin_time,
                 capacity_type count) const;

private:
    capacity_type                                  _buff_size;
    T*                                             _entry;
    sequence                                       _claim_write_seq;
    uint64*                                        _available_buff;
    capacity_type                                  _index_mask;
    sequence                                       _claim_read_seq;

    mutable capacity_type                          _push_count;
    mutable capacity_type                          _pop_count;
    capacity_type                                  _push_num;
    capacity_type                                  _pop_num;
    mutable capacity_type                          _spin_tries;
    uint32                                         _index_shift;
    free_callback                                  _callback;
    mutable high_resolution_clock::time_point      _begin_time;
    mutable high_resolution_clock::time_point      _pre_time;
    mutable double                                 _max_push_speed;
    mutable double                                 _min_push_speed;
    mutable double                                 _max_pop_speed;
    mutable double                                 _min_pop_speed;

    template<typename T1>
    friend ostream& operator<<(ostream&, const circular_queue<T1>&);
};

template<typename T1>
ostream& operator<<(ostream& s, const circular_queue<T1>& r)
{
    s << "[" << std::endl;
    s << "thread            : " << hex << std::this_thread::get_id() << std::endl;
    s << "circular_queue    : " << hex << &r << std::endl;
    s << "    size          : " << dec << r.size() << std::endl;
    s << "    buff_size     : " << dec << r._buff_size  << std::endl;
    s << "    push_counter  : " << dec << r.push_counter() << std::endl;
    s << "    pop_counter   : " << dec << r.pop_counter() << std::endl;
    s << "    push_speed    : " << r.push_speed() << std::endl;
    s << "    pop_speed     : " << r.pop_speed() << std::endl;
    s << "]" << std::endl;
    return s;
}

template<typename T>
circular_queue<T>::circular_queue(capacity_type buff_size,
                                  free_callback callback)
    : _buff_size(buff_size), _entry(nullptr), _available_buff(nullptr),
      _callback(callback)
{
    init(0);
}

template<typename T>
circular_queue<T>::~circular_queue()
{
    if (_entry != nullptr)
    {
        if (_available_buff != nullptr)
        {
            if (_callback)
            {
                for (capacity_type i = 0; i < _buff_size; ++i)
                {
                    if ((_available_buff[i] & 1))
                    {
                        _callback(_entry[i]);
                    }
                }
            }

            delete [] _available_buff;
            _available_buff = nullptr;
        }

        delete [] _entry;
        _entry = nullptr;
    }
}

template<typename T>
void circular_queue<T>::init(uint64 init_seq)
{
    if (!is_pow_of_two(_buff_size))
    {
        capacity_type size = 1 << (log2(_buff_size) + 1);
        _buff_size         = size;
    }

    _index_mask     = _buff_size - 1;

    _entry          = new T[_buff_size];
    _available_buff = new uint64[_buff_size];
    _index_shift    = log2(_buff_size);
    _spin_tries     = DEFAULT_SPIN_TRIES;
    _push_num       = 0;
    _push_count     = 0;
    _pop_num        = 0;
    _pop_count      = 0;
    _begin_time     = high_resolution_clock::now();
    _pre_time       = _begin_time;
    _max_push_speed = 0.0;
    _min_push_speed = std::numeric_limits<double>::max();
    _max_pop_speed  = 0.0;
    _min_pop_speed  = std::numeric_limits<double>::max();
    _claim_write_seq.set(init_seq);
    _claim_read_seq.set(init_seq);
    init_available_buff(init_seq);
}

template<typename T>
void circular_queue<T>::push(const T& t)
{
    uint64 next_seq = next();
    _entry[(capacity_type)next_seq & _index_mask] = t;
    set_readable(next_seq);
}

template<typename T>
bool circular_queue<T>::try_push(const T& t)
{
    uint64  next_seq;
    bool result = try_next(next_seq);

    if (result)
    {
        _entry[(capacity_type)next_seq & _index_mask] = t;
        set_readable(next_seq);
    }

    return result;
}

template<typename T>
bool circular_queue<T>::timed_push(const T& t, const capacity_type& wait_until)
{
    bool result = false;
    capacity_type counter = wait_until / DEFAULT_SLEEP_MS;
    timespec tt;
    tt.tv_sec = 0;
    tt.tv_nsec = DEFAULT_SLEEP_MS * 1000000L;

    while (counter > 0)
    {
        if (try_push(t))
        {
            result = true;
            break;
        }

        if (size() == capacity())
        {
            nanosleep(&tt, nullptr);
        }

        --counter;
    }

    return result;
}

/*
 * get next writeable position
 */
template<typename T>
uint64 circular_queue<T>::next()
{
    uint64 current_seq;
    capacity_type counter = _spin_tries;

    do
    {
        current_seq = _claim_write_seq.get();

        if (!writable(current_seq))
        {
            counter = wait_strategy(counter);
        }

        else if (_claim_write_seq.compare_and_set(current_seq, current_seq + 1))
        {
            break;
        }
    }
    while (true);

    return current_seq;
}

template<typename T>
bool circular_queue<T>::try_next(uint64 &next_seq)
{
    uint64 current_seq;

    do
    {
        current_seq = _claim_write_seq.get();

        if (!writable(current_seq))
        {
            if (current_seq != _claim_write_seq.get())
            {
                continue;
            }

            return false;
        }

        else if (_claim_write_seq.compare_and_set(current_seq, current_seq + 1))
        {
            next_seq = current_seq;
            return true;
        }
    }
    while (true);
}

template<typename T>
void circular_queue<T>::pop(T& t)
{
    uint64 read_seq = read_next();
    t = _entry[(capacity_type)read_seq & _index_mask];
    set_writeable(read_seq);
}

template<typename T>
bool circular_queue<T>::try_pop(T& t)
{
    uint64  read_seq;
    bool result = try_read_next(read_seq);

    if (result)
    {
        t = _entry[(capacity_type)read_seq & _index_mask];
        set_writeable(read_seq);
    }

    return result;
}

template<typename T>
bool circular_queue<T>::timed_pop(T& t, const capacity_type& wait_until)
{
    capacity_type counter = wait_until / DEFAULT_SLEEP_MS;
    timespec tt;
    tt.tv_sec = 0;
    tt.tv_nsec = DEFAULT_SLEEP_MS * 1000000L;

    while (counter > 0)
    {
        if (try_pop(t))
        {
            return true;
        }

        if ((size() == 0))
        {
            nanosleep(&tt, nullptr);
        }

        --counter;
    }

    return false;
}

/*
 * get next readable position
 */
template<typename T>
uint64 circular_queue<T>::read_next()
{
    uint64  current_read_seq;
    capacity_type counter = _spin_tries;

    do
    {
        current_read_seq = _claim_read_seq.get();

        if (!readable(current_read_seq))
        {
            counter = wait_strategy(counter);
        }

        else if (_claim_read_seq.compare_and_set(current_read_seq,
                 current_read_seq + 1))
        {
            break;
        }
    }
    while (true);

    return current_read_seq;
}

template<typename T>
bool circular_queue<T>::try_read_next(uint64 &next_seq)
{
    uint64  current_read_seq;

    do
    {
        current_read_seq = _claim_read_seq.get();

        if (!readable(current_read_seq))
        {
            if (current_read_seq != _claim_read_seq.get())
            {
                continue;
            }

            return false;
        }

        else if (_claim_read_seq.compare_and_set(current_read_seq,
                 current_read_seq + 1))
        {
            next_seq = current_read_seq;
            return true;
        }
    }
    while (true);
}
template<typename T>
double circular_queue<T>::speed(const high_resolution_clock::time_point
                                &begin_time,
                                capacity_type count) const
{
    high_resolution_clock::time_point now = high_resolution_clock::now();

    long time_span = duration_cast<microseconds>(now - begin_time).count();

    if (time_span <= 0)
    {
        return 0;
    }

    else
    {
        return (double) (count * 1000) / time_span;
    }
}

ns_end(cub)
#endif

