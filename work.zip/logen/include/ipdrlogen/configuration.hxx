//
// Created by 10209409 on 3/15/2017.
//

#ifndef __CONFIGURATION_HXX__
#define __CONFIGURATION_HXX__

#include <cub/base_types.hxx>
#include <string>

const std::string  APPLICATION              = "appname";


const std::string LOG_DIR                           = "/log/";
const std::string LOGGER                            = "LOGGER";
const std::string LOG_FILE_EXT                      = ".log";
const std::string LOG_FORMAT                        = "%L%Y-%m-%d %H:%M:%S.%i %s[%P] %p %U:%u %t";
const std::string TIME_FORMAT                       = "%Y-%m-%d %H:%M:%S.%i";

const std::string STDOUT                            = "stdout";
const std::string STDERR                            = "stderr";

const std::string CONFIG_DIR                        = "/etc/";
const std::string CONFIG_FILE_EXT                   = ".ini";

const std::string COMMON_LOG_LEVEL                  = "common.log_level";
const std::string DEFAULT_LOG_LEVEL                 = "information";

const std::string LOGEN_SERVER_ADDRESS              = "logen.listen_address";
const std::string LOGEN_FILE_DEVICE_ID              = "logen.file.deviceid";
const std::string DEFAULT_DEVICE_ID                 = "001";
const std::string LOGEN_FILE_ENTRY_NUM              = "logen.file.entries";
const std::string LOGEN_FILE_SWITCH_INTERVAL        = "logen.file.switch_interval";
const std::string LOGEN_FILE_LIST_UPLOAD_INTERVAL   = "logen.file.list_upload_interval";
const std::string LOGEN_FILTERFILE_SWITCH_INTERVAL  = "logen.filterfile.switch_interval";
const std::string LOGEN_FILTERFILE_ENTRIES          = "logen.filterfile.entries";

const std::string LOGEN_FILTERFILE_CONDITION_NUM  = "login.filterfile.conditon.num";
const std::string LOGEN_ACCOUNT_MONITOR_CONDITION_NUM  = "login.account_monitor.conditon.num";

const std::string LOGEN_WRITE_THREAD_NUM            = "logen.file.write.thread.num";

const std::string LOGEN_FILE_ACCOUNT_TYPE           = "logen.file.account_type";
const std::string LOGEN_FILE_TIME_FORMAT            = "logen.file.line_time_format";

const std::string LOGEN_ONLINE_CACHE_CAPACITY       = "logen.online_cache_capacity";
const std::string LOGEN_ONLINE_CACHE_CYCLE          = "logen.online_cache_cycle";
const std::string LOGEN_OFFLINE_CACHE_CAPACITY      = "logen.offline_cache_capacity";
const std::string LOGEN_OFFLINE_CACHE_CYCLE         = "logen.offline_cache_cycle";

const std::string DEFAULT_TIME_FORMAT               = "%Y-%m-%d %H:%M:%S";

const std::string INTERFACE_SERVER_ADDRESS          = "interface.listen_address";
const std::string DEFAULT_INTERFACE_SERVER_ADDRESS  = "0.0.0.0:8080";
const std::string INTERFACE_URI                     = "/ipdr";

const std::string DEFAULT_NORTH_UPLOAD_PROTOCOL   = "SFTP";
const std::string NORTH_UPLOAD_PROTOCOL              = "north.upload.protocol";

const std::string NORTH_FTP_SERVER                  = "north.upload.ftp_server";
const std::string NORTH_FTP_PORT                    = "north.upload.ftp_port";
const std::string NORTH_FTP_USER                    = "north.upload.ftp_user";
const std::string NORTH_FTP_PASSWORD                = "north.upload.ftp_password";
const std::string NORTH_FTP_PATH                    = "north.upload.ftp_path";
const uint16 DEFAULT_FTP_PORT                       = 21;

const std::string UPLOAD_SFTP_SERVER                = "upload.sftp.server";
const std::string UPLOAD_SFTP_PORT                  = "upload.sftp.port";
const std::string UPLOAD_SFTP_USER                  = "upload.sftp.user";
const std::string UPLOAD_SFTP_PASSWORD              = "upload.sftp.password";
const std::string UPLOAD_SFTP_ACCESS_PATH           = "upload.sftp.access.path";
const std::string UPLOAD_SFTP_LINE_PATH             = "upload.sftp.line.path";
const std::string UPLOAD_SFTP_NAT_PATH              = "upload.sftp.nat.path";
const std::string UPLOAD_SFTP_FILE_LIST_PATH        = "upload.sftp.file.list.path";
const std::string UPLOAD_SFTP_KEYWORK_FILTER_PATH   = "upload.sftp.keyword.filter.path";
const std::string REUPLOAD_SFTP_ACCESS_PATH           = "reupload.sftp.access.path";
const std::string REUPLOAD_SFTP_LINE_PATH             = "reupload.sftp.line.path";
const std::string REUPLOAD_SFTP_NAT_PATH              = "reupload.sftp.nat.path";
const std::string REUPLOAD_SFTP_FILE_LIST_PATH        = "reupload.sftp.file.list.path";
const std::string REUPLOAD_SFTP_KEYWORK_FILTER_PATH   = "reupload.sftp.keyword.filter.path";

const std::string USER_ACCOUNT_LINE_VERSION                = "user.account.line.version";
const std::string USER_ACCOUNT_BOCE_TEL                  = "user.account.boce.msisdn";



const uint16 DEFAULT_SFTP_PORT                      = 22;

const uint32 LOG_ENTRY_NUM_MIN                      = 0;
const uint32 LOG_ENTRY_NUM_MAX                      = 400000;


const std::string XDR_ROOT_DIR                      = "xdr/";
const std::string XDR_FILE_SUFFIX                   = ".txt.gz";
const std::string XDR_DIR_FORMAT                    = "%Y%m%d/";
const std::string OK_SUFFIX                         = ".ok";
const std::string NAME_FILED_DELIMITER              = "-";
const size_t END_TIME_IDX                           = 4;
const size_t YYYYMMDD_LENGTH                        = 8;
const char PATH_SEP                                 = '/';
const std::string PATH_SEP_STR                      = "/";
const uint64 MICROSECONDS_PER_DAY                   = 24l * 60l * 60l * 1000l * 1000l;
const uint64 THREE_DAYS_IN_MICROSECONDS             = 72l * 60l * 60l * 1000l * 1000l;
#endif /* __CONFIGURATION_HXX__ */
