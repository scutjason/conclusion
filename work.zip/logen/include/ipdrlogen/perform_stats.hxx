//
// Created by 10171618 on 4/14/2017.
//

#ifndef __PERFORM_STATS_HXX__
#define __PERFORM_STATS_HXX__

#include <cub/base_types.hxx>
#include <Poco/Timestamp.h>
#include <Poco/FileStream.h>
#include <Poco/Timer.h>
#include <map>
#include <ipdrlogen/common.hxx>
#include <ipdrlogen/configuration.hxx>
#include "ipdrlogen/Feature.h"

using Poco::Timer;
using Poco::TimerCallback;
using Poco::Timestamp;





class PerformStats
{
    std::string     _ipAddr;
    const std::string STATS_FILE_HEAD           = "stats_";
    const std::string STATS_FILE_FORMAT         = "%Y%m%d";
    
    const uint32 TIMER_START_INTERVAL           = 0;
    const uint32 TIMER_PERIOD_INTERVAL          = 60 * 1000;
    
    const std::string KPI_FILE_DIR                      = "/home/vmax-saltagent/sample/HOST_Manager/iplog/";
    const std::string KPI_FILE_NAME                     = "iplog_logserver_xdr_collect_";
    const std::string KPI_SUFFIX                        = ".txt";

    std::string device_id = app_config.getString(LOGEN_FILE_DEVICE_ID,
                                DEFAULT_DEVICE_ID);

public:
    PerformStats();
    ~PerformStats();
    
    void onTimer(Timer& timer);
    
    std::string inStringFormat();
    std::string xdrInStringFormat();
    std::string fileInStringFormat();

    void clearIndexOfStars();
    
public:
    Timestamp       _ctl_time;
    
    static unsigned long          _rx_xdr_bytes ;
    static unsigned long          _rx_nat_bytes;
    static unsigned long          _rx_line_bytes;
                                  
    static unsigned long   _en_access_nums;
    static unsigned long   _en_nat_nums;
    static unsigned long   _en_line_nums;
    
    static unsigned long   _de_access_nums;
    static unsigned long   _de_nat_nums;
    static unsigned long   _de_line_nums;
    
    static unsigned long    _wq_access_nums;
    static unsigned long    _wq_nat_nums;
    static unsigned long    _wq_line_nums;
    static unsigned long    _wq_fl_nums;
    static unsigned long    _wq_kf_nums;

    static unsigned long   _fw_access_nums;
    static unsigned long   _fw_nat_nums;
    static unsigned long   _fw_line_nums;
    static unsigned long   _fw_fl_nums;
    static unsigned long   _fw_kf_nums;
    
    static unsigned long   _incoming_msgs;
	static unsigned long   _online_msgs;
	static unsigned long   _offline_msgs;
	static unsigned long   _online_cache_size;
	static unsigned long   _offline_cache_size;

    static unsigned long   _fw_access_bytes;
    static unsigned long   _fw_nat_bytes;
    static unsigned long   _fw_line_bytes;
    
    static unsigned long   _gz_access_bytes;
    static unsigned long   _gz_nat_bytes;
    static unsigned long   _gz_line_bytes;

    static unsigned long   _sftp_access_nums;
    static unsigned long   _sftp_nat_nums;
    static unsigned long   _sftp_line_nums;
    static unsigned long   _sftp_kf_nums;
    static unsigned long   _sftp_fl_nums;

    static unsigned long   _sftp_access_bytes;
    static unsigned long   _sftp_nat_bytes;
    static unsigned long   _sftp_line_bytes;
    static unsigned long   _sftp_kf_bytes;
    static unsigned long   _sftp_fl_bytes;

    static unsigned long  _fw_ok_num;
    static unsigned long  _fw_all_bytes;
    static unsigned long  _fw_err_num;
    
    static unsigned long  _sftp_ok_num;
    static unsigned long  _sftp_err_num;
    static unsigned long  _sftp_all_cost;
    static unsigned long  _sftp_all_bytes;
    static unsigned long  _sftp_conn_re;


    Timestamp             _file_name_time;
    std::string           _kpi_time;

private:
    uint8 _hasHead;
};
#endif /* __PERFORM_STATS_HXX__ */


