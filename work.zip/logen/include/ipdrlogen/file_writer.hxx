//
// Created by 10209409 on 3/20/2017.
//

#ifndef __FILE_WRITER_HXX__
#define __FILE_WRITER_HXX__

#include <cub/base_types.hxx>
#include <Poco/DeflatingStream.h>
#include <Poco/FileStream.h>
#include <Poco/Timestamp.h>
#include <Poco/Runnable.h>
#include <Poco/Timer.h>
#include <chrono>
#include <fstream>
#include "ipdrlogen/LoopQueue.h"
#include <ipdrlogen/queue.hxx>

using Poco::DeflatingOutputStream;
using Poco::DeflatingStreamBuf;
using Poco::FileStream;
using Poco::FileOutputStream;
using Poco::Timestamp;
using Poco::Runnable;
using Poco::Timer;
using Poco::FastMutex;
using std::chrono::high_resolution_clock;

class FileWriter : public Runnable
{
    const std::string XDR_FILE_PREFIX         = "xdr/.temp.";
    const std::string SERVICE_TYPE_NAT_LOG    = "15";
    const std::string SERVICE_TYPE_ACCESS_LOG = "14";
    const std::string SERVICE_TYPE_LINE_LOG   = "13";
    const std::string SERVICE_TYPE_KEYWORD_FILTER_LOG   = "16";
    const std::string SERVICE_TYPE_FILE_LIST_LOG   = "17";
    const int COUNTER_WIDTH                   = 12;
    const std::string NAME_DATE_FORMAT        = "%Y%m%d%H%M%S";
    std::string boce_tel = app_config.getString(USER_ACCOUNT_BOCE_TEL, "18805318929");
    
public:
    enum
    {
        WRITE_ACCESS_LOG    = 0,
        WRITE_NAT_LOG
    };

    FileWriter(uint32                            switch_interval,
                LoopQueue<IPDRMessage*>&  queue,
               uint32 max_entry_num,    std::string& device_id, uint16&  is_stop, 
                uint16 &log_type, uint16 &_is_create_file, uint8 svrNo);

    virtual ~FileWriter();
    
    virtual void run();
    
    void on_timer(Timer& timer);

private:
    void switch_file(bool create = true);

    std::string get_file_name();

    std::string md5sum(const std::string& path);


    inline uint64 file_size(const std::string& path);

    std::string                        _path;
    DeflatingOutputStream*             _gz_stream;
    FileStream                         _stream;
    Timestamp                          _create_time;
    Timestamp                          _close_time;
    Timer                              _timer;
    FastMutex                          _mutex;
    uint16                             _log_type;
    uint16&                            _is_gen_file;
    LoopQueue<IPDRMessage*>&           _queue;
    uint32                             _entry_count;
    uint32                             _max_entry_num;
    std::string                        _device_id;
    uint16&                            _is_stop;
    uint32                             _switch_time_up;
    std::string                        _name_delimiter;
    std::string                        _remote_path;
    std::vector<tIpdrFilterContext*>   _filter_context;
    filter_set                         _msisdn_set;
    filter_set                         _url_set;
    std::vector<Filter>                _msdn_vec;
    std::vector<Filter>                _url_vec;
    time_t                             _filter_version;
    uint8                              _serverNoFL;
    uint64                             _file_count;
    bool                               _filter_start;
    uint8                              _srvNo;
    std::string                        _filename;
    uint16                             _boce_flag;
};

#endif /* __FILE_WRITER_HXX__ */
