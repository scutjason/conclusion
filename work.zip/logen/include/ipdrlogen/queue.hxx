//
// Created by 10209409 on 3/21/2017.
//

#ifndef __QUEUE_HXX__
#define __QUEUE_HXX__

#include <concurrentqueue/concurrentqueue.h>
#include <ipdrlogen/interface_message.hxx>
#include <ipdrlogen/protocol.hxx>
#include <Poco/SingletonHolder.h>
#include <ipdrlogen/LoopQueue.h>
#include <vector>

using moodycamel::ConcurrentQueue;
using Poco::SingletonHolder;


class IFQueryQueue                                                
{                                                          
public:                                                   
     IFQueryQueue()                                            
    {                                                      
    };                                                     
    ~IFQueryQueue()                                               
    {                                                      
    };                                                                                                       
public:                                                   
    static LoopQueue<IFNotify*>    Instance;                    
};


class SFTPUploadQueue                                                
{                                                          
public:                                                   
     SFTPUploadQueue()                                            
    {                                                      
    };                                                     
    ~SFTPUploadQueue()                                               
    {                                                      
    };                                                  
public:                                                   
    static LoopQueue<UploadInfo*>    Instance;                    
};



class FILElistQueue                                                
{                                                          
public:                                                   
     FILElistQueue()                                            
    {                                                      
    };                                                     
    ~FILElistQueue()                                               
    {                                                      
    };                                                                                                 
    static LoopQueue<IPDRMessage*>    Instance;
    static std::vector<LoopQueue<IPDRMessage*> *>ins;
};



class ACCOUNTMonitorQueue                                                
{                                                          
public:                                                   
     ACCOUNTMonitorQueue()                                            
    {                                                      
    };                                                     
    ~ACCOUNTMonitorQueue()                                               
    {                                                      
    };                                                     
                                                 
    static LoopQueue<IPDRXDRSession*>    Instance;                    
};




class KEYWORDfilterFWQueue                                                
{                                                          
public:                                                   
     KEYWORDfilterFWQueue()                                            
    {                                                      
    };                                                     
    ~KEYWORDfilterFWQueue()                                               
    {                                                      
    };                                                                                                        
                                                 
    static LoopQueue<IPDRMessage*>    Instance;
    static std::vector<LoopQueue<IPDRMessage*> *>ins;
};



class KEYWORDfilterContextQueue                                                
{                                                          
public:                                                   
     KEYWORDfilterContextQueue()                                            
    {                                                      
    };                                                     
    ~KEYWORDfilterContextQueue()                                               
    {                                                      
    };                                                                                                
    static LoopQueue<tIpdrFilterContext*>    Instance;                    
};



#endif /* __QUEUE_HXX__ */
