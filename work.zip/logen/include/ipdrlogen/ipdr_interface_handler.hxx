//
// Created by 10209409 on 2/22/2017.
//

#ifndef __IPDR_INTERFACE_HANDLER_HXX__
#define __IPDR_INTERFACE_HANDLER_HXX__

#include <cub/base_types.hxx>
#include <ipdrlogen/interface_message.hxx>
#include <Poco/Net/HTTPRequest.h>
#include <Poco/Net/HTTPRequestHandler.h>
#include <Poco/Net/HTTPRequestHandlerFactory.h>
#include <Poco/Net/HTTPResponse.h>
#include <Poco/Net/HTTPServerResponse.h>
#include <Poco/Net/HTTPServerRequest.h>
#include <map>
#include <Poco/Mutex.h>
#include <ipdrlogen/protocol.hxx>
#include <Poco/Thread.h>
#include <ipdrlogen/LoopQueue.h>
#include <ipdrlogen/http_client.hxx>
#include <Poco/Thread.h>
#include <ipdrlogen/file_writer.hxx>
#include <vector>

using Poco::Net::HTTPRequest;
using Poco::Net::HTTPRequestHandler;
using Poco::Net::HTTPRequestHandlerFactory;
using Poco::Net::HTTPResponse;
using Poco::Net::HTTPServerResponse;
using Poco::Net::HTTPServerRequest;
using Poco::Runnable;
using Poco::Thread;
using Poco::ThreadPool;

typedef std::map<std::string, AccountMonitor *> tMonitorMap;
extern tMonitorMap monitor_terms;
extern Poco::FastMutex g_mutex;
extern time_t   monitor_version;


extern time_t filter_version;
extern Poco::FastMutex g_filter_mutex;
extern filter_set g_filter_msisdn;
extern filter_set g_filter_url;

class FilterContext:public Runnable
{

    uint32 switch_interval  = app_config.getUInt(LOGEN_FILTERFILE_SWITCH_INTERVAL, 15 * 60);
    
    uint32 filter_entries   = app_config.getUInt(LOGEN_FILTERFILE_ENTRIES, 100);
    
    std::string device_id = app_config.getString(LOGEN_FILE_DEVICE_ID,
                            DEFAULT_DEVICE_ID);

public:
    FilterContext(LoopQueue<tIpdrFilterContext*> &context_queue, uint8 num);

    virtual ~FilterContext();

    virtual void run();
private:
    LoopQueue<tIpdrFilterContext*> &_context_queue;
    filter_set                         _msisdn_set;
    filter_set                         _url_set;
    std::vector<Filter>                _msdn_vec;
    std::vector<Filter>                _url_vec;
    time_t                             _filter_version;
    
    ThreadPool                         _filter_thread_pool;

    uint16                             _isStop;
    bool                               _filter_start ;
    bool                               _thread_start;
    uint8                              _sftp_server_nums;
    std::vector <FileWriter*>          _filter_workers;

};


class MoniorHandle: public Runnable
{
    uint32 line_version = app_config.getUInt(USER_ACCOUNT_LINE_VERSION, 1);
public:


    MoniorHandle(LoopQueue<IPDRXDRSession*> &upload_queue);

    virtual ~MoniorHandle();

    virtual void run();

    std::string write_body(IPDRXDRSession* entry, std::string& account_info)
    {
        //std::ostream& res;
        std::stringstream res;
        
        res << "{" << std::endl;
        
        res << "    \"info_id\"   : \"" << account_info<< "\"," << std::endl;
        
        res << "    \"account\"   : \"" << entry->msisdn<< "\"," << std::endl;
        
        res << "    \"accountType\" : \"" << "2" << "\"," << std::endl;
        
        res << "    \"loginType\"  : \"" << "2" << "\","<< std::endl;
        if(line_version == 1)
        {
            res << "    \"onlineTime\" : \"" << entry->btime <<  "\","<< std::endl;
        }
        else
        {
            res << "    \"onlineTime\" : \"" << entry->procedure_start_time <<  "\","<< std::endl;
        }

        res << "    \"priIpv4\" : \"" << get_ip(entry->user_ip, false) <<  "\"," << std::endl;
            
        res << "    \"pubIpv4\" : \"" << get_ip(entry->pub_ip, false) <<  "\"," << std::endl;
            
        res << "    \"pubIpv6\"    : \"" << get_ip(entry->pub_ip, true) << "\"," << std::endl;
            
        res << "    \"LAC\" : \"" << entry->lac <<  "\"," << std::endl;
            
        res << "    \"CI\"  : \"" << entry->ci << "\"" << std::endl; 
            
        res << "}" << std::endl;

        return res.str();
    }
private:
    LoopQueue<IPDRXDRSession*>&     _upload_queue;
    HTTPClient         httpClient;
};



class IPDRInterfaceHandler: public HTTPRequestHandler
{
    const uint32 Succeed                = 1;
    const uint32 Failed                 = 2;
    const std::string empty             = "";
    std::string monitor_result          = "monitor_result";
    std::string filter_result           = "filter_result";
    std::string FILE_NOT_EXIST          = "File not exist";
    std::string TIME_EXCEED_THREE_DAYS  = "Time range is large than 72 hours";
    std::string TIME_ERROR              = "start time beyonds end time";
    std::string RULE_ERROR              = "No match rules for re-transfer";
    const uint32 filter_num             = app_config.getUInt(LOGEN_FILTERFILE_CONDITION_NUM, 10);
    const uint32 account_num            = app_config.getUInt(LOGEN_ACCOUNT_MONITOR_CONDITION_NUM, 10);
public:
    IPDRInterfaceHandler();

    virtual ~IPDRInterfaceHandler();

    void handleRequest(HTTPServerRequest& request, HTTPServerResponse& response);

private:

    inline void send_status(HTTPServerResponse & response,
                            HTTPResponse::HTTPStatus status)
    {
        response.setStatusAndReason(status);
        response.send();
    }

    inline void send_forbidden(HTTPServerResponse & response)
    {
        response.setStatusAndReason(HTTPResponse::HTTP_FORBIDDEN);
        response.send();
    };

    inline void send_ok(HTTPServerResponse & response)
    {
        response.setStatusAndReason(HTTPResponse::HTTP_OK);
        response.send();
    };

    void send_action_result(HTTPServerResponse & response, bool success,
                            std::string& account_info, std::string& type);

    void send_re_transfer_process_result(HTTPServerResponse & response,
                                         bool success,
                                         const std::string& fail_reason);

    bool process_re_transfer(FileReTransfer& fileReTransfer,
                             std::string& fail_reason);
                             
    std::string         _remote_path;

};

class IPDRInterfaceHandlerFactory: public HTTPRequestHandlerFactory
{
public:
    IPDRInterfaceHandlerFactory()
    {
    }

    HTTPRequestHandler* createRequestHandler(const HTTPServerRequest& request)
    {
        return new IPDRInterfaceHandler;
    }
};
#endif /* __IPDR_INTERFACE_HANDLER_HXX__ */
