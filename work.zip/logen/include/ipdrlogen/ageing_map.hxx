
typedef bool (*t_ageing_callback)(void *data, void *arg);

template <class _Kty, class _Ty> class ageing_map
{
public:
    class htraits_hash : public __gnu_cxx::hash<_Kty>
    {
    public:
        size_t operator()(const _Kty &key) const
        {
            char *val = (char *)key.c_str();
            size_t size = key.size();
            size_t hval = 2654435761U;
            size_t i = 0;

            for (; i + 4 <= size; i += 4, val += 4)
                hval = hval * 1000003 ^ *(unsigned*)val;
            for (; i < size; ++i, val += 1)
                hval = hval * 1000003 ^ *val;

            return hval;
        }
    };

    class htraits_equal : public __gnu_cxx::equal_to<_Kty>
    {
    public:
        bool operator()(const _Kty &key1, const _Kty &key2) const
        {  
            return (key1 == key2);
        }
    };

    typedef struct __tag_lru_node
    {
        __tag_lru_node *lru_prev;
        __tag_lru_node *lru_next;
    } lru_node;

    typedef struct __tag_data_node
    {
        lru_node lru;
        unsigned int timestamp;
        _Kty key;
        _Ty* value;
    }data_node;
    #if 0
    typedef __gnu_cxx::hash_map<_Kty, data_node*, htraits_hash, htraits_equal> HASH_MAP;
    typedef typename HASH_MAP::iterator iterator;
    typedef typename HASH_MAP::value_type value_type;
    #else
    typedef std::map<_Kty, data_node*> HASH_MAP;
    typedef typename HASH_MAP::iterator iterator;
    typedef typename HASH_MAP::value_type value_type;
    #endif

    ageing_map(unsigned int capacity, unsigned int ageing, t_ageing_callback cb = NULL, void *cb_arg = NULL) :
        _capacity(capacity), _ageing(ageing), _cb(cb), _cb_arg(cb_arg)
    {
        _lru_head.lru_prev = _lru_head.lru_next = NULL;
        _lru_rear_ptr = &_lru_head;
    }

    ~ageing_map()
    {
        _lru_head.lru_prev = _lru_head.lru_next = NULL;
        _lru_rear_ptr = &_lru_head;
        for(iterator it = _nodes.begin(); it != _nodes.end(); ++it)
        {
            delete it->second->value;
            delete it->second;
        }
        _nodes.clear();
    }

    bool insert(const _Kty &key, _Ty *value)
    {
        unsigned int now = time(NULL);

        // If the map is full, ageing the oldest.
        _force_ageing(now);

        data_node *node = new data_node;

        node->lru.lru_prev  = NULL;
        node->lru.lru_next  = NULL;
        node->timestamp = now;
        node->key       = key;
        node->value     = value;
        pair<iterator, bool> result = _nodes.insert(value_type(key, node));
        if(!result.second)
        {
            // The node with the same key has already exists, and delete the old node.
            _lru_pop((lru_node *)result.first->second);
            if(_cb == NULL || !(*_cb)(result.first->second->value, _cb_arg))
            {
                delete result.first->second->value;
            }
            delete result.first->second;
            result.first->second = node;
        }
        _lru_push((lru_node *)node);
        return true;
    }

    bool find(const _Kty &key, _Ty *&value, bool reset_ageing = true)
    {
        iterator it = _nodes.find(key);
        if(it == _nodes.end())
        {
            return false;
        }

		if(reset_ageing)
		{
            _lru_pop((lru_node*)it->second);
            _lru_push((lru_node *)it->second);
		}
        value = it->second->value;
        return true;
    }
	
	bool reset_ageing(const _Kty &key)
    {
        iterator it = _nodes.find(key);
        if(it == _nodes.end())
        {
            return false;
        }

        _lru_pop((lru_node*)it->second);
        _lru_push((lru_node *)it->second);
        return true;
    }

    // only erase the node from map, and don't free user's data space.
    bool erase(const _Kty &key)
    {
        iterator it = _nodes.find(key);
        if(it != _nodes.end())
        {
            _lru_pop((lru_node *)it->second);
            delete it->second;
            _nodes.erase(it);
            return true;
        }
        return false;
    }

    bool destory(const _Kty &key)
    {
        iterator it = _nodes.find(key);
        if(it != _nodes.end())
        {
            _lru_pop((lru_node *)it->second);
            delete it->second->value;
            delete it->second;
            _nodes.erase(it);
            return true;
        }
        return false;
    }

    unsigned int size()
    {
        return _nodes.size();
    }
	
	// active ageing by external caller
    void do_ageing(time_t now)
	{
	    while(_lru_rear_ptr != &_lru_head)
        {
            data_node *node = (data_node *)_lru_rear_ptr;
            if((now <= node->timestamp || now - node->timestamp < _ageing))
                break;
            
            _lru_pop(_lru_rear_ptr);
            _nodes.erase(node->key);
            if(_cb == NULL || !(*_cb)(node->value, _cb_arg))
            {
                delete node->value;
            }
            delete node;
        }
	}
	
    void reset_timestamp(const _Kty &key)
    {
        unsigned int now = time(NULL);
        iterator it = _nodes.find(key);

        if(it != _nodes.end())
        {
             it->second->timestamp = now;
            _lru_pop((lru_node*)it->second);
            _lru_push((lru_node *)it->second);
        }
    }

private:
    bool _lru_push(lru_node *node)
    {         
        if(node != NULL)  
        {                                 
            node->lru_next = _lru_head.lru_next;      
            if(_lru_head.lru_next != NULL)        
            {                             
                _lru_head.lru_next->lru_prev = node;  
            }                             
            _lru_head.lru_next = node;            
            node->lru_prev = &_lru_head;   

            if(&_lru_head == _lru_rear_ptr)
            {
                _lru_rear_ptr = node;
            }
            return true;
        }
        return false;
    }                                     

    bool _lru_pop(lru_node *node)
    {                                           
        if(node != NULL && node->lru_prev != NULL)  
        {                                 
            if(node == _lru_rear_ptr)
            {
                _lru_rear_ptr = node->lru_prev;
            }

            node->lru_prev->lru_next = node->lru_next;      
            if(node->lru_next != NULL)              
            {                                   
                node->lru_next->lru_prev = node->lru_prev;  
            }
            node->lru_prev = NULL;
            node->lru_next = NULL;
            return true;
        }
        return false;
    } 

	// force ageing, when the size of the map reaches the capacity.
    void _force_ageing(unsigned int now)
    {
	    if(_nodes.size() < _capacity)
		    return;
			
	    do_ageing(now);
		
        while(_lru_rear_ptr != &_lru_head && _nodes.size() >= _capacity)
        {
            data_node *node = (data_node *)_lru_rear_ptr;
            
            _lru_pop(_lru_rear_ptr);
            _nodes.erase(node->key);
			// TODO 
            // if(_cb == NULL || !(*_cb)(node->value, _cb_arg))
            {
                delete node->value;
            }
            delete node;
        }
    }

private:
    HASH_MAP _nodes;
    lru_node  _lru_head;
    lru_node *_lru_rear_ptr;
    unsigned int  _capacity;
    unsigned int  _ageing;
    t_ageing_callback _cb;
	void * _cb_arg;
};
