//
// Created by 10209409 on 3/21/2017.
//

#ifndef __NORTH_FACE_HXX__
#define __NORTH_FACE_HXX__

#include <ipdrlogen/http_client.hxx>
#include <ipdrlogen/ftp_client.hxx>
#include <ipdrlogen/interface_message.hxx>
#include <ipdrlogen/sftp_worker.hxx>
#include <ipdrlogen/common.hxx>
#include <ipdrlogen/configuration.hxx>
#include <Poco/Runnable.h>

using Poco::Runnable;

class NorthFace : public  Runnable
{
    const std::string  FTP_URL_SCHEME   = "ftp://";
    const uint16       FTP_PORT         = 21;
    const std::string  SFTP_URL_SCHEME   = "sftp://";
    const uint16       SFTP_PORT         = 22;
    const std::string  LOCAL_TEMP       = "temp/";
    std::string upload_protocol = app_config.getString(NORTH_UPLOAD_PROTOCOL,
                                        DEFAULT_NORTH_UPLOAD_PROTOCOL);
public:
    NorthFace(const std::string& server, uint16 port,
              const std::string& user, const std::string& password,
              const std::string& remote_path);

    ~NorthFace();

    virtual void run();

private:
    bool send_notification(bool success, IFNotify * notify,
                           std::string& remote_path);

private:
    HTTPClient         httpClient;
    FTPClient          ftpClient;
    SFTPClient         sftpClient;
    std::string        _remote_path;

};

#endif /* __NORTH_FACE_HXX__ */
