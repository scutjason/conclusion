//
// Created by 10209409 on 3/21/2017.
//

#ifndef __INTERFACE_MESSAGE_HXX__
#define __INTERFACE_MESSAGE_HXX__

#include <cub/base.hxx>
#include <cub/base_types.hxx>
#include <cub/circular_queue.hxx>
#include <Poco/AutoPtr.h>
#include <vector>
#include <string.h>
/*用户监测字段结构*/
class AccountMonitor
{
private:
    std::string            _id; /*                               */
    std::string          _type; /*                               */
    std::string       _account; /* 用户上网账号或手机号             */
    uint8        _account_type; /* 数字    1:固网账号    2:移动账号 */
    uint8        _monitor_type; /* 操作类型 1:开始监测   2:停止监测  */
    std::string    _notify_url;

public:
    bool            _isUpload;

    const std::string& get_id()
    {
        return _id;
    }

    void set_id( std::string& id)
    {
        _id = id;
    }

    const std::string& get_type()
    {
        return _type;
    }

    void set_type( std::string& type)
    {
        _type = type;
    }

    const std::string& get_account()
    {
        return _account;
    }

    void set_account( std::string& account)
    {
        _account = account;
    }

    uint8 get_account_type()
    {
        return _account_type;
    }

    void set_account_type(uint8 account_type)
    {
        _account_type = account_type;
    }

    uint8 get_monitor_type()
    {
        return _monitor_type;
    }

    void set_monitor_type(uint8 monitor_type)
    {
        _monitor_type = monitor_type;
    }

    const std::string& get_notify_url()
    {
        return _notify_url;
    }

    void set_notify_url( std::string& notify_url)
    {
        _notify_url = notify_url;
    }
};


/*特定账号或关键词过滤*/
class Filter
{
private:
    std::string           _id;
    std::string         _type; /* filter 操作 如:请求            */
    std::string        _field; /* 需要过滤的手机号码或url         */
    uint8         _field_type; /* 数字 1:手机号      2:url关键词  */
    uint8        _filter_type; /* 操作类型 1:开始过滤   2:停止过滤 */    
public:
    
    const std::string&  get_id()
    {
        return _id;
    }

    void set_id(std::string& id)
    {
        _id = id;
    }

    const std::string&  get_type()
    {
        return _type;
    }

    void set_type(std::string& type)
    {
        _type = type;
    }

    const std::string&  get_field()
    {
        return _field;
    }

    void set_field(std::string& field)
    {
        _field = field;
    }

    uint8  get_field_type()
    {
        return _field_type;
    }

    void set_field_type(uint8 field_type)
    {
        _field_type = field_type;
    }

    uint8  get_filter_type()
    {
        return _filter_type;
    }

    void set_filter_type(uint8 filter_type)
    {
        _filter_type = filter_type;
    }
};

enum
{
    FILTER_FIELD_TYPE_MSISDN    = 1,
    FILTER_FIELD_TYPE_URL
};

enum
{
    FILTER_ACTION_START         = 1,
    FILTER_ACTION_STOP
};

class filter_set
{
public:
    std::vector<Filter> filter_items;

public:

    bool find_match(std::string &str, std::string &out)
    {
        int i;
        bool ret = false;
        Filter flter;
        int size = filter_items.size();
        for(i = 0; i < size; i++)
        {
            flter = filter_items[i]; 
            if(flter.get_field()== str)
            {
                ret =  true;
                out = flter.get_id();
                break;
            }
        }
        return ret;
    }

    bool find_substring(std::string &str, std::string &out)
    {
        int i;
        bool ret = false;
        Filter flter;
        int size = filter_items.size();

        for(i = 0; i < size; i++)
        {
            flter = filter_items[i]; 
            std::string field = flter.get_field();
            if(strstr(str.c_str(), field.c_str()))
            {
                ret =  true;   
                out = flter.get_id();
                break;
            }
        }
        return ret;
    }

};

/*特定账号或关键词过滤*/
class FileReTransfer
{
private:
    std::string          _id;
    std::string        _type; /* 信息重传类型如: query_request */
    std::string   _file_name;
    uint64       _begin_time;
    uint64         _end_time;
    uint8        _match_type;

public:
    const std::string & get_id()
    {
        return _id;
    }

    void set_id(std::string & id)
    {
        _id = id;
    }

    const std::string & get_type()
    {
        return _type;
    }

    void set_type(std::string & type)
    {
        _type = type;
    }

    const std::string & get_file_name()
    {
        return _file_name;
    }

    void set_file_name(std::string & file_name)
    {
        _file_name = file_name;
    }

    uint64 get_begin_time()
    {
        return _begin_time;
    }

    void set_begin_time(uint64 begin_time)
    {
        _begin_time = begin_time;
    }

    uint64 get_end_time()
    {
        return _end_time;
    }

    void set_end_time(uint64 end_time)
    {
        _end_time = end_time;
    }

    uint8 get_match_type()
    {
        return _match_type;
    }

    void set_match_type(uint8 match_type)
    {
        _match_type = match_type;
    }
};

enum
{
    FILE_MATCH_NAME,
    FILE_MATCH_TIME
};

class IFNotify
{
private:
    /*北向接口字段*/
    std::string     _event_id;
    std::string     _notify_url;
    std::string     _zip_url;
    uint8           _result;

public:

    void set_event_id(const std::string& event_id)
    {
        _event_id = event_id;
    }

    const std::string& get_event_id()
    {
        return _event_id;
    }

    void set_notify_url(const std::string& url)
    {
        _notify_url = url;
    }

    const std::string& get_notify_url()
    {
        return _notify_url;
    }
    void set_zip_url(const std::string& url)
    {
        _zip_url = url;
    }

    const std::string& get_zip_url()
    {
        return _zip_url;
    }

    void set_result(uint8 result)
    {
        _result = 0;
    }

    uint8 get_result()
    {
        return  _result;
    }
} ;

class UploadInfo
{
    std::string        _local_file;
    std::string        _remote_path;
    std::string        _fileMd5;
    uint64             _fileNum;

public:
    uint8              _serverNo;
    
    const std::string& get_local_file()
    {
        return _local_file;
    }

    void set_local_file(const std::string& local_file)
    {
        _local_file = local_file;
    }

    const std::string& get_remote_path()
    {
        return _remote_path;
    }

    const std::string& get_file_md5()
    {
        return _fileMd5;
    }

    uint64 get_file_num()
    {
        return _fileNum;
    }

    void set_remote_path(std::string& remote_path)
    {
        _remote_path = remote_path;
    }
    
    void set_file_md5(std::string& md5)
    {
        _fileMd5 = md5;
    }

    void set_file_num(uint64 num)
    {
        _fileNum = num;
    }
};
#endif /* __INTERFACE_MESSAGE_HXX__ */
