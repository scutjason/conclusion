//
// Created by 10209409 on 3/17/2017.
//

#ifndef __FTP_CLIENT_HXX_
#define __FTP_CLIENT_HXX_

#include <cub/base_types.hxx>
#include <cub/noncopyable.hxx>
#include <Poco/Net/FTPClientSession.h>

using cub::noncopyable;
using Poco::Net::FTPClientSession;

class FTPClient : public noncopyable
{
    enum
    {
        FTP_PORT = 21
    };

public:
    FTPClient(const std::string& remote, const std::string& username,
              const std::string& password);

    FTPClient(const std::string& remote, uint16 port, const std::string& username,
              const std::string& password);
    ~FTPClient();

    bool put(const std::string& local_path,
             const std::string& remote_path);

    bool put(const std::string& local_path,
             const std::string& remote_dir,
             const std::string& remote_filename);

    bool get(const std::string& remote_path,
             const std::string& local_path);

    std::string to_string();

    std::string& get_host()
    {
        return _remote;
    }

    uint16 get_port()
    {
        return _port;
    }

private:
    void close();

private:
    FTPClientSession*     ftpClientSession;
    std::string                   _remote;
    uint16                          _port;
    std::string                 _username;
    std::string                 _password;
};

#endif /* __FTP_CLIENT_HXX_ */
