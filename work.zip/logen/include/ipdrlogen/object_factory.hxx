//
// Created by 10209409 on 3/21/2017.
//

#ifndef __OBJECT_FACTORY_HXX__
#define __OBJECT_FACTORY_HXX__
#include <Poco/Mutex.h>
#include <Poco/ObjectPool.h>
using cub::circular_queue;
using Poco::ObjectPool;

static Poco::SingletonHolder<IPDRLogFactory> holder;

template <typename T>
class IPDRLogFactory
{
public:
    IPDRLogFactory();
    ~IPDRLogFactory()
    {
    };

    T& borrow()
    {
    }
    static IPDRLogFactory& Instance()
    {
        return *holder.get();
    }

private:

};
#endif /* __OBJECT_FACTORY_HXX__ */
