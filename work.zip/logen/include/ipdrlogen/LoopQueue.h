#ifndef __LOOPQUEUE_H__
#define __LOOPQUEUE_H__

#include "ipdrlogen/Feature.h"

template<typename T>
class LoopQueueElement 
{
public:
    LoopQueueElement() : is_used(0)
    {
    }

    volatile long is_used;
    T data;
};

// �������ζ���
template<typename T>
class LoopQueue 
{
public:
    LoopQueue(long max = 0x200000) : _head(0), _tail(1), _queue_sz(max), _pending(0) 
    {
        _queue = new LoopQueueElement<T>[max];
    }

    ~LoopQueue() 
    {
        delete []_queue;
    }

    bool try_dequeue(T & t) 
    {
        long h_snapshot(_head);                    // ȡ��head�Ŀ���
        long new_h = (h_snapshot + 1) % _queue_sz; // �����µ�head

        if(mm_slow(new_h == _tail))
        {
            // ���п�
            return false;
        }

        while(__interlocked_compare_exchange(&_head, new_h, h_snapshot) != h_snapshot) 
        {
            // �������߳̾����޸�head
            h_snapshot = _head;
            new_h = (h_snapshot+1) % _queue_sz;
            if(mm_slow(new_h == _tail))
            {
                // ���п�
                return false;
            }
        }
        while(!_queue[new_h].is_used);
        t = _queue[new_h].data;
        __interlocked_exchange(&_queue[new_h].is_used,0);
        __interlocked_add_exchange(&_pending, -1);
        return true;
    }

    bool enqueue(const T& t) 
    {
        long t_snapshot(_tail);                    // ȡ��tail�Ŀ���
        long new_t = (t_snapshot + 1) % _queue_sz; // �����µ�tail

        if(mm_slow(new_t == _head))
        {
            // ������
            return false;
        }
        while(__interlocked_compare_exchange(&_tail, new_t, t_snapshot) != t_snapshot) 
        {
            // �������߳̾����޸�tail
            t_snapshot = _tail;
            new_t = (t_snapshot + 1) % _queue_sz;
            if(mm_slow(new_t == _head)) 
            {
                // ������
                return false;
            }
        }
        while(_queue[t_snapshot].is_used);
        _queue[t_snapshot].data = t;
        __interlocked_exchange(&_queue[t_snapshot].is_used,1);
        __interlocked_add_exchange(&_pending, 1);
        return true;
    }

    int pending() 
    {
        return _pending;
    }

private:
    LoopQueueElement<T> * _queue;
    volatile long _head, _tail, _queue_sz;
    volatile int _pending;
};

#endif // __LOOPQUEUE_H__
