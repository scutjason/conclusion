//
// Created by 10209409 on 3/20/2017.
//

#ifndef __HTTP_CLIENT_HXX__
#define __HTTP_CLIENT_HXX__

#include <cub/noncopyable.hxx>
#include <Poco/Net/HTTPClientSession.h>
#include <Poco/URI.h>

using cub::noncopyable;
using Poco::URI;


class HTTPClient : public noncopyable
{
public:
    HTTPClient();
    ~HTTPClient();

    bool post(std::string& local_path);

    //bool post(std::istream& in);

    bool get(const std::string& out_file);

    bool get(std::ostream& out);

    bool  set_uri(const std::string& uri);

    std::string & get_url()
    {
        return _url;
    }

private:
    URI                      _uri;
    std::string              _url;
    bool                     _reg;
};
#endif /* __HTTP_CLIENT_HXX__ */
