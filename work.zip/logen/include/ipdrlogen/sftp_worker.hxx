//
// Created by 10209409 on 3/22/2017.
//

#ifndef __SFTP_WORKER_HXX__
#define __SFTP_WORKER_HXX__

#include <ipdrlogen/sftp_client.hxx>
#include <Poco/Runnable.h>
#include <vector>

using Poco::Runnable;

class SFTPWorker : public Runnable
{
    const std::string NAME_DATE_FORMAT        = "%Y-%m-%d %H:%M:%S";

public:
    SFTPWorker(std::string& sftp_server,  std::string& sftp_port,
               std::string& sftp_user,std::string& sftp_password);
    std::string get_remote_path(std::string type, uint8 srvNo, bool isReload);
    virtual ~SFTPWorker();
    virtual void run();

private:
    std::vector<SFTPClient *> sftpClient;
    uint8                     _sever_num;
    std::string               _line_remote_path;
    std::string               _access_remote_path;
    std::string               _nat_remote_path;
    std::string               _fl_remote_path;
    std::string               _kf_remote_path;
    std::string               _re_line_remote_path;
    std::string               _re_access_remote_path;
    std::string               _re_nat_remote_path;
    std::string               _re_fl_remote_path;
    std::string               _re_kf_remote_path;
};
#endif /* __SFTP_WORKER_HXX__ */
