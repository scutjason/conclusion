#ifndef __FEATURE_H__
#define __FEATURE_H__

#ifndef _WIN32
#include <unistd.h>
#include <sys/vfs.h>
#include <sched.h>
#include<sys/types.h>
#include<sys/wait.h>
#else
#include <winsock2.h>
#include <windows.h>
#endif

#if defined __GNUC__ || defined __llvm__
#define mm_fast(x) __builtin_expect ((x), 1)
#define mm_slow(x) __builtin_expect ((x), 0)
#else
#define mm_fast(x) (x)
#define mm_slow(x) (x)
#endif

inline long __interlocked_exchange(volatile long* target,long new_value) {
#ifdef _WIN32
	return InterlockedExchange(target,new_value);
#else
	return __sync_lock_test_and_set(target,new_value);
#endif
}

inline long long __interlocked_exchange64(volatile long long* target, long long new_value) {
#ifdef _WIN32
	return (long long)InterlockedExchangePointer(target,new_value);
#else
	return __sync_lock_test_and_set(target,new_value);
#endif
}

inline long long __interlocked_compare_exchange64(volatile long long* target, long long new_value, long long comparand) {
#ifdef _WIN32
	return (long long)InterlockedCompareExchangePointer((void **)target,(void *)new_value,(void *)comparand);
#else
	return __sync_val_compare_and_swap(target,comparand,new_value);
#endif
}

inline long __interlocked_compare_exchange(volatile long* target,long new_value,long comparand) {
#ifdef _WIN32
	return InterlockedCompareExchange(target,new_value,comparand);
#else
	return __sync_val_compare_and_swap(target,comparand,new_value);
#endif
}

inline int __interlocked_add_exchange(volatile unsigned int* target,unsigned int plus_value) {
#ifdef _WIN32
	return (InterlockedExchangeAdd((volatile long*)target,plus_value) + plus_value);
#else
	return __sync_add_and_fetch(target,plus_value);
#endif
}

inline unsigned long __interlocked_add_exchange64(volatile unsigned long* target,unsigned long plus_value) {
#ifdef _WIN32
	return (InterlockedExchangeAdd((volatile long*)target,plus_value) + plus_value);
#else
	return __sync_add_and_fetch((volatile unsigned long*)target,plus_value);
#endif
}

inline int __interlocked_add_exchange(volatile int* target,int plus_value) {
#ifdef _WIN32
	return (InterlockedExchangeAdd((volatile long*)target,plus_value) + plus_value);
#else
	return __sync_add_and_fetch(target,plus_value);
#endif
}

#endif // __FEATURE_H__
