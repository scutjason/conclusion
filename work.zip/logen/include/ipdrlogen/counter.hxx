//
// Created by 10209409 on 3/30/2017.
//

#ifndef __COUNTER_HXX__
#define __COUNTER_HXX__

#include <cub/base_types.hxx>
#include <Poco/SingletonHolder.h>
#include <string>
#include <atomic>
#include <vector>

using Poco::SingletonHolder;

class Counter;
static SingletonHolder<Counter> counter_holder;
class Counter
{
    const uint64 counter_min         = 1l;
    const uint64 counter_max         = 999999999999l;
    const std::string counter_file   = ".counter";
public:
    Counter() : _counter(counter_min)
    {
    };

    ~Counter()
    {
    };

    int write_counter();


    int read_counter();

    uint64 get()
    {
        uint64 value = _counter.fetch_add(1, std::memory_order_relaxed);

        if (value == counter_max)
        {
            _counter.exchange(counter_min, std::memory_order_relaxed);
        }

        return value;
    }

    static Counter& Instance()
    {
        return *counter_holder.get();
    }
private:
    std::atomic<uint64>    _counter;
};

// file_list count
class CounterFL                                                
{      
    const uint64 counter_min         = 1l;
    const uint64 counter_max         = 999999999990l;
    const std::string counter_file   = ".counter";

public:                                                   
     CounterFL()                                            
    {                                                      
    };  
    
    ~CounterFL()                                               
    {                                                      
    };
    
    uint64 get(std::atomic<uint64> *_counter, uint8 min)
    {
        uint64 value = _counter->fetch_add(num, std::memory_order_relaxed);

        if (value >= counter_max)
        {
            _counter->exchange(min, std::memory_order_relaxed);
        }

        return value;
    }
public:                                                   
    static std::vector<std::atomic<uint64>*>ins;
    static uint8   num;
};

// keywork_filter count
class CounterKF                                                
{      
    const uint64 counter_min         = 1l;
    const uint64 counter_max         = 999999999990l;
    const std::string counter_file   = ".counter";

public:                                                   
     CounterKF()                                            
    {                                                      
    }; 
    
    ~CounterKF ()                                               
    {                                                      
    }; 

    uint64 get(std::atomic<uint64> *_counter, uint8 min)
    {
        uint64 value = _counter->fetch_add(num, std::memory_order_relaxed);

        if (value >= counter_max)
        {
            _counter->exchange(min, std::memory_order_relaxed);
        }

        return value;
    }
public:                                                   
    static std::vector<std::atomic<uint64>*>ins;
    static uint8   num;
};


#endif /* __COUNTER_HXX__ */
