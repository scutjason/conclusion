
#ifndef __IPDR_SERVER_HXX__
#define __IPDR_SERVER_HXX__

#include <Poco/Util/Application.h>
#include <Poco/Util/ServerApplication.h>

using Poco::Util::Application;
using Poco::Util::ServerApplication;

class IPDRServer: public ServerApplication
{
public:
    IPDRServer();

    ~IPDRServer();

    void loadConfiguration(int argc, char * argv[]);

protected:
    void initLogger();

    void beDaemon();

    void initialize(Application& self);

    void uninitialize();

    int main(const std::vector<std::string>& args);
};

#endif /* __IPDR_SERVER_HXX__ */


