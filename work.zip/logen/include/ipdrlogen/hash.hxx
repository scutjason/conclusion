//
// Created by 10209409 on 4/1/2017.
//

#ifndef __HASH_HXX__
#define __HASH_HXX__

#include <junction/ConcurrentMap_Linear.h>
#include <ipdrlogen/protocol.hxx>

using junction::ConcurrentMap_Linear;

#define DECLARE_HASH(hash, key, value)                         \
    class hash;                                                \
    static SingletonHolder<hash> hash##_holder;                \
    class hash                                                 \
    {                                                          \
    public:                                                    \
        hash()                                                 \
        {                                                      \
        };                                                     \
        ~hash()                                                \
        {                                                      \
        };                                                     \
        static ConcurrentMap_Linear<key, value>& Instance()    \
        {                                                      \
            hash& instance = *hash##_holder.get();             \
            return instance.get_hash();                        \
        }                                                      \
    private:                                                   \
        ConcurrentMap_Linear<key, value>& get_hash()           \
        {                                                      \
            return _hash;                                      \
        }                                                      \
    private:                                                   \
        ConcurrentMap_Linear<key, value>    _hash;             \
    }

DECLARE_HASH(IPDRHashTable, uint64, IPDRMessage*);
#endif /* __HASH_HXX__ */
