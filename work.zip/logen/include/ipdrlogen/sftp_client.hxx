//
// Created by 10209409 on 3/17/2017.
//

#ifndef __SFTP_CLIENT_HXX__
#define __SFTP_CLIENT_HXX__

#include <cub/message_block.hxx>
#include <cub/noncopyable.hxx>
#include <Poco/Net/StreamSocket.h>
#include <libssh2_sftp.h>

using cub::message_block;
using cub::noncopyable;
using Poco::Net::StreamSocket;
using Poco::Net::SocketAddress;

class SFTPClient : public noncopyable
{
    enum
    {
        SFTP_PORT         = 22
    };
    const size_t READ_BUFFER_SIZE         = 16 * 1024 * 1024;

public:
    SFTPClient(const std::string& remote,
               const std::string& username,
               const std::string& password);

    SFTPClient(const std::string& remote,
               uint16 port,
               const std::string& username,
               const std::string& password);

    ~SFTPClient();

public:

    bool put(const std::string& local_path,
             const std::string& remote_path,
             bool remote_is_directory = false);

    bool get(const std::string& remote_path,
             const std::string& local_path);

    bool Init();
    
    uint16 get_port()
    {
        return _port;
    }
    
    std::string& get_host()
    {
        return _remote;
    }

    void close();

    std::string to_string();

    inline bool connected()
    {
        return _connected;
    }

private:
    int wait_socket(int time_out = 10);

private:
    StreamSocket*               _socket;
    std::string                 _remote;
    uint16                        _port;
    std::string               _username;
    std::string               _password;
    bool                     _connected;
    LIBSSH2_SESSION*       _ssh_session;
    LIBSSH2_SFTP*         _sftp_session;
    char*                  _read_buffer;
};
#endif /* __SFTP_CLIENT_HXX__ */
