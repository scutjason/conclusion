//
// Created by 10209409 on 2/16/2017.
//

#ifndef __QUERY_SERVICE_HANDLER_H__
#define __QUERY_SERVICE_HANDLER_H__

#include <ipdrlogen/protocol.hxx>
#include <Poco/Net/SocketReactor.h>
#include <Poco/Net/StreamSocket.h>
#include <Poco/Net/SocketNotification.h>
#include <Poco/AutoPtr.h>
#include <Poco/FIFOBuffer.h>
#include <cub/message_block.hxx>
#include <ipdrlogen/LoopQueue.h>
#include <ipdrlogen/file_writer.hxx>
#include <Poco/Thread.h>
#include <ext/hash_map>
#include "ipdrlogen/ageing_map.hxx"
#include <ipdrlogen/ipdr_interface_handler.hxx>
#include <map>

using namespace __gnu_cxx;

using Poco::Net::StreamSocket;
using Poco::Net::SocketReactor;
using Poco::Net::ReadableNotification;
using Poco::Net::WritableNotification;
using Poco::Net::ShutdownNotification;
using Poco::AutoPtr;
using Poco::FIFOBuffer;
using Poco::Thread;
using Poco::Runnable;
using Poco::ThreadPool;

struct StringHash
{
    size_t operator()(const string &s) const
    {
	    size_t hval = 2654435761U;  
        size_t i = 0;
        const char *val = s.c_str();

        for (; i + 4 <= s.size(); i += 4, val += 4)
            hval = hval * 1000003 ^ *(unsigned*)val;
        for (; i < s.size(); ++i, val += 1)
            hval = hval * 1000003 ^ *val;

        return hval;
    }
};

struct StringCompare
{
    bool operator()(const string &left, const string &right) const
    {
        return (left == right);
    }
};

#if 0
typedef hash_map<std::string , IPDRMessage *, StringHash, StringCompare> HASH_TABLE;
#else
typedef std::map<std::string , IPDRMessage *> HASH_TABLE;
#endif

class DataHandle : public Runnable
{
    uint32 line_version = app_config.getUInt(USER_ACCOUNT_LINE_VERSION, 1);

public:


    DataHandle(LoopQueue<char*>&  queue, 
	    LoopQueue<IPDRMessage *> &write_queue, 
		LoopQueue<IPDRMessage *> &session_queue, 
		uint16& isStop);

    virtual ~DataHandle();

    virtual void run();
    
private:
    LoopQueue<char*>&                 _data_queue;
	LoopQueue<IPDRMessage*>&          _write_queue;
	LoopQueue<IPDRMessage*>&          _session_queue;
    uint16&                                 _isStop;
    HASH_TABLE                              _cache;
};


class LineDb : public Runnable
{

public:
    LineDb(LoopQueue<IPDRMessage*>& queue, LoopQueue<IPDRMessage*> &write_queue, uint16& isStop);

    virtual ~LineDb();

    virtual void run();
    
private:
	LoopQueue<IPDRMessage*>&        _session_queue;
	LoopQueue<IPDRMessage*>&        _write_queue;
	uint16&                         _isStop;
	time_t                          _last_do_ageing; 
};


class SessionHandle: public Runnable 
{
    uint32 line_version = app_config.getUInt(USER_ACCOUNT_LINE_VERSION, 1);
    std::string boce_tel = app_config.getString(USER_ACCOUNT_BOCE_TEL, "18805318929");

public:
    SessionHandle(LoopQueue<IPDRMessage*>& queue, LoopQueue<IPDRMessage*> &write_queue, uint16& isStop);

    virtual ~SessionHandle();

    void update_session_cache(IPDRMessage* message);

    bool online_ageing(IPDRXDRSession *session);
    
    bool online_ageing_ex(IPDRXDRSession *session);

    bool offline_ageing_ex(IPDRXDRSession *session);

    bool offline_ageing(IPDRXDRSession *session);

    virtual void run();
	
private:
    static ageing_map<std::string, IPDRXDRSession > *_online_cache;
	static ageing_map<std::string, IPDRXDRSession > *_offline_cache;
	LoopQueue<IPDRMessage*>&        _session_queue;
	LoopQueue<IPDRMessage*>&        _write_queue;
	uint16&                               _isStop;
	time_t                                _last_do_ageing; 
    uint64   _incoming_msgs;
	uint64   _online_msgs;
	uint64   _online_discard_msgs;
	uint64   _offline_msgs;
	uint64   _offline_discard_msgs;
	time_t   _monitor_version;
    std::map<std::string, AccountMonitor *> _monitor_conditon_map;   
};

class IPDRServerHandler
{
    uint32 thread_num     = app_config.getUInt(LOGEN_WRITE_THREAD_NUM,
                              2);
                              
    uint32 max_entry_num  = app_config.getUInt(LOGEN_FILE_ENTRY_NUM, 400000);
    
    std::string device_id = app_config.getString(LOGEN_FILE_DEVICE_ID,
                            DEFAULT_DEVICE_ID);
    uint32 line_version = app_config.getUInt(USER_ACCOUNT_LINE_VERSION, 1);

public:
    IPDRServerHandler(StreamSocket& socket, SocketReactor& reactor);

    ~IPDRServerHandler();

    void on_socket_readable(const AutoPtr<ReadableNotification>& pNf);

    void on_socket_writable(const AutoPtr<WritableNotification>& pNf);

    void on_socket_shutdown(const AutoPtr<ShutdownNotification>& pNf);

    void on_send_buffer_readable(bool& init);

    void stop_thread()
    {
        _is_stop_thread = 1;
    };


private:

    void send_heart_beat();

    int read(char* buf, int count, int& read_count);

    int parse_data(int bytes);

    enum
    {
        BUFFER_SIZE    = 1 * 1024 *1024
    };

    StreamSocket                    _socket;
    SocketReactor&                  _reactor;
    cub::message_block              _recv_buffer;
    FIFOBuffer                      _send_buffer;
    uint16                          _is_stop_thread;
    uint16                          _is_create_file;
    LoopQueue<char *>         _data_queue;
    Thread                          _data_thread;
    DataHandle*                     _data_handle;
	LoopQueue<IPDRMessage *>  _write_queue;
    ThreadPool                      _write_pool;
    std::vector<FileWriter *>       _write_handles;
	LoopQueue<IPDRMessage *>     _session_queue;
	LoopQueue<IPDRMessage *>  _write_session_queue;
	SessionHandle *                    _session_handle;
	FileWriter *                       _session_writer;
	Thread                             _session_thread;
	Thread                             _write_session_thread;
	Thread                             _lien_db_thread;
	LineDb*                            _line_db_handle;
};

#endif /* __QUERY_SERVICE_HANDLER_H__ */
