//
// Created by 10209409 on 3/16/2017.
//

#ifndef __PROTOCOL_HXX__
#define __PROTOCOL_HXX__

#include <ipdrlogen/common.hxx>
#include <cub/endian.hxx>
#include <cub/net.hxx>

#include <Poco/Timestamp.h>
#include <Poco/LocalDateTime.h>
#include <Poco/DateTimeFormatter.h>
#include <Poco/AutoPtr.h>
#include <Poco/Notification.h>
#include <iostream>
#include <sstream>

using Poco::LocalDateTime;
using Poco::Timestamp;
using Poco::DateTimeFormatter;
using Poco::AutoPtr;
using Poco::Notification;

const uint16 IPDR_PACKAGE_MAGIC         = 0xc823;
const uint16 IPDR_HEADER_LENGTH         = 6;
const size_t IPDR_HEADER_MAGIC_OFFSET   = 0;
const size_t IPDR_HEADER_LENGTH_OFFSET  = 2;
const size_t IPDR_HEADER_TYPE_OFFSET    = 4;
const uint64 MICRO_SEC_PER_MILL_SEC     = 1000;

const uint16 IPDR_XDR                   = 10086;
const uint16 IPDR_SESSION               = 10099;
const uint16 IPDR_NAT                   = 10010;
const uint16 IPDR_FILE_LIST             = 10090;
const uint16 IPDR_KEYWORD_FILTER        = 10091;
const uint16 IPDR_HEART_BEAT            = 10000;
const uint16 IPDR_TIMER                 = 10011;

const char        IPDR_FILED_DELIMITER  = '|';
const std::string EMPTY_ZERO_STR        = "0";
const std::string IPV6_DELIMITER        = ":";

const uint8 IPDR_FILTER_TRACE_ACCESS    = 3;
const uint8 IPDR_FILTER_TRACE_LINE      = 4;

extern std::string ACCOUNT_TYPE;

#define GETX(x)  (x.empty() ? EMPTY_ZERO_STR :  x)

static inline std::string get_ip(const std::string &ip, bool ipv6)
{
    if (ip.empty())
    {
        return EMPTY_ZERO_STR;
    }
    
    if(ip == "::")
    {
        return EMPTY_ZERO_STR;
    }

    std::size_t index = ip.find(IPV6_DELIMITER);

    if (index != std::string::npos)
    {
        if(ipv6)
        {
            return ip;
        }
        else
        {
            return EMPTY_ZERO_STR;
        }
    }

    return (ipv6 ? EMPTY_ZERO_STR : ip);
}

enum TIME_DATUM
    {
        DATUM1970 = 0,
        DATUM1994 = 1,
        DATUM2000 = 2,
        DATUM2008 = 3
    };
	
static std::string time2String(unsigned int dwSeconds, TIME_DATUM datum = DATUM2000)
{
    unsigned char szTime[64]={0};
    unsigned char DAYS_PER_MONTH[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    switch(datum)
    {
    case DATUM1970:
    {
                if(dwSeconds <= 946684800)
                {
                    return "2000-01-01 00:00:00";
                }
                dwSeconds -= 946684800;
            }
            break;

        case DATUM1994:
            {
                if(dwSeconds <= 189302400)
                {
                    return "2000-01-01 00:00:00";
                }
                dwSeconds -= 189302400;
            }
            break;

        case DATUM2008:
            {
                dwSeconds += 252460800;
            }
            break;

        default:
            break;
        }


        unsigned int dwDaySeconds = dwSeconds % 86400;
        unsigned char ucHour      = (unsigned char)(dwDaySeconds / 3600);

        dwDaySeconds %= 3600;
        unsigned char ucMinute = (unsigned char)(dwDaySeconds / 60);
        unsigned char ucSecond = (unsigned char)(dwDaySeconds % 60);

        unsigned int   dwDays       = dwSeconds / 86400;
        unsigned short wDaysPerYear = 366;
        unsigned short wYear        = 2000;
        while (dwDays >= wDaysPerYear) {
            dwDays -= wDaysPerYear;
            wYear++;
            if ((((wYear % 4) == 0 && (wYear % 100) != 0)) || ((wYear % 400) == 0))
                wDaysPerYear = 366;
            else
                wDaysPerYear = 365;
        }

        if (wDaysPerYear == 366)
            DAYS_PER_MONTH[1] = 29;
        else
            DAYS_PER_MONTH[1] = 28;

        unsigned char ucMonth = 1;
        while (dwDays >= DAYS_PER_MONTH[ucMonth - 1]) {
            dwDays -= DAYS_PER_MONTH[ucMonth - 1];
            ucMonth ++;
        }

        unsigned char ucDay = (unsigned char)(dwDays + 1);

        sprintf((char *)szTime, "%d-%02d-%02d %02d:%02d:%02d", wYear, ucMonth, ucDay, ucHour, ucMinute, ucSecond);
        return std::string((char *)szTime);
    }
static inline std::string format_time(uint64 time)
{
    return time2String(time/1000, DATUM1970);
#if 0
    Timestamp ts(static_cast<Timestamp::TimeVal>(time * MICRO_SEC_PER_MILL_SEC));
    LocalDateTime dateTime(ts);

    return DateTimeFormatter::format(dateTime,
#endif
}


class IPDRMessage
{
public:

    IPDRMessage()          {};
    virtual ~IPDRMessage() {};


    virtual void encode(void * buffer, uint16& encoded_length) = 0;
    virtual void decode(void * buffer, uint16& decoded_length) = 0;
    virtual void write(std::ostream* ostream)const               = 0;

    uint16 get_message_type()
    {
        return _message_type;
    };

    void set_message_type(uint16 message_type)
    {
        _message_type = message_type;
    }

private:
    uint16  _message_type;
};

typedef struct sIPDRKeywordFilter 
{
    std::string  taskId;
    uint8  trace_type;
    std::string  trace_file_name;
    IPDRMessage *ipdr_entry;
    uint64      count;

}tIpdrFilterContext;


class IPDRFileList : public IPDRMessage
{
public:
    std::string        filename;
    std::string        uploadStartTime;
    std::string        uploadEndTime;
    uint8              sftp_No;
    std::string        fileMd5;
    uint64             fileNum;
    std::string        wap_ip;
    char               delimiter;
    
    IPDRFileList(char del = IPDR_FILED_DELIMITER) : delimiter(del)
    {
        set_message_type(IPDR_FILE_LIST);
    }
    
    virtual void encode(void * buffer, uint16& encoded_length)
    {
    }
    virtual void decode(void * buffer, uint16& decoded_length)
    {
    }

    virtual void write(std::ostream* stream)const
    {
        *stream << GETX(filename) << delimiter;            
        *stream << GETX(uploadStartTime) << delimiter;            
        *stream << GETX(uploadEndTime) << delimiter;           
        *stream << GETX(fileMd5) << delimiter;      
        *stream << fileNum << delimiter;      
        *stream << GETX(wap_ip);               
        *stream << "\r\n";
    }

};
std::ostream& operator<< (std::ostream& stream, const IPDRFileList& r);


class IPDRXDRlog : public IPDRMessage
{
public:
    uint64        btime;
    std::string   msisdn;
    std::string   imsi;
    std::string   imei;
    std::string   user_agent;
    std::string   private_ip;
    std::string   nat_ip;
    uint16        nat_port;
    std::string   dest_ip;
    uint16        dest_port;
    uint16        protocol_type;
    uint16        service_cmd;
    uint16        lac;
    uint32        ci;
    std::string   rnode;
    std::string   lnode;
    uint16        request_type;
    std::string   url;
    char           delimiter;

    IPDRXDRlog(char del = IPDR_FILED_DELIMITER) : delimiter(del)
    {
        set_message_type(IPDR_XDR);
    }

    virtual void encode(void * buffer, uint16& encoded_length)
    {
        char * dest    = reinterpret_cast<char*>(buffer);
        dest += cub::encode(dest, btime);
        dest += cub::encode_string(dest, msisdn);
        dest += cub::encode_string(dest, imsi);
        dest += cub::encode_string(dest, imei);
        dest += cub::encode_string(dest, user_agent);
        dest += cub::encode_string(dest, private_ip);
        dest += cub::encode_string(dest, nat_ip);
        dest += cub::encode(dest, nat_port);
        dest += cub::encode_string(dest, dest_ip);
        dest += cub::encode(dest, dest_port);
        dest += cub::encode(dest, protocol_type);
        dest += cub::encode(dest, service_cmd);
        dest += cub::encode(dest, lac);
        dest += cub::encode(dest, ci);
        dest += cub::encode_string(dest, rnode);
        dest += cub::encode_string(dest, lnode);
        dest += cub::encode(dest, request_type);
        dest += cub::encode_string(dest, url);

        encoded_length = static_cast<uint16>(dest - reinterpret_cast<char*>(buffer));
    }

    virtual void decode(void * buffer, uint16& decoded_length)
    {
        const char * src = reinterpret_cast<const char*>(buffer);
        src += cub::decode(src, btime);
        src += cub::decode_string(src, msisdn);
        src += cub::decode_string(src, imsi);
        src += cub::decode_string(src, imei);
        src += cub::decode_string(src, user_agent);
        src += cub::decode_string(src, private_ip);
        src += cub::decode_string(src, nat_ip);
        src += cub::decode(src, nat_port);
        src += cub::decode_string(src, dest_ip);
        src += cub::decode(src, dest_port);
        src += cub::decode(src, protocol_type);
        src += cub::decode(src, service_cmd);
        src += cub::decode(src, lac);
        src += cub::decode(src, ci);
        src += cub::decode_string(src, rnode);
        src += cub::decode_string(src, lnode);
        src += cub::decode(src, request_type);
        src += cub::decode_string(src, url);

        decoded_length =  static_cast<uint16>(src - reinterpret_cast<char*>(buffer));
    }

    std::string to_string()
    {
        std::stringstream result;
        result << std::endl;
        result << "btime           = " << format_time(btime) << std::endl;
        result << "msisdn          = " << msisdn << std::endl;
        result << "imsi            = " << imsi << std::endl;
        result << "imei            = " << imei << std::endl;
        result << "user_agent      = " << user_agent << std::endl;
        result << "private_ip      = " << private_ip << std::endl;
        result << "nat_ip          = " << nat_ip << std::endl;
        result << "nat_port        = " << nat_port << std::endl;
        result << "dest_ip         = " << dest_ip << std::endl;
        result << "dest_port       = " << dest_port << std::endl;
        result << "protocol_type   = " << protocol_type << std::endl;
        result << "service_cmd     = " << service_cmd << std::endl;
        result << "lac             = " << lac << std::endl;
        result << "ci              = " << ci << std::endl;
        result << "rnode           = " << rnode << std::endl;
        result << "lnode           = " << lnode << std::endl;
        result << "request_type    = " << request_type << std::endl;
        result << "url             = " << url;

        return result.str();
    }

    virtual void write(std::ostream* stream)const
    {
        std::string http_url = url;
        *stream << GETX(imsi) << delimiter;             /* IMSI          */
        *stream << GETX(imei) << delimiter;             /* IMEI          */
        *stream << EMPTY_ZERO_STR << delimiter;         /* Mac, empty    */
        *stream << GETX(msisdn) << delimiter;           /* Account       */
        *stream << GETX(user_agent) << delimiter;       /* user_agent    */
        *stream << ACCOUNT_TYPE << delimiter;           /* accountType    */
        *stream << 2 << delimiter;                    /* loginType    */
        *stream << get_ip(private_ip, false) << delimiter;       /* private_ip    */
        *stream << get_ip(nat_ip, false) << delimiter;  /* srcIP         */
        *stream << get_ip(nat_ip, true)  << delimiter;  /* srcIPv6       */
        *stream << nat_port << delimiter;               /* srcPort       */
        *stream << get_ip(dest_ip, false) << delimiter; /* dstIpv4       */
        *stream << get_ip(dest_ip, true) << delimiter;  /* dstIpv6       */
        *stream << dest_port << delimiter;              /* dstPort       */
#if 1
        *stream << protocol_type << delimiter;          /* protocol_type */
        *stream << service_cmd << delimiter;            /* serviceTypeId   */
        *stream << 0 << delimiter;                      /* virtualUserName   */
        *stream << format_time(btime) << delimiter;     /* btime         */
        *stream << lac << delimiter;                    /* lac           */
        *stream << ci  << delimiter;                    /* ci            */
        *stream << get_ip(lnode, false) << delimiter;   /* LNodeIpV4     */
        *stream << get_ip(lnode, true) << delimiter;    /* LNodeIpV6     */
        *stream << get_ip(rnode, false) << delimiter;   /* RNodeIpV6     */
        *stream << get_ip(rnode, true) << delimiter;    /* RNodeIpV6     */
        *stream << request_type << delimiter;           /* request_type  */
        if (protocol_type == 1 && !url.empty()){
            if (url.substr(0,7) != "http://" && url.substr(0,8) != "https://"){
                http_url = "http://" + url;
            }
        }
        *stream << GETX(http_url);                      /* url           */
        *stream << "\r\n";
#endif
    }
};

std::ostream& operator<< (std::ostream& stream, const IPDRXDRlog& r);

class IPDRNATlog : public IPDRMessage
{
public:
    std::string    private_ip;
    std::string    source_ip;
    uint16         source_port;
    std::string    dest_ip;
    uint16         dest_port;
    std::string    nat_time;
    char           delimiter;

    IPDRNATlog(char del = IPDR_FILED_DELIMITER) : delimiter(del)
    {
        set_message_type(IPDR_NAT);
    }

    virtual void encode(void * buffer, uint16& encoded_length)
    {
        char * dest    = reinterpret_cast<char*>(buffer);
        dest += cub::encode_string(dest, private_ip);
        dest += cub::encode_string(dest, source_ip);
        dest += cub::encode(dest, source_port);
        dest += cub::encode_string(dest, dest_ip);
        dest += cub::encode(dest, dest_port);
        dest += cub::encode_string(dest, nat_time);
        encoded_length = static_cast<uint16>(dest - reinterpret_cast<char*>(buffer));
    }

    virtual void decode(void * buffer, uint16& decoded_length)
    {
        const char * src = reinterpret_cast<const char*>(buffer);
        src += cub::decode_string(src, private_ip);
        src += cub::decode_string(src, source_ip);
        src += cub::decode(src, source_port);
        src += cub::decode_string(src, dest_ip);
        src += cub::decode(src, dest_port);
        src += cub::decode_string(src, nat_time);
        decoded_length =  static_cast<uint16>(src - reinterpret_cast<char*>(buffer));
    }

    std::string to_string()
    {
        std::stringstream result;
        result << std::endl;
        result << "private_ip      = " << private_ip << std::endl;
        result << "source_ip       = " << source_ip << std::endl;
        result << "source_port     = " << source_port << std::endl;
        result << "dest_ip         = " << dest_ip << std::endl;
        result << "dest_port       = " << dest_port << std::endl;
        result << "nat_time        = " << nat_time << std::endl;
        return result.str();
    }

    virtual void write(std::ostream* stream)const
    {
        *stream << GETX(private_ip) << delimiter;
        *stream << GETX(source_ip) << delimiter;
        *stream << source_port << delimiter;
        *stream << GETX(dest_ip) << delimiter;
        *stream << dest_port << delimiter;
        *stream << nat_time;
        *stream << "\r\n";
    }
};

std::ostream& operator<< (std::ostream& stream, const IPDRNATlog& r);

#define ONLINE_TIME_TYPE "1"
#define OFFLINE_TIME_TYPE "2"

class IPDRXDRSession : public IPDRMessage
{
    uint32 line_version = app_config.getUInt(USER_ACCOUNT_LINE_VERSION, 1);
public:
    bool          online;
    uint64        btime;
	uint64        etime;
    std::string   msisdn; //account
    std::string   imsi;
    std::string   imei;
	std::string   mac = EMPTY_ZERO_STR;
	uint16        login_type = 2;
	std::string   user_ip;
	uint16        lac;
    uint32        ci;	
	std::string   rnode_ip; // enb_ip
    std::string   lnode_ip; // mme_ip
    std::string   pub_ip = EMPTY_ZERO_STR;
    char          delimiter;

    std::string   procedure_start_time; /* mis-seceont,  now from 1970 */
    std::string   user_ipv6;
    uint8         procedure_type;        /* 1 attach  0 deattach  5 TAU */
    uint8         procedure_status;      /* 0 1 */
    uint16        tac;
    uint32        cell_id;
    uint16        other_tac;
    uint32        other_eci;

	IPDRXDRSession(IPDRXDRlog &xdr)
	{
	    online     = true;
		btime      = xdr.btime;
		etime      = xdr.btime;
		msisdn     = xdr.msisdn;
		imsi       = xdr.imsi;
		imei       = xdr.imei;
		user_ip    = xdr.private_ip;
		user_ipv6  = xdr.private_ip;
		rnode_ip   = xdr.rnode;
		lnode_ip   = xdr.lnode;
		lac        = xdr.lac;
		ci         = xdr.ci;
		login_type = 2;
        pub_ip     = xdr.nat_ip;
		
		delimiter = xdr.delimiter;
		set_message_type(IPDR_SESSION);
	}
	
    IPDRXDRSession(char del = IPDR_FILED_DELIMITER) : delimiter(del)
    {
        set_message_type(IPDR_SESSION);
    }

    virtual void encode(void * buffer, uint16& encoded_length)
    {
        
    }

    virtual void decode(void * buffer, uint16& decoded_length)
    {
        const char * src = reinterpret_cast<const char*>(buffer);
        src += cub::decode_string(src, imsi);
        src += cub::decode_string(src, imei);
        src += cub::decode_string(src, msisdn);
        src += cub::decode(src, procedure_type);
        src += cub::decode_string(src, procedure_start_time);
        src += cub::decode(src, procedure_status);
        src += cub::decode_string(src, user_ip);
        src += cub::decode_string(src, user_ipv6);
        src += cub::decode_string(src, rnode_ip); // rnode_ip
        src += cub::decode_string(src, lnode_ip); // lnode_ip
        src += cub::decode(src, tac);
        src += cub::decode(src, cell_id);
        src += cub::decode(src, other_tac);
        src += cub::decode(src, other_eci);

        decoded_length =  static_cast<uint16>(src - reinterpret_cast<char*>(buffer));

    }

    std::string to_string(bool line)
    {
        std::stringstream result;
        result << std::endl;
        result << "imsi         = " << GETX(imsi) << std::endl;              /* IMSI          */
        result << "imei         = " << GETX(imei) << std::endl;              /* IMEI          */
        result << "mac          = " << GETX(mac)  << std::endl;              /* Mac, empty    */
        result << "account      = " << GETX(msisdn) << std::endl;           /* Account       */
        result << "account_type = " << ACCOUNT_TYPE << std::endl;
		result << "login_type   = " << login_type << std::endl;              /* ��½���� */
		result << "user_ipv4    = " << get_ip(user_ip, false) << std::endl;
		result << "user_ipv6    = " << get_ip(user_ipv6, true) << std::endl; 
		
		if(line)
		{
		    result << "line_time_type = " << ONLINE_TIME_TYPE << std::endl;
		    if(line_version == 1)
		    {
		        result << "line_time      = " << format_time(btime) << std::endl;
		    }
		    else
		    {
		        result << "line_time      = " << GETX(procedure_start_time) << std::endl;
		    }
	    }
		else
		{
		    result  << "line_time_type = " << OFFLINE_TIME_TYPE << std::endl;
		    if(line_version == 1)
		    {
		        result << "line_time      = " << format_time(etime) << std::endl;
		    }
		    else
		    {
		        result << "line_time      = " << GETX(procedure_start_time) << std::endl;
		    }
		}
		
		result  << "lac = " << lac << std::endl;                    /* lac           */
        result  << "ci  = " << ci  << std::endl;                    /* ci            */
		result  << "lnode_ipv4 = " << get_ip(lnode_ip, false) << std::endl; 
		result  << "lnode_ipv6 = " << get_ip(lnode_ip, true)  << std::endl; 
		result  << "rnode_ipv4 = " << get_ip(rnode_ip, false) << std::endl; 
		result  << "rnode_ipv4 = " << get_ip(rnode_ip, true)  << std::endl; 

        return result.str();
    }

    virtual void write(std::ostream* stream)const
    {
		
        *stream << GETX(imsi) << delimiter;              /* IMSI          */
        *stream << GETX(imei) << delimiter;              /* IMEI          */
        *stream << GETX(mac)  << delimiter;              /* Mac, empty    */
        *stream << GETX(msisdn) << delimiter;           /* Account       */
        *stream << ACCOUNT_TYPE << delimiter;
		*stream << login_type << delimiter;              /* ��½���� */
		*stream << get_ip(user_ip, false) << delimiter;
		*stream << get_ip(user_ipv6, true)  << delimiter;
		
		if(online)
		{
		    *stream << ONLINE_TIME_TYPE << delimiter;
		    if(line_version == 1)
		    {
		        *stream << format_time(btime) << delimiter;
		    }
		    else
		    {
		        *stream<< GETX(procedure_start_time) << delimiter;
		    }
	    }
		else
		{
		    *stream << OFFLINE_TIME_TYPE << delimiter;
		    if(line_version == 1)
		    {
		        *stream << format_time(etime) << delimiter;
		    }
		    else
		    {
		        *stream<< GETX(procedure_start_time) << delimiter;
		    }
		}
		
		*stream << lac << delimiter;                    /* lac           */
        *stream << ci  << delimiter;                    /* ci            */
		*stream << get_ip(lnode_ip, false)  << delimiter; 
		*stream << get_ip(lnode_ip, true)   << delimiter; 
		*stream << get_ip(rnode_ip, false)  << delimiter; 
		*stream << get_ip(rnode_ip, true); 
		*stream << "\r\n";
    }
};

std::ostream& operator<< (std::ostream& stream, const IPDRXDRSession& r);

class IPDRKeywordFilter : public IPDRMessage
{
public:
    std::string  taskId;
    uint8  trace_type;
    std::string  trace_file_name;
    IPDRXDRSession  *ipdr_msg_line;
    IPDRXDRlog  *ipdr_msg_access;
    uint8               kf_server_No;
    char               delimiter;
    
    IPDRKeywordFilter(char del = IPDR_FILED_DELIMITER) : delimiter(del)
    {
        set_message_type(IPDR_KEYWORD_FILTER);
    }
    virtual void encode(void * buffer, uint16& encoded_length)
    {
    }
    virtual void decode(void * buffer, uint16& decoded_length)
    {
    }

    virtual void write(std::ostream* stream)const
    {
        //std::ostream ipdr_stream;
        *stream << GETX(taskId) << delimiter;
        *stream << GETX(trace_file_name) << delimiter;
        *stream << std::to_string(trace_type) << delimiter;            
             
        if(trace_type == IPDR_FILTER_TRACE_LINE  &&
            ipdr_msg_line != NULL)
        {
            ipdr_msg_line->write(stream);
        }
        else if(trace_type == IPDR_FILTER_TRACE_ACCESS &&
            ipdr_msg_access != NULL)
        {
            ipdr_msg_access->write(stream);
        }
    }

};
std::ostream& operator<< (std::ostream& stream, const IPDRKeywordFilter& r);

#endif /* __PROTOCOL_HXX__ */
