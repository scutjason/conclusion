//
// Created by 10209409 on 2/11/2017.
//

#ifndef __COMMON_HXX__
#define __COMMON_HXX__

#include <ipdrlogen/configuration.hxx>
#include <Poco/Logger.h>
#include <Poco/Util/Application.h>
#include <cstring>

using Poco::Logger;


#define __FILENAME__       (strrchr(__FILE__, '/') ? strrchr(__FILE__, '/') + 1 : __FILE__)

#define app_config         Poco::Util::Application::instance().config()

extern std::string appName;

#define __logger__         Poco::Logger::get(appName)
#define LOG_INFO(x)        __logger__.information((x), __FILENAME__, __LINE__)
#define LOG_WARN(x)        __logger__.warning((x), __FILENAME__, __LINE__)
#define LOG_DEBUG(x)       __logger__.debug((x), __FILENAME__, __LINE__)
#define LOG_FATAL(x)       __logger__.fatal((x), __FILENAME__, __LINE__)
#define LOG_TRACE(x)       __logger__.trace((x), __FILENAME__, __LINE__)
#define LOG_ERROR(x)       __logger__.error((x), __FILENAME__, __LINE__)
#define LOG_CRITICAL(x)    __logger__.critical((x), __FILENAME__, __LINE__)

#endif /* __COMMON_HXX__ */
