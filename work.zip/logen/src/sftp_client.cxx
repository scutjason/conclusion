//
// Created by 10209409 on 3/17/2017.
//
#include <cub/os_utils.hxx>
#include <cub/string_utils.hxx>
#include <ipdrlogen/sftp_client.hxx>
#include <ipdrlogen/common.hxx>
#include <ipdrlogen/perform_stats.hxx>

SFTPClient::SFTPClient(const std::string &remote,
                       const std::string &username,
                       const std::string &password):
    _remote(remote),
    _port(SFTP_PORT),
    _username(username),
    _password(password),
    _connected(false),
    _socket(nullptr),
    _ssh_session(nullptr),
    _sftp_session(nullptr),
    _read_buffer(new char[READ_BUFFER_SIZE])
{
}

SFTPClient::SFTPClient(const std::string &remote,
                       uint16 port,
                       const std::string &username,
                       const std::string &password):
    _remote(remote),
    _port(port),
    _username(username),
    _password(password),
    _connected(false),
    _socket(nullptr),
    _ssh_session(nullptr),
    _sftp_session(nullptr),
    _read_buffer(new char[READ_BUFFER_SIZE])
{
}

SFTPClient::~SFTPClient()
{
    close();
    safe_delete_array(_read_buffer);
}

bool SFTPClient::Init()
{
    SocketAddress socketAddress = SocketAddress(_remote, _port);
    const char *fingerprint;
    int rc;

    try
    {
        _socket  = new StreamSocket(socketAddress);
        /*
         * Create a session instance
         */
        _ssh_session = libssh2_session_init();

        if (!_ssh_session)
        {
            LOG_INFO("libssh2_session_init failed !!! ");
            close();
            return false;
        }
        LOG_INFO("libssh2_session_init OK !!! ");
        /* Since we have set non-blocking, tell libssh2 we are non-blocking */
        libssh2_session_set_blocking(_ssh_session, 1);

        /* set timeout 5min */
        //std::string sftp_timtout = app_config.getString(UPLOAD_SFTP_TIMEOUT);
        libssh2_session_set_timeout(_ssh_session, 300000);
        
        /*
         * start it up. This will trade welcome banners, exchange keys,
         * and setup crypto, compression, and MAC layers
         */
        rc = libssh2_session_handshake(_ssh_session, _socket->impl()->sockfd());

        if (rc)
        {
            LOG_WARN("Failure establishing SSH session : " + std::string(strerror(errno)) +to_string());
            close();
            return false;
        }
        LOG_INFO("libssh2_session_handshake OK !!! ");
        /* At this point we havn't yet authenticated.  The first thing to do is
         * check the hostkey's fingerprint against our known hosts Your app may
         * have it hard coded, may go to a file, may present it to the user,
         * that's your call
         */
        fingerprint = libssh2_hostkey_hash(_ssh_session, LIBSSH2_HOSTKEY_HASH_SHA1);
        LOG_INFO("SSH fingerprint : " + cub::hex_dump(fingerprint, 20));
        

        /* We could authenticate via password */
       rc = libssh2_userauth_password(_ssh_session, _username.c_str(),
                                               _password.c_str());

        if (rc)
        {
            LOG_WARN("Authentication by password failed. " +to_string());
            close();
            return false;
        }
        LOG_INFO("libssh2_userauth_password OK !!! ");
        
        _sftp_session = libssh2_sftp_init(_ssh_session);
        LOG_INFO("SFTP timeout : " + std::to_string(libssh2_session_get_timeout(_ssh_session)));
        if (!_sftp_session)
        {
            LOG_WARN("Unable to init SFTP session");
            close();
            return false;
        }
        LOG_INFO("libssh2_sftp_init OK !!! ");
        _connected = true;
        LOG_INFO(" sftp_client init OK !!! ");
        return true;
    }

    catch (Poco::TimeoutException& e)
    {
        LOG_WARN(e.displayText());
        close();
        return false;
    }

    catch (Poco::Exception& e)
    {
        LOG_WARN(e.displayText());
        close();
        return false;
    }

    catch (...)
    {
        LOG_WARN("Unknown exception raised connecting to " +to_string());
        close();
        return false;
    }
}

void SFTPClient::close()
{
    if (_ssh_session != nullptr)
    {
        safe_free(_sftp_session, libssh2_sftp_shutdown);
        safe_free(_sftp_session, free);

        libssh2_session_disconnect(_ssh_session,
                                          "Normal Shutdown, Thank you for playing");
               

        safe_free(_ssh_session, libssh2_session_free);
        safe_free(_ssh_session, free);
    }

    if ((_socket != nullptr) && _connected)
    {
        _socket->close();
    }

    safe_delete(_socket);
    _connected = false;
    if(_socket == nullptr)
    {
        LOG_INFO("closed SSH OK  ");
    }
    else
    {
        LOG_INFO(" ssh closed ERROR !! ");
    }
}

bool SFTPClient::put(const std::string& local_path,
                     const std::string& remote_path,
                     bool remote_is_directory)
{
    if (!_connected && !Init())
    {
        LOG_WARN("Fail to startup SFTP session.");
        return false;
    }

    LIBSSH2_SFTP_HANDLE*   sftp_handle;
    FILE *                 local;
    size_t                 read_size;
    ssize_t                rc;
    char *                 ptr;
    bool                   flag = false;
    
    std::string remote_file = remote_path;

    if (remote_is_directory)
    {
        size_t length = remote_file.length();

        if (remote_file.at(length - 1) != PATH_SEP)
        {
            remote_file.append(PATH_SEP_STR);
            remote_file.append(cub::basename(local_path));
        }
    }
    
    do
    {
        sftp_handle =
            libssh2_sftp_open(_sftp_session, remote_file.c_str(),
                              LIBSSH2_FXF_WRITE | LIBSSH2_FXF_CREAT | LIBSSH2_FXF_TRUNC,
                              LIBSSH2_SFTP_S_IRUSR | LIBSSH2_SFTP_S_IWUSR |
                              LIBSSH2_SFTP_S_IRGRP | LIBSSH2_SFTP_S_IROTH);

        if (!sftp_handle) {
        
            LOG_ERROR("Unable to open " + remote_file + " with SFTP " +to_string());
            close();
            //__interlocked_add_exchange64(&PerformStats::_sftp_conn_re, 1);
            return false; 
            
        }
    }
    while (0);

    local = fopen(local_path.c_str(), "rb");

    if (!local)
    {
        int ret = libssh2_sftp_close(sftp_handle);
        LOG_WARN("Can't open local file " + local_path + " : " + std::string(strerror(
                     errno)) + " rc " + std::to_string(ret));
        return false;
    }

    do
    {
        read_size = fread(_read_buffer, 1, READ_BUFFER_SIZE, local);

        if (read_size <= 0)
        {
            /* end of file */
            break;
        }

        ptr = _read_buffer;

        do
        {
            /* write data in a loop until we block */
            /* timeout is 3min and try 3 times*/

            rc = libssh2_sftp_write(sftp_handle, ptr, read_size);
            if (rc < 0)
            {   
                flag= true;
                break;
            }

            ptr += rc;
            read_size -= rc;
        }
        while (read_size);
    }
    while (rc > 0);

    safe_free(local, fclose);
    int ret = libssh2_sftp_close(sftp_handle);
    if(rc < 0)
    {
        LOG_WARN("libssh2_sftp_close ERROR , rc  " +std::to_string(ret));
    }
    
    if(flag){
        LOG_ERROR("libssh2_sftp_write ERROR!!!!! ready to close " +std::to_string(rc));
        close();
        //__interlocked_add_exchange64(&PerformStats::_sftp_conn_re, 1);
        return false;
    }
    
    LOG_DEBUG("uploading to: < "+ _remote + ", " + std::to_string(_port)+ "> " + remote_file  +"    OK !!!");
    return  true;
}


bool SFTPClient::get(const std::string& remote_path,
                     const std::string& local_path)
{
    if (!_connected && !Init())
    {
        LOG_WARN("Fail to startup SFTP session.");
        return false;
    }

    LIBSSH2_SFTP_HANDLE*   sftp_handle;
    FILE *                 local;
    ssize_t                read_size;

    do
    {
        sftp_handle = libssh2_sftp_open(_sftp_session, remote_path.c_str(),
                                        LIBSSH2_FXF_READ, 0);

        if (!sftp_handle &&
            (libssh2_session_last_errno(_ssh_session) != LIBSSH2_ERROR_EAGAIN))
        {
            LOG_ERROR("Unable to open " + remote_path + " with SFTP, error code = " +
                      std::to_string(libssh2_session_last_errno(_ssh_session)));
            return false;
        }
    }
    while (!sftp_handle);

    local = fopen(local_path.c_str(), "w");

    if (!local)
    {
        safe_free(sftp_handle, libssh2_sftp_close_handle);
        LOG_ERROR("Can't open local file " + local_path + " : " + std::string(strerror(
                      errno)));
        return false;
    }

    LOG_DEBUG("SFTP downloading : " + remote_path + " -> " + local_path);

    do
    {
        read_size = libssh2_sftp_read(sftp_handle, _read_buffer, sizeof(_read_buffer));

        if (read_size > 0)
        {
            fwrite(_read_buffer, sizeof(char), static_cast<size_t>(read_size), local);
        }

        else
        {
            safe_free(local, fclose);
            safe_free(sftp_handle, libssh2_sftp_close_handle);

            return  (read_size == 0);
        }
    }
    while (1);
}


int SFTPClient::wait_socket(int time_out)
{
    if (_socket == nullptr)
    {
        return -1;
    }

    struct timeval timeout;

    int rc;

    int socket_fd = _socket->impl()->sockfd();

    fd_set fd;

    fd_set *write_fd = nullptr;

    fd_set *read_fd  = nullptr;

    int dir;

    timeout.tv_sec  = time_out;

    timeout.tv_usec = 0;

    FD_ZERO(&fd);

    FD_SET(socket_fd, &fd);

    /* now make sure we wait in the correct direction */
    dir = libssh2_session_block_directions(_ssh_session);

    if (dir & LIBSSH2_SESSION_BLOCK_INBOUND)
    {
        read_fd = &fd;
    }

    if (dir & LIBSSH2_SESSION_BLOCK_OUTBOUND)
    {
        write_fd = &fd;
    }

    rc = select(socket_fd + 1, read_fd, write_fd, nullptr, &timeout);

    return rc;
}

std::string SFTPClient::to_string()
{
    std::stringstream out;
    out << "{ ";
    out << "host : " << _remote   << ", ";
    out << "port : " <<  _port    << ", ";
    out << "user : " << _username;
    out << " }";
    return out.str();
}
