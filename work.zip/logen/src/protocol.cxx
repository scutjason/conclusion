//
// Created by 10209409 on 3/25/2017.
//

#include <ipdrlogen/protocol.hxx>

std::ostream& operator<< (std::ostream& stream, const IPDRXDRlog& r)
{
    stream << GETX(r.imsi) << r.delimiter;             /* IMSI          */
    stream << GETX(r.imei) << r.delimiter;             /* IMEI          */
    stream << EMPTY_ZERO_STR << r.delimiter;           /* Mac, empty    */
    stream << GETX(r.msisdn) << r.delimiter;           /* Account       */
    stream << GETX(r.user_agent) << r.delimiter;       /* user_agent    */
    stream << ACCOUNT_TYPE << r.delimiter;
    stream << GETX(r.private_ip) << r.delimiter;       /* private_ip    */
    stream << get_ip(r.nat_ip, false) << r.delimiter;  /* srcIP         */
    stream << get_ip(r.nat_ip, true)  << r.delimiter;  /* srcIPv6       */
    stream << r.nat_port << r.delimiter;               /* srcPort       */
    stream << get_ip(r.dest_ip, false) << r.delimiter; /* dstIpv4       */
    stream << get_ip(r.dest_ip, true) << r.delimiter;  /* dstIpv6       */
    stream << r.dest_port << r.delimiter;              /* dstIpv6       */
    stream << r.protocol_type << r.delimiter;          /* protocol_type */
    stream << r.service_cmd << r.delimiter;            /* service_cmd   */
    stream << format_time(r.btime) << r.delimiter;     /* btime         */
    stream << r.lac << r.delimiter;                    /* lac           */
    stream << r.ci  << r.delimiter;                    /* ci            */
    stream << get_ip(r.lnode, false) << r.delimiter;   /* LNodeIpV4     */
    stream << get_ip(r.lnode, true) << r.delimiter;    /* LNodeIpV6     */
    stream << get_ip(r.rnode, false) << r.delimiter;   /* RNodeIpV6     */
    stream << get_ip(r.rnode, true) << r.delimiter;    /* RNodeIpV6     */
    stream << r.request_type << r.delimiter;           /* request_type  */
    stream << GETX(r.url);                             /* url           */
    return stream;
}

std::ostream& operator<< (std::ostream& stream, const IPDRNATlog& r)
{
    stream << r.private_ip << r.delimiter;
    stream << r.source_ip << r.delimiter;
    stream << r.source_port << r.delimiter;
    stream << r.dest_ip << r.delimiter;
    stream << r.dest_port << r.delimiter;
    stream << r.nat_time;
    return stream;
}

std::ostream& operator<< (std::ostream& stream, const IPDRXDRSession& r)
{
    r.write(&stream);
	return stream;
}
