//
// Created by 10209409 on 2/22/2017.
//

#include <cub/base.hxx>
#include <ipdrlogen/ipdr_interface_handler.hxx>
#include <ipdrlogen/common.hxx>
#include <ipdrlogen/http_client.hxx>
#include <ipdrlogen/queue.hxx>
#include <cub/os_utils.hxx>

#include <Poco/JSON/Parser.h>
#include <Poco/File.h>
#include <Poco/StringTokenizer.h>
#include <Poco/Net/HTTPClientSession.h>

using Poco::Util::Application;
using Poco::JSON::Parser;
using Poco::JSON::JSONException;
using Poco::JSON::Object;
using Poco::Dynamic::Var;
using Poco::Dynamic::Struct;
using Poco::DynamicStruct;
using Poco::Net::HTTPRequest;
using Poco::Net::HTTPResponse;
using Poco::Net::HTTPMessage;
using Poco::Path;
using Poco::URI;
using Poco::Exception;
using Poco::File;
using Poco::StringTokenizer;
using Poco::Net::HTTPClientSession;
using Poco::AutoPtr;


time_t monitor_version = time(NULL);
tMonitorMap monitor_terms;
Poco::FastMutex g_mutex;

time_t filter_version = time(NULL);
Poco::FastMutex g_filter_mutex;
filter_set g_filter_msisdn;
filter_set g_filter_url;

FilterContext::FilterContext(LoopQueue<tIpdrFilterContext *> &context_queue, uint8 num):
    _context_queue(context_queue),
    _isStop(0),
    _filter_start(false),
    _thread_start(false),
    _filter_version(filter_version),
    _sftp_server_nums(num)
{
        /*uint16 type = IPDR_KEYWORD_FILTER;
        
        if (num > _filter_thread_pool.capacity())
        {
            _filter_thread_pool.addCapacity(num - _filter_thread_pool.capacity());
        }
        
        for(int i = 0; i < num; i++)
        {
            LoopQueue<IPDRMessage*> *queque = new LoopQueue<IPDRMessage*>;
            KEYWORDfilterFWQueue::ins.push_back(queque);
            _isStop = 0;
            FileWriter* kf_handle = new FileWriter(switch_interval, *KEYWORDfilterFWQueue::ins[i], filter_entries, device_id, _isStop, type);
            _filter_workers.push_back(kf_handle);
        }
        
        for (auto worker : _filter_workers)
        {
            _filter_thread_pool.start(*worker);
        }
        
        _thread_start = true;
        LOG_INFO("keyword filter thread_pool started");
        */

}

FilterContext::~FilterContext()
{
}

void FilterContext::run()
{
    tIpdrFilterContext*  context_entry = NULL;
    IPDRXDRlog *xdr_msg_entry = NULL;
    IPDRXDRSession *line_msg_entry = NULL;
    while (true)
    {
        if (!_context_queue.try_dequeue(context_entry))
        {
            Poco::Thread::sleep(10);
            continue;            
        }

        IPDRKeywordFilter*  fw_ipdr_msg = new IPDRKeywordFilter;
        fw_ipdr_msg->taskId = context_entry->taskId;
        fw_ipdr_msg->trace_type = context_entry->trace_type;
        fw_ipdr_msg->trace_file_name = context_entry->trace_file_name;
        if(fw_ipdr_msg->trace_type ==  IPDR_FILTER_TRACE_ACCESS)
        {
            xdr_msg_entry = new IPDRXDRlog(*(IPDRXDRlog *)(context_entry->ipdr_entry));
            fw_ipdr_msg->ipdr_msg_access = xdr_msg_entry;
        }
        else if(fw_ipdr_msg->trace_type == IPDR_FILTER_TRACE_LINE)
        {
            line_msg_entry = new IPDRXDRSession(*(IPDRXDRSession *)(context_entry->ipdr_entry));
            fw_ipdr_msg->ipdr_msg_line = line_msg_entry;
        }
        uint64 kf_count = context_entry->count;
        uint8  kf_sev_No = kf_count % _sftp_server_nums;
        fw_ipdr_msg->kf_server_No = kf_sev_No;
        if(!KEYWORDfilterFWQueue::ins[kf_sev_No]->enqueue(fw_ipdr_msg))
        {
            if(fw_ipdr_msg->trace_type ==  IPDR_FILTER_TRACE_ACCESS)
            {
                safe_delete(xdr_msg_entry);
            }
            else if(fw_ipdr_msg->trace_type == IPDR_FILTER_TRACE_LINE)
            {
                safe_delete(line_msg_entry);
            }
            safe_delete(fw_ipdr_msg);
        }
        
        safe_delete(context_entry->ipdr_entry);
        safe_delete(context_entry);
    }
}


MoniorHandle::MoniorHandle(LoopQueue<IPDRXDRSession *> &upload_queue):
    _upload_queue(upload_queue)
{
}

MoniorHandle::~MoniorHandle()
{
    
}
void MoniorHandle::run()
{ 
    IPDRXDRSession* ipdr_entry = NULL;
    bool isNeedUpload;
    
    while (true)
    {
		isNeedUpload = true;
        if (!_upload_queue.try_dequeue(ipdr_entry))
        {
            Poco::Thread::sleep(10);
            continue;            
        }
        LOG_INFO(" dequeque monitor-queque with " +ipdr_entry->msisdn);
        AccountMonitor *accountMonitor;
        
        if(g_mutex.tryLock())
        {
            tMonitorMap::iterator item = monitor_terms.find(ipdr_entry->msisdn);
            if(item != monitor_terms.end())
            {
                accountMonitor = item->second;
            }
            else
            {
                isNeedUpload = false;
                LOG_ERROR(" can not find msisdn " +ipdr_entry->msisdn);
                LOG_ERROR(" [MoniorHandle] <monitor_terms> size " +std::to_string(monitor_terms.size())); 
            }
            
            if(isNeedUpload &&  !accountMonitor->get_notify_url().empty())
            {
                httpClient.set_uri(accountMonitor->get_notify_url());
            
                std::string upload_body = write_body(ipdr_entry, const_cast<std::string &>(accountMonitor->get_id()));
                httpClient.post(upload_body);
            }
            g_mutex.unlock();
        }
        safe_delete(ipdr_entry);
    }
}


IPDRInterfaceHandler::IPDRInterfaceHandler()
{
   _remote_path = app_config.getString(UPLOAD_SFTP_ACCESS_PATH);
};

IPDRInterfaceHandler::~IPDRInterfaceHandler()
{
};

void IPDRInterfaceHandler::handleRequest(HTTPServerRequest& request,
        HTTPServerResponse& response)
{
    std::string  uri = request.getURI();
    int northflag = 0;

    LOG_INFO(request.getMethod() + " " + uri + " from " +
             request.clientAddress().toString());

    if ((request.getURI() != INTERFACE_URI)
        || (request.getMethod() != HTTPRequest::HTTP_POST))

    {
        LOG_INFO("invalid " + request.getMethod() + " " + uri + " from " +
                 request.clientAddress().toString());
        send_forbidden(response);
        return;
    }

    std::streamsize body_len = request.getContentLength();

    if (body_len <= 0)
    {
        LOG_INFO("no HTTP body in request info " +
                 request.clientAddress().toString());

        send_forbidden(response);
        return;
    }

    std::istream &body_in = request.stream();

    #if 0
    char *body_buffer = (char *) malloc(static_cast<size_t>(body_len + 1));

    if (body_buffer == nullptr)
    {
        LOG_ERROR("malloc failed, no enough memory.");
        send_status(response, HTTPResponse::HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    memset((void *) body_buffer, 0, static_cast<size_t>(body_len + 1));

    body_in.read(body_buffer, body_len);

    LOG_DEBUG(std::string(body_buffer));
    #endif
    Parser parser;
    Var result;

    try
    {
        result = parser.parse(body_in);
    }

    catch (JSONException &ex)
    {
        LOG_WARN(ex.message());
        //safe_free(body_buffer, free);
        send_status(response, HTTPResponse::HTTP_BAD_REQUEST);
        return;
    }

    catch (...)
    {
        //safe_free(body_buffer, free);
        send_status(response, HTTPResponse::HTTP_BAD_REQUEST);
        return;
    }

    if (result.type() != typeid(Object::Ptr))
    {
        LOG_WARN("request format error " +
                 request.clientAddress().toString());

        //safe_free(body_buffer, free);
        send_status(response, HTTPResponse::HTTP_BAD_REQUEST);
        return;
    }

    Object::Ptr object = result.extract<Object::Ptr>();

    if (object->size() == 0)
    {
        //safe_free(body_buffer, free);
        send_status(response, HTTPResponse::HTTP_BAD_REQUEST);
        return;
    }

    //safe_free(body_buffer, free);

    DynamicStruct ds = *object;

    try
    {
        LOG_INFO("Parsing json " + ds.toString());

        /*关键词过滤 和 用户账号监控入口都是"task"字段*/
        if (ds.contains("task"))
        {
            std::string type = ds["task"]["type"];

            if (type == "account_monitor")
            {
                /* 用户监测请求字段 */
                AccountMonitor *accountMonitor = new AccountMonitor;

                std::string id           = ds["task"]["id"];
                std::string account      = ds["task"]["account"];
                std::string account_type = ds["task"]["accountType"];
                std::string monitor_type = ds["task"]["monitorType"];
                std::string notify_url   = ds["task"]["usrOnlinUrl"];

                accountMonitor->set_id(id);
                accountMonitor->set_account(account);
                accountMonitor->set_type(type);
                accountMonitor->set_notify_url(notify_url);
                accountMonitor->set_account_type(static_cast<uint8>(std::stoi(
                                                     account_type)));
                accountMonitor->set_monitor_type(static_cast<uint8>(std::stoi(
                                                     monitor_type)));
                accountMonitor->_isUpload = false;
                // ToDo:
                bool action_result = false;
                bool is_free = false;
                uint8 action_type = accountMonitor->get_monitor_type();
                // add monitor list
                if(g_mutex.tryLock() && 
                    monitor_terms.size() <= account_num)
                {
                    // 
                    tMonitorMap::iterator item = monitor_terms.find(account);
                    if(item == monitor_terms.end())
                    {
                        // not exist
                        if(action_type == 1)
                        {
                            monitor_terms.insert(tMonitorMap::value_type(account, accountMonitor));
                            action_result = true;
                            monitor_version = time(NULL);
                            LOG_INFO("[handleRequest] start to monitor account : " +account);
                            LOG_INFO("[handleRequest] monitor_version : " +std::to_string(monitor_version));
                            LOG_INFO("[handleRequest] <monitor_terms> size " +std::to_string(monitor_terms.size()));
                        }else{
                            LOG_INFO("account not be monitor, but try to stop " +account);
                        }
                    }
                    else  
                    {
                        if (action_type == 2)
                        {
                            safe_delete(item->second);
                            monitor_terms.erase(item);
                            action_result = true;
                            is_free = true;
                            monitor_version = time(NULL);
                            LOG_INFO("[handleRequest] stop to monitor account : " +account);
                            LOG_INFO("[handleRequest] monitor_version : " +std::to_string(monitor_version));
                            LOG_INFO("[handleRequest] <monitor_terms> size " +std::to_string(monitor_terms.size()));
                        }
                        else
                        {
                            LOG_INFO("account exits : " +account);
                            action_result = true;
                            is_free = true;
                        }
                    }
                    g_mutex.unlock();

                }

                send_action_result(response, action_result,
                                   const_cast<std::string &>(accountMonitor->get_id()), monitor_result);

                if(!action_result || is_free)
                {
                    safe_delete(accountMonitor);
                }

            }

            else if (type == "filter_request")
            {
                Filter filter_entry;
                /* 关键词过滤请求字段 */

                std::string id          = ds["task"]["id"];
                std::string field       = ds["task"]["field"];
                std::string filter_type = ds["task"]["filterType"];
                std::string field_type  = ds["task"]["fieldType"];

                filter_entry.set_id(id);
                filter_entry.set_field(field);
                filter_entry.set_type(type);
                filter_entry.set_field_type(((field_type == "1") ? FILTER_FIELD_TYPE_MSISDN :
                                        FILTER_FIELD_TYPE_URL));

                filter_entry.set_filter_type(((filter_type == "1") ? FILTER_ACTION_START :
                                         FILTER_ACTION_STOP));

                // ToDo:
                bool action_result = false;
                int msdn_size = g_filter_msisdn.filter_items.size();
                int url_size = g_filter_url.filter_items.size();

                int i = 0;
                bool flag= false;
                if(g_filter_mutex.tryLock() && 
                        msdn_size + url_size <= filter_num)
                { 
                    //start filter
                    if(filter_type == "1")
                    {
                        switch (filter_entry.get_field_type())
                        {
                            // msisdn
                            case FILTER_FIELD_TYPE_MSISDN:
                            {
                                for(i = 0; i < msdn_size; i++)
                                {
                                    Filter msdn_filter = g_filter_msisdn.filter_items[i];
                                    if( msdn_filter.get_field() == field)
                                    {   
                                        // already exist
                                        LOG_INFO("msiddn is already filter " +field);
                                        flag = true;
                                        break;
                                     }
                                }
                                if(!flag)
                                {
                                    g_filter_msisdn.filter_items.push_back(filter_entry);
                                    filter_version = time(NULL);
                                }
                                action_result = true;
                                break;
                            }
                            
                            case FILTER_FIELD_TYPE_URL:
                            {
                                for(i = 0; i < url_size; i++)
                                {
                                    Filter url_filter = g_filter_url.filter_items[i];
                                    if( url_filter.get_field() == field)
                                    {
                                        LOG_INFO("url is already filter " +field);
                                        flag = true;
                                        break;
                                    }
                                }
                                if(!flag)
                                {
                                    g_filter_url.filter_items.push_back(filter_entry);
                                    filter_version = time(NULL);
                                }
                                action_result = true;
                                break;
                            }
                            default:
                            {
                                break;
                            }
                        }
                    }else if(filter_type == "2")
                    {
                        //stop filter
                        switch (filter_entry.get_field_type())
                        {
                            // msisdn
                            case FILTER_FIELD_TYPE_MSISDN:
                            {
                                for(i = 0; i < msdn_size; i++)
                                {
                                    Filter msdn_filter = g_filter_msisdn.filter_items[i];
                                    if( msdn_filter.get_field() == field)
                                    {
                                        // find it, erase
                                        std::vector<Filter>::iterator it = g_filter_msisdn.filter_items.begin()+i;
                                        g_filter_msisdn.filter_items.erase(it);
                                        LOG_INFO("msisdn stop fiter ok " +field);
                                        filter_version = time(NULL);
                                        action_result = true;
                                        break;
                                     }
                                }
                                if(!action_result){
                                    LOG_INFO("msisdn not be filtered, but try to stop " +field);
                                }
                                break;
                            }
                            
                            case FILTER_FIELD_TYPE_URL:
                            {
                                for(i = 0; i < url_size; i++)
                                {
                                    Filter url_filter = g_filter_url.filter_items[i];
                                    if( url_filter.get_field() == field)
                                    {
                                        std::vector<Filter>::iterator it = g_filter_url.filter_items.begin()+i;
                                        g_filter_url.filter_items.erase(it);
                                        LOG_INFO("url stop fiter ok " +field);
                                        filter_version = time(NULL);
                                        action_result = true;
                                        break;
                                    }
                                }
                                if(!action_result){
                                    LOG_INFO("url not be filtered but try to stop" +field);
                                }
                                break;
                            } 
                            default:
                            {
                                break;
                            }
                        }
                    }
                    LOG_INFO("<msisdn filter> size " +std::to_string(g_filter_msisdn.filter_items.size()));
                    LOG_INFO("<url    filter> size " +std::to_string(g_filter_url.filter_items.size()));
                    g_filter_mutex.unlock();
                }
                send_action_result(response, action_result,
                                   const_cast<std::string &>(filter_entry.get_id()), filter_result);

            }

            else
            {
                LOG_INFO("error contains  \"task\" type is invalid!");
            }
        }

        /*溯源信息重传*/
        else if (ds.contains("info"))
        {
            std::string type = ds["info"]["type"];

            if (type == "query_request")
            {
                std::string fail_reason;
                bool action_result = true;

                std::string id = ds["info"]["id"];
                FileReTransfer fileReTransfer;
                fileReTransfer.set_id(id);
                fileReTransfer.set_type(type);

                if (!ds["info"]["beginTime"].isEmpty())
                {
                    std::string begin_time = ds["info"]["beginTime"];
                    std::string end_time = ds["info"]["endTime"];

                    fileReTransfer.set_begin_time(std::stoull(begin_time) * 1000);
                    fileReTransfer.set_end_time(std::stoull(end_time) * 1000);

                    if (fileReTransfer.get_begin_time() >= fileReTransfer.get_end_time())
                    {
                        action_result = false;
                        fail_reason = TIME_ERROR;
                    }

                    else if (fileReTransfer.get_end_time() - fileReTransfer.get_begin_time() >
                             THREE_DAYS_IN_MICROSECONDS)
                    {
                        action_result = false;
                        fail_reason = TIME_EXCEED_THREE_DAYS;
                    }

                    fileReTransfer.set_match_type(FILE_MATCH_TIME);
                }

                else if (!ds["info"]["fileName"].isEmpty())
                {
                    std::string file_name = ds["info"]["fileName"];
                    fileReTransfer.set_file_name(file_name);
                    fileReTransfer.set_match_type(FILE_MATCH_NAME);
                }

                else
                {
                    action_result = false;
                    fail_reason = RULE_ERROR;
                }

                if (action_result)
                {
                    action_result = process_re_transfer(fileReTransfer, fail_reason);
                }

                send_re_transfer_process_result(response, action_result, fail_reason);
            }
        }

        else
        {
            LOG_WARN("Unknown request info + ");
            send_status(response, HTTPResponse::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    catch (Poco::Exception ex)
    {
        LOG_WARN(ex.displayText());
        send_status(response, HTTPResponse::HTTP_INTERNAL_SERVER_ERROR);
    }
}

void IPDRInterfaceHandler::send_action_result(HTTPServerResponse & response,
        bool success,
        std::string& account_info,
        std::string& type)
{
    std::ostream& res = response.send();

    response.setContentType("application/json");

    res << "{" << std::endl;

    res << "    \"result_id\"   : \"" << account_info << "\"," <<
        std::endl;
    res << "    \"type\"        : \"" << type << "\"," << std::endl;

    res << "    \"resultCode\"  : " << (success ? Succeed : Failed) << ","
        << std::endl;

    res << "    \"successList\" : \"" << (success ? " " : empty) <<  "\","
        << std::endl;

    res << "    \"failList\"    : \"" << (success ? " " : empty) << "\"" <<
        endl;

    res << "}" << endl;
    return;
}

void IPDRInterfaceHandler::send_re_transfer_process_result
(HTTPServerResponse & response,
 bool success,
 const std::string &fail_reason)
{
    std::ostream& res = response.send();

    response.setContentType("application/json");

    res << "{" << std::endl;
    res << "    \"resultCode\" : \"" << (success ? Succeed : Failed) << "\","
        << std::endl;
    res << "    \"failReason\" : \"" << fail_reason << "\"" << std::endl;
    res << "}" << std::endl;
}

bool IPDRInterfaceHandler::process_re_transfer(FileReTransfer&
        fileReTransfer, std::string& fail_reason)
{

    if (fileReTransfer.get_match_type() == FILE_MATCH_NAME)
    {
        time_t btime = time(NULL); // second
        btime *=1000000;
        for (int i = 0; i <= 3 ; i++)
        {
            Timestamp file_ts(static_cast<Timestamp::TimeVal>(btime));
            LocalDateTime dir_time(file_ts);
            std::string dir = XDR_ROOT_DIR;
            btime -= MICROSECONDS_PER_DAY;
            dir.append(DateTimeFormatter::format(dir_time, XDR_DIR_FORMAT));
            File path(dir);

            if (!path.exists())
            {
                continue;
            }

            try
            {
                if (!path.isDirectory())
                {
                    continue;
                }
            }

            catch (...)
            {
                continue;
            }

            {
                std::vector <File> files;
                path.list(files);

                for (auto file : files)
                {
                    if (!file.isFile())
                    {
                        continue;
                    }

                    const std::string& path = file.path();

                    if (path.find(fileReTransfer.get_file_name()) != std::string::npos)
                    {
                        if (path.find(OK_SUFFIX) != std::string::npos)
                        {
                            continue;
                        }
                        
                        LOG_INFO("Adding " + path + " to re-transfer list.");
                        std::string file_name = cub::basename(file.path());
                        
                        UploadInfo* uploadInfo = new UploadInfo;
                        uploadInfo->set_local_file(file.path());
                        uploadInfo->set_remote_path(_remote_path);
                        std::string md5 = "re_transfer";
                        uploadInfo->set_file_md5(md5);
                        
                        if (!SFTPUploadQueue::Instance.enqueue(uploadInfo))
                        {
                            LOG_ERROR("Error dispatching SFTP uploading for " + file.path());
                            safe_delete(uploadInfo);
                        }
                        return true;
                    }

                }
            }
        }
        fail_reason = FILE_NOT_EXIST;
        return false;
    }

    else
    {
        uint64 begin_time = fileReTransfer.get_begin_time();
        uint64 end_time   = fileReTransfer.get_end_time();
        uint32 file_count = 0;
        for (; begin_time <= end_time; begin_time += MICROSECONDS_PER_DAY)
        {
            Timestamp ts(static_cast<Timestamp::TimeVal>(begin_time));
            LocalDateTime filetime(ts);

            std::string dir = XDR_ROOT_DIR;

            dir.append(DateTimeFormatter::format(filetime, XDR_DIR_FORMAT));

            File path(dir);

            if (!path.exists())
            {
                fail_reason = FILE_NOT_EXIST;
                continue;
            }

            try
            {
                if (!path.isDirectory())
                {
                    fail_reason = FILE_NOT_EXIST;
                    continue;
                }
            }

            catch (...)
            {
                continue;
            }

            {
                std::vector <File> files;
                path.list(files);

                for (auto file : files)
                {
                    if (!file.isFile())
                    {
                        continue;
                    }

                    const std::string& path = file.path();

                    if (path.find(XDR_FILE_SUFFIX) == std::string::npos)
                    {
                        continue;
                    }
                    
                    if (path.find(OK_SUFFIX) != std::string::npos)
                    {
                        continue;
                    }
                    
                    Timestamp::TimeVal timestamp = file.getLastModified().raw();

                    if (timestamp  < begin_time || timestamp > end_time)
                    {
                        continue;
                    }

                    LOG_DEBUG("Adding " + path + " to re-transfer list.");
                    std::string file_name = cub::basename(file.path());
                    StringTokenizer fields(file_name, NAME_FILED_DELIMITER);
                    std::string file_type = fields[0];
                    if(true)
                    {
                        UploadInfo* uploadInfo = new UploadInfo;
                        uploadInfo->set_local_file(file.path());
                        uploadInfo->set_remote_path(_remote_path);
                        std::string md5 = "re_transfer";
                        uploadInfo->set_file_md5(md5);
                        
                        if (!SFTPUploadQueue::Instance.enqueue(uploadInfo))
                        {
                            LOG_ERROR("Error dispatching SFTP uploading for " + file.path());
                            safe_delete(uploadInfo);
                        }
                    }

                    file_count++;
                }
            }
        }

        if (file_count == 0)
        {
            fail_reason = FILE_NOT_EXIST;
            return false;
        }

        return true;
    }
}
