#include <ipdrlogen/counter.hxx>
#include <ipdrlogen/common.hxx>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

int Counter::write_counter()
{
    int handle;
    ssize_t ret;
    size_t  counter_size = sizeof(_counter);

    /* write and read access for current user only                        */
    handle = open(counter_file.c_str(), O_WRONLY | O_CREAT, (S_IRUSR | S_IWUSR ));

    /* error opening file, return error, error handling for caller        */
    if (handle == -1)
    {
        LOG_ERROR("Can not open file " + counter_file + ": " + strerror(errno));
        return -1;
    }

    /* assuming nobody touchs the file, otherwise god knows what happened */
    ret = pwrite(handle, reinterpret_cast<void*>(&_counter), counter_size,
                 (off_t)0);

    if (ret != counter_size)
    {
        LOG_ERROR("pwrite returns error, excepted : " + std::to_string(
                      counter_size) + ", actual : "
                  + std::to_string(ret));
        close(handle);
        return -1;
    }

    close(handle);
    LOG_DEBUG("counter saved, counter = " + std::to_string(_counter));
    return 0;
}


int Counter::read_counter()
{
    int handle;
    ssize_t ret;
    size_t  counter_size = sizeof(_counter);

    /* read only is enough                                                */
    handle = open(counter_file.c_str(), O_RDONLY);

    /* error opening file, return error, error handling for caller        */
    if (handle == -1)
    {
        LOG_ERROR("Can not open file " + counter_file + ": " + strerror(errno));
        return -1;
    }

    /* assuming nobody touchs the file, otherwise god knows what happened */
    ret = pread(handle, reinterpret_cast<void*>(&_counter), counter_size,
                off_t(0));

    if (ret != counter_size)
    {
        LOG_ERROR("counter file length mismatch: excepted: " + std::to_string(
                      counter_size) + ", actual: " + std::to_string(ret));
        close(handle);
        return -1;
    }

    LOG_DEBUG("counter restored, counter = " + std::to_string(_counter));

    close(handle);
    return 0;
}