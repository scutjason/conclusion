//
// Created by 10209409 on 2/16/2017.
//
#include <ipdrlogen/ipdr_server_handler.hxx>
#include <ipdrlogen/perform_stats.hxx>
#include <ipdrlogen/queue.hxx>
#include <ipdrlogen/hash.hxx>
#include <cub/os_utils.hxx>

#include <Poco/Net/SocketAcceptor.h>
#include <Poco/NObserver.h>
#include <Poco/Delegate.h>
#include <Poco/Util/ServerApplication.h>
#include <Poco/StringTokenizer.h>

using Poco::Net::SocketReactor;
using Poco::Net::SocketAcceptor;
using Poco::Net::ReadableNotification;
using Poco::Net::WritableNotification;
using Poco::Net::ShutdownNotification;
using Poco::Net::ServerSocket;
using Poco::Net::StreamSocket;
using Poco::NObserver;
using Poco::AutoPtr;
using Poco::Logger;
using Poco::delegate;
using Poco::StringTokenizer;
using namespace Poco::Util;

LoopQueue<IPDRXDRSession*> ACCOUNTMonitorQueue::Instance;
LoopQueue<IPDRMessage*> KEYWORDfilterFWQueue::Instance;
std::vector<LoopQueue<IPDRMessage*> *> KEYWORDfilterFWQueue::ins;
LoopQueue<tIpdrFilterContext*> KEYWORDfilterContextQueue::Instance;


IPDRServerHandler::IPDRServerHandler(StreamSocket& socket,
                                     SocketReactor& reactor):
    _socket(socket),
    _reactor(reactor),
    _is_stop_thread(0),
    _is_create_file(0),
    _send_buffer(BUFFER_SIZE, true)
{
    LOG_DEBUG("Connection from " + socket.peerAddress().toString());

    _recv_buffer.init(BUFFER_SIZE, false);

    _reactor.addEventHandler(_socket,
                             NObserver<IPDRServerHandler, ReadableNotification>(*this,
                                     &IPDRServerHandler::on_socket_readable));
    _reactor.addEventHandler(_socket,
                             NObserver<IPDRServerHandler, ShutdownNotification>(*this,
                                     &IPDRServerHandler::on_socket_shutdown));

    _send_buffer.readable += delegate(this,
                                      &IPDRServerHandler::on_send_buffer_readable);

    uint32 switch_interval  = app_config.getUInt(LOGEN_FILE_SWITCH_INTERVAL, 300);
    uint16 type = 0;
    uint16 flag = 1;
    // thread pool
    if (thread_num > _write_pool.capacity())
    {
        _write_pool.addCapacity(thread_num - _write_pool.capacity());
    }

	// Start the handle writing thread.
    for (uint32 i = 0; i < thread_num; i += 1)
    {
        FileWriter * write_handle = new FileWriter(switch_interval, _write_queue, max_entry_num, device_id, _is_stop_thread, type,flag,0);
        _write_handles.push_back(write_handle);
    }

    for (auto worker : _write_handles)
    {
        _write_pool.start(*worker);
    }
	
	// Start write the session thread.
	type = IPDR_SESSION;
	_session_writer = new FileWriter(switch_interval, _write_session_queue, max_entry_num, device_id, _is_stop_thread, type, _is_create_file,0);
	_write_session_thread.start(*_session_writer);
	
	// Start the session handle thread
	_session_handle = new SessionHandle(_session_queue, _write_session_queue, _is_stop_thread);
	_session_thread.start(*_session_handle);


    _line_db_handle = new LineDb(_session_queue, _write_session_queue, _is_stop_thread);
    _lien_db_thread.start(*_line_db_handle);

	
	// Start the handle data thread.
	_data_handle = new DataHandle(_data_queue, _write_queue, _session_queue, _is_stop_thread);
	_data_thread.start(*_data_handle);
	
    LOG_INFO("data handle && writer thread started!");

}

IPDRServerHandler::~IPDRServerHandler()
{
    try
    {
        LOG_DEBUG("Disconnecting " + _socket.peerAddress().toString());
    }

    catch (...)
    {
    }

    _recv_buffer.reset();
    
    _reactor.removeEventHandler(_socket,
                                NObserver<IPDRServerHandler, ReadableNotification>(*this,
                                        &IPDRServerHandler::on_socket_readable));
    _reactor.removeEventHandler(_socket,
                                NObserver<IPDRServerHandler, WritableNotification>(*this,
                                        &IPDRServerHandler::on_socket_writable));
    _reactor.removeEventHandler(_socket,
                                NObserver<IPDRServerHandler, ShutdownNotification>(*this,
                                        &IPDRServerHandler::on_socket_shutdown));

    _send_buffer.readable -= delegate(this,
                                      &IPDRServerHandler::on_send_buffer_readable);
                                          _recv_buffer.reset();

										  
    while(true)
    {
	
        if(_data_queue.pending() == 0 &&
            _write_queue.pending() == 0 &&
            _session_queue.pending() == 0 &&
            _write_session_queue.pending() ==0)
        {
            // stop & join
            _is_stop_thread = 1;
            
			_write_session_thread.join();
			_session_thread.join();
			safe_delete(_session_writer);
			safe_delete(_session_handle);

			_lien_db_thread.join();
            safe_delete(_line_db_handle);
			
			_data_thread.join();
            safe_delete(_data_handle);
            
            _write_pool.joinAll();
            _write_pool.stopAll();

            for (auto worker : _write_handles)
            {
                safe_delete(worker);
            }
            break;
        }

    }
    LOG_INFO("data handle && writer thread stopted!");
}

void IPDRServerHandler::on_send_buffer_readable(bool& init)
{
    if (init)
    {
        _reactor.addEventHandler(_socket,
                                 NObserver<IPDRServerHandler, WritableNotification>(*this,
                                         &IPDRServerHandler::on_socket_writable));
    }

    else
    {
        _reactor.removeEventHandler(_socket,
                                    NObserver<IPDRServerHandler, WritableNotification>(*this,
                                            &IPDRServerHandler::on_socket_writable));
    }
}

void IPDRServerHandler::on_socket_readable(const AutoPtr<ReadableNotification>&
        pNf)
{
    try
    {
        int read_count = _socket.receiveBytes(reinterpret_cast<void*>
                                              (_recv_buffer.write_ptr()),
                                              static_cast<int>(_recv_buffer.space()));

        LOG_DEBUG("Data received : " + std::to_string(read_count));

        if ( read_count > 0)
        {
            _recv_buffer.write_ptr(static_cast<size_t>(read_count));
            
            int result = parse_data(read_count);
            
            if (result == CUB_ERROR)
            {
                LOG_INFO("Data parse : error");
                delete this;
            }
        }

        else
        {
            LOG_INFO("Data received : error recv_buffer" + std::to_string(_recv_buffer.space()));
            delete this;
        }
    }

    catch (Poco::Exception& exc)
    {
        LOG_WARN(exc.displayText());
        delete this;
    }
}

void IPDRServerHandler::on_socket_writable(const AutoPtr<WritableNotification>&
        pNf)
{
    try
    {
        LOG_DEBUG("Sending data to client : " + _socket.peerAddress().toString() +
                  ", size : " + std::to_string(_send_buffer.used()));
        _socket.sendBytes(_send_buffer);
    }

    catch (Poco::Exception& exc)
    {
        LOG_WARN(exc.displayText());
        delete this;
    }
}

void IPDRServerHandler::on_socket_shutdown(const AutoPtr<ShutdownNotification>&
        pNf)
{
    delete this;
}

int IPDRServerHandler::read(char *buf, int count, int &read_count)
{
    assert( buf != NULL );
    read_count = 0;
    int sock_fd = _socket.impl()->sockfd();

    if ( -1 == sock_fd)
    {
        LOG_ERROR("Invalid socket fd, client = " + _socket.peerAddress().toString() +
                  ", fd = " + std::to_string(sock_fd));
        return CUB_ERROR;
    }

    if ( count <=  0 )
    {
        return CUB_OK;
    }


    int read_result = cub::block_read(sock_fd, buf, count, read_count);

    if ((0 == read_result) && (0 == errno))
    {
        // 对方关闭连接
        LOG_INFO("Connection closed by client " + _socket.peerAddress().toString());

        return CUB_ERROR;
    }

    else if (read_result < 0)
    {
        LOG_ERROR("Error occurred when reading data from client " +
                  _socket.peerAddress().toString() + " : " + strerror(errno));
        return CUB_ERROR;
    }

    read_count = read_result;

    return CUB_OK;
}

int IPDRServerHandler::parse_data(int bytes)
{
#if 1
    int result = CUB_OK;
    do
    {
        if (_recv_buffer.length() < static_cast<size_t>(IPDR_HEADER_LENGTH))
        {
            // not enough data, pending.
            LOG_DEBUG("no enough data, waiting for more, received : " + std::to_string(
                          _recv_buffer.length()));
            result = CUB_READ_PART;
            break;
        }

        // =========   now we can decode message head   =========
        uint16 magic;
        uint16 length;
        uint16 xdr_type;

        cub::decode(_recv_buffer.read_ptr() + IPDR_HEADER_MAGIC_OFFSET, magic);
        cub::decode(_recv_buffer.read_ptr() + IPDR_HEADER_LENGTH_OFFSET, length);
        cub::decode(_recv_buffer.read_ptr() + IPDR_HEADER_TYPE_OFFSET, xdr_type);

        if (magic != IPDR_PACKAGE_MAGIC)
        {
            LOG_WARN("invalid message head magic received : " + std::to_string(magic));
            result = CUB_ERROR;
            break;
        }

        // data not ready, pending
        if (_recv_buffer.length() < static_cast<size_t>(length + IPDR_HEADER_LENGTH))
        {
            LOG_DEBUG("no enough data, waiting for more, received : " + std::to_string(
                          length));
            result = CUB_READ_PART;
            break;
        }

        uint16 entry_length = 0;
        char* buffer;
        
        switch (xdr_type)
        {
            case IPDR_XDR:
            {
                //LOG_INFO("=================================IPDR_XDR comming");
                if(line_version == 1)
                {
                    _is_create_file = 1;
                }
                
                buffer = (char *)malloc(length + IPDR_HEADER_LENGTH);
                memcpy(buffer, _recv_buffer.read_ptr(), length + IPDR_HEADER_LENGTH);
                if (!_data_queue.enqueue(buffer))
                {
                    LOG_ERROR("Error enqueing XDR ");
                    safe_free(buffer, free);
                }else{
                    //__interlocked_add_exchange64(&PerformStats::_rx_xdr_bytes, length + IPDR_HEADER_LENGTH);
                    //__interlocked_add_exchange64(&PerformStats::_en_access_nums, 1);
                }
                break;
            }

            case IPDR_NAT:
            {
                buffer = (char *)malloc(length + IPDR_HEADER_LENGTH);
                memcpy(buffer, _recv_buffer.read_ptr(), length + IPDR_HEADER_LENGTH);
                if (!_data_queue.enqueue(buffer))
                {
                    LOG_ERROR("Error enqueing NAT ");
                    safe_free(buffer, free);
                }else{
  			        //__interlocked_add_exchange64(&PerformStats::_rx_nat_bytes, length + IPDR_HEADER_LENGTH);
                    //__interlocked_add_exchange64(&PerformStats::_en_nat_nums, 1);
                }
                break;
            }
            case IPDR_SESSION:
            {
                buffer = (char *)malloc(length + IPDR_HEADER_LENGTH);
                memcpy(buffer, _recv_buffer.read_ptr(), length + IPDR_HEADER_LENGTH);
                if (!_data_queue.enqueue(buffer))
                {
                    LOG_ERROR("Error enqueing LINE "+std::to_string(_data_queue.pending()));
                    safe_free(buffer, free);
                }else{
  			        //__interlocked_add_exchange64(&PerformStats::_rx_line_bytes, length + IPDR_HEADER_LENGTH);
                    //__interlocked_add_exchange64(&PerformStats::_en_line_nums, 1);
                }
                break;
            }

            case IPDR_HEART_BEAT:
            {
                send_heart_beat();
                LOG_DEBUG("heart beat message received, echo back.");
                break;
            }

            default:
            {
                LOG_WARN("invalid message type received : " + std::to_string(xdr_type));
                result = CUB_ERROR;
                break;
            }
        }

        if (result == CUB_ERROR)
        {
            break;
        }
        // packet ready
        
        _recv_buffer.read_ptr(static_cast<size_t>(length + IPDR_HEADER_LENGTH));
    }
    while (true);

    if (CUB_ERROR == result)
    {
        _recv_buffer.reset();
    }
    
    _recv_buffer.tidy();
    return result;
#endif
}

void IPDRServerHandler::send_heart_beat()
{
    char header_buffer[IPDR_HEADER_LENGTH] = {0};
    char * dest = header_buffer;
    dest += cub::encode(dest, IPDR_PACKAGE_MAGIC);
    dest += cub::encode(dest, uint16(0));
    dest += cub::encode(dest, IPDR_HEART_BEAT);

    _send_buffer.write(header_buffer, IPDR_HEADER_LENGTH);
}


DataHandle::DataHandle(LoopQueue<char*>& queue, 
                       LoopQueue<IPDRMessage *> &write_queue, 
                       LoopQueue<IPDRMessage *> &session_queue, 					   
					   uint16& isStop):
    _data_queue(queue),
	_write_queue(write_queue),
	_session_queue(session_queue),
    _isStop(isStop)
{
}

DataHandle::~DataHandle()
{
    
}

void DataHandle::run()
{
    while (!_isStop)
    {
	    char* ipdr_entry = NULL;
		
        if (!_data_queue.try_dequeue(ipdr_entry))
        {
            Poco::Thread::sleep(5);
            continue;            
        }

        uint16 length =0;
        uint16 message_type = 0;
        uint16 magic = 0;
        
		cub::decode((char *)ipdr_entry + IPDR_HEADER_MAGIC_OFFSET, magic);
        cub::decode((char *)ipdr_entry + IPDR_HEADER_LENGTH_OFFSET, length);
        cub::decode((char *)ipdr_entry + IPDR_HEADER_TYPE_OFFSET, message_type);
        
        switch (message_type)
        {
            case IPDR_XDR:
            {  
                IPDRXDRlog *ipdr_xdr_entry = new IPDRXDRlog();
				uint16 actual_length = 0;
                ipdr_xdr_entry->decode(ipdr_entry + IPDR_HEADER_LENGTH, actual_length);
                if (length != actual_length)
                {
                    LOG_WARN("xdr Decode fail, length mismatch, excepted : " + std::to_string(
                                 length) + ", actual : " + std::to_string(actual_length));
                }
				if(line_version == 1)
				{
    	            IPDRXDRlog *clone = new IPDRXDRlog(*ipdr_xdr_entry);
                    if(!_session_queue.enqueue(clone))
    	    		{
    			        LOG_WARN("Enqueue the xdr to session queue failed.");
    			        safe_delete(clone);
    		    	}
			    }	
			    if(!_write_queue.enqueue(ipdr_xdr_entry))
		    	{
                    LOG_ERROR("Error enqueing XDR to _write_queue , queue size " + std::to_string(_write_queue.pending())); 
                    safe_delete(ipdr_xdr_entry);
  			    }
                //__interlocked_add_exchange64(&PerformStats::_de_access_nums, 1);
                
                break;
            }
            
            case IPDR_NAT:
            {
                IPDRNATlog *ipdr_nat_entry = new IPDRNATlog();
				uint16 actual_length = 0;
                ipdr_nat_entry->decode(ipdr_entry + IPDR_HEADER_LENGTH, actual_length);
                if (length != actual_length)
                {
                    LOG_WARN("nat Decode fail, length mismatch, excepted : " + std::to_string(
                                 length) + ", actual : " + std::to_string(actual_length));
                }
                if(!_write_queue.enqueue(ipdr_nat_entry))
                {
                    LOG_ERROR("Error enqueing XDR to _write_queue");
                    safe_delete(ipdr_nat_entry);
                }
                //__interlocked_add_exchange64(&PerformStats::_de_nat_nums, 1);  
                break;
            }
            case IPDR_SESSION:
            {
                uint8 flag = 0;
                IPDRXDRSession *off_session = NULL;
                IPDRXDRSession *on_session  = NULL;
                IPDRXDRSession *ipdr_session_entry = new IPDRXDRSession();
				uint16 actual_length = 0;
                ipdr_session_entry->decode(ipdr_entry + IPDR_HEADER_LENGTH, actual_length);
                if (length != actual_length)
                {
                    LOG_WARN("session Decode fail, length mismatch, excepted : " + std::to_string(
                                 length) + ", actual : " + std::to_string(actual_length));
                    safe_delete(ipdr_session_entry);
                    break;
                }

                //__interlocked_add_exchange64(&PerformStats::_de_line_nums, 1);

                
                /* failed */
                if(ipdr_session_entry->procedure_status == 0 ||
                    ipdr_session_entry->msisdn.size() == 0)
                {
                    safe_delete(ipdr_session_entry);
                    break;
                }
                /* TAC */
                if(ipdr_session_entry->procedure_type == 0)
                {
                    /* offline */
                    ipdr_session_entry->online = false;
                }
                else if(ipdr_session_entry->procedure_type == 1)
                {
                    /* online */
                    ipdr_session_entry->online = true;
                }
                else if(ipdr_session_entry->procedure_type == 5)
                {
                    flag = 1;
                    off_session = new IPDRXDRSession(*ipdr_session_entry);
                    off_session->online = false;
                    off_session->lac=off_session->other_tac;
                    off_session->ci=off_session->other_eci;
                    
                    on_session  = new IPDRXDRSession(*ipdr_session_entry);
                    on_session->online = true;
                    on_session->lac=on_session->other_tac;
                    on_session->ci=on_session->other_eci;
                }
                else
                {
                    LOG_DEBUG(" can not parse this type: " + std::to_string(ipdr_session_entry->procedure_type));
                    safe_delete(ipdr_session_entry);
                    break;
                }

                /* normal line */
                if(flag == 0)
                {
                    ipdr_session_entry->lac=ipdr_session_entry->tac;
                    ipdr_session_entry->ci=ipdr_session_entry->cell_id;
   
                    IPDRXDRSession *clone = new IPDRXDRSession(*ipdr_session_entry);
                    
                    if(!_session_queue.enqueue(clone))
    	    		{
    			        LOG_WARN("Enqueue the xdr to session queue failed.");
    			        safe_delete(clone);
    		    	}
                    
                    if(!_write_queue.enqueue(ipdr_session_entry))
                    {
                        LOG_ERROR("Error enqueing session to _write_queue");
                        safe_delete(ipdr_session_entry);
                    }
                }
		    	else
		    	{
                    IPDRXDRSession *clone_online = new IPDRXDRSession(*on_session);
                    
                    if(!_session_queue.enqueue(clone_online))
    	    		{
    			        LOG_WARN("Enqueue the xdr to session queue failed. size :" + std::to_string(_session_queue.pending()));
    			        safe_delete(clone_online);
    		    	}
                    if(!_write_queue.enqueue(off_session))
                    {
                        LOG_ERROR("Error enqueing off_session to _write_queue");
                        safe_delete(off_session);
                    }
                    if(!_write_queue.enqueue(on_session))
                    {
                        LOG_ERROR("Error enqueing on_session  to _write_queue");
                        
                        safe_delete(on_session);
                    }
                    safe_delete(ipdr_session_entry);
		    	}
                break;
            }
            default:
            {
			    LOG_WARN("Receiving a log entry with unknown message type " + std::to_string(message_type));
                break;
            }
        }
        safe_free(ipdr_entry, free);
    }
}




LineDb::LineDb(LoopQueue<IPDRMessage*>& queue, LoopQueue<IPDRMessage*> &write_queue, uint16& isStop):
    _session_queue(queue),
    _write_queue(write_queue),
    _isStop(isStop)
{
    _last_do_ageing = time(NULL);
}

LineDb::~LineDb()
{
    
}

void LineDb::run()
{
    int cnt1 = 0;
    int cnt2 = 0;
    while (!_isStop)
    {
        // entry 1
        Poco::Thread::sleep(10000);
        IPDRXDRlog* entry1     = new IPDRXDRlog;
        entry1->btime           = 1509527560.790;
        entry1->msisdn          = "18805318929";
        entry1->imsi            = "460078541544023";
        entry1->imei            = "8622980363921378";
        entry1->private_ip      = "0.0.0.1";
        entry1->nat_ip          = "0.0.0.1";
        entry1->nat_port        = 43494;
        entry1->dest_ip         = "0.0.0.1";
        entry1->dest_port       = 53;
        entry1->protocol_type   = 4;
        entry1->service_cmd     = 999;
        entry1->lac             = 25356;
        entry1->ci              = 91626509;
        entry1->rnode           = "0.0.0.1";
        entry1->lnode           = "0.0.0.1";
        entry1->request_type    = 0;
        entry1->url             = "www.alibaba.com";

        if(1 > cnt1){
            if(!_session_queue.enqueue(entry1)){
                LOG_INFO(" 1== put entry1 error " +entry1->msisdn);
                safe_delete(entry1);
            }else{
                LOG_INFO(" 1== put entry1 ok " +entry1->msisdn);
            }
            cnt1++;
        }else{
            safe_delete(entry1);
        }
        #if 0
        // entry 1
        Poco::Thread::sleep(10000);
        IPDRXDRlog* entry1_1     = new IPDRXDRlog;
        entry1_1->btime           = 1509527560.790;
        entry1_1->msisdn          = "18805318929";
        entry1_1->imsi            = "460078541544023";
        entry1_1->imei            = "8622980363921378";
        entry1_1->private_ip      = "0.0.0.1";
        entry1_1->nat_ip          = "1.1.1.1";
        entry1_1->nat_port        = 43494;
        entry1_1->dest_ip         = "1.1.1.1";
        entry1_1->dest_port       = 53;
        entry1_1->protocol_type   = 4;
        entry1_1->service_cmd     = 999;
        entry1_1->lac             = 25356;
        entry1_1->ci              = 91626509;
        entry1_1->rnode           = "1.1.1.1";
        entry1_1->lnode           = "1.1.1.1";
        entry1_1->request_type    = 0;
        entry1_1->url             = "www.baidu.com";
        if(!_session_queue.enqueue(entry1_1)){
            LOG_INFO(" 2== put entry1 error " +entry1_1->msisdn);
            safe_delete(entry1_1);
        }else{
            LOG_INFO(" 2== put entry1 ok " +entry1_1->msisdn);
        }
        #endif

        
        Poco::Thread::sleep(10000);
        // entry2
        IPDRXDRlog* entry2     = new IPDRXDRlog;
        entry2->btime           = 1509527558.790;
        entry2->msisdn          = "18805318929";
        entry2->imsi            = "460078541544023";
        entry2->imei            = "8622980363921378";
        entry2->private_ip      = "0.0.0.2";
        entry2->nat_ip          = "0.0.0.2";
        entry2->nat_port        = 43494;
        entry2->dest_ip         = "0.0.0.2";
        entry2->dest_port       = 53;
        entry2->protocol_type   = 4;
        entry2->service_cmd     = 999;
        entry2->lac             = 25356;
        entry2->ci              = 91626509;
        entry2->rnode           = "0.0.0.2";
        entry2->lnode           = "0.0.0.2";
        entry2->request_type    = 0;
        entry2->url             = "www.tencent.com";

        if (1 > cnt2){
            if(!_session_queue.enqueue(entry2)){
                LOG_INFO(" 1** put entry2 error " +entry2->msisdn);
                safe_delete(entry2);
            }else{
                LOG_INFO(" 1** put entry2 ok " +entry2->msisdn);
            }
        }else{
            safe_delete(entry2);
        }
        #if 0
        // entry2
        Poco::Thread::sleep(10000);
        IPDRXDRlog* entry2_1     = new IPDRXDRlog;
        entry2_1->btime           = 1509527558.790;
        entry2_1->msisdn          = "18805318929";
        entry2_1->imsi            = "460078541544023";
        entry2_1->imei            = "8622980363921378";
        entry2_1->private_ip      = "0.0.0.2";
        entry2_1->nat_ip          = "2.2.2.2";
        entry2_1->nat_port        = 43494;
        entry2_1->dest_ip         = "2.2.2.2";
        entry2_1->dest_port       = 53;
        entry2_1->protocol_type   = 4;
        entry2_1->service_cmd     = 999;
        entry2_1->lac             = 25356;
        entry2_1->ci              = 91626509;
        entry2_1->rnode           = "2.2.2.2";
        entry2_1->lnode           = "2.2.2.2";
        entry2_1->request_type    = 0;
        entry2_1->url             = "www.qq.com";
        if(!_session_queue.enqueue(entry2_1)){
            LOG_INFO(" 2** put entry2 error " +entry2_1->msisdn);
            safe_delete(entry2_1);
        }else{
            LOG_INFO(" 2** put entry2 ok " +entry2_1->msisdn);
        }
        #endif
    }
}

// Callback this function when the item in the online cache is ageing
bool online_callback(void *data, void *arg)
{
    uint32 line_version = app_config.getUInt(USER_ACCOUNT_LINE_VERSION, 1);

    if(line_version == 1)
    {
        if(data == NULL || arg == NULL)
    	{
    	    return false;
    	}
    	
    	SessionHandle *handle = (SessionHandle *)(arg);
    	return handle->online_ageing((IPDRXDRSession *)(data));
	}
}

// Callback this function when the item in the offline cache is ageing
bool offline_callback(void *data, void *arg)
{
    uint32 line_version = app_config.getUInt(USER_ACCOUNT_LINE_VERSION, 1);
    if(line_version == 1)
    {
        if(data == NULL || arg == NULL)
    	{
    	    return false;
    	}
    	SessionHandle *handle = (SessionHandle *)(arg);
    	return handle->offline_ageing((IPDRXDRSession *)(data));
	}
}

SessionHandle::SessionHandle(LoopQueue<IPDRMessage*>& queue, 
            LoopQueue<IPDRMessage*> &write_queue, uint16& isStop):
    _session_queue(queue),
	_write_queue(write_queue),
    _isStop(isStop)
{
    _online_cache = new ageing_map<std::string, IPDRXDRSession >(
        app_config.getUInt(LOGEN_ONLINE_CACHE_CAPACITY, 1000000), 
        app_config.getUInt(LOGEN_ONLINE_CACHE_CYCLE, 300), &online_callback, this);
        
    _offline_cache = new ageing_map<std::string, IPDRXDRSession >(
        app_config.getUInt(LOGEN_OFFLINE_CACHE_CAPACITY, 5000000), 
        app_config.getUInt(LOGEN_OFFLINE_CACHE_CYCLE, 3600), &offline_callback, this);

    _last_do_ageing = time(NULL);
	_incoming_msgs         = 0;
	_online_msgs           = 0;
	_online_discard_msgs   = 0;
	_offline_msgs          = 0;
	_offline_discard_msgs  = 0;
	_monitor_version       = monitor_version;
}

SessionHandle::~SessionHandle()
{
    safe_delete(_online_cache);
    safe_delete(_offline_cache);
}

void SessionHandle::update_session_cache(IPDRMessage* message)
{
	IPDRXDRSession *sess_entry = NULL;
    std::map<std::string, AccountMonitor *>::iterator it;
    std::string local_msisdn;

    if(line_version == 2)
    {
        IPDRXDRSession *ipdr_sess_entry = dynamic_cast<IPDRXDRSession*>(message);
        sess_entry = ipdr_sess_entry;
        std::string msisdn = sess_entry->msisdn;
        IPDRXDRSession *sess;
        _online_cache->destory(msisdn);
        if(sess_entry->online)
        {
            IPDRXDRSession *session_in = new IPDRXDRSession(*sess_entry);
    	    _online_cache->insert(msisdn, session_in);
    	}
    }

    if(_monitor_version != monitor_version)
    {
        //need update
        if(g_mutex.tryLock())
        {
            _monitor_conditon_map = monitor_terms;
            LOG_INFO(" <_monitor_conditon_map> update, size " +std::to_string(_monitor_conditon_map.size()));
            _monitor_version = monitor_version;
            g_mutex.unlock();
        }
        for(it = _monitor_conditon_map.begin(); it != _monitor_conditon_map.end(); ++it)
        {
            local_msisdn = it->first;
            LOG_INFO(" <_monitor_conditon_map> begin to search offline with account " +local_msisdn);
            
            IPDRXDRSession *offline_session_entry = NULL;

            if(line_version == 1)
            {
                //search _offline-queue
                if(_offline_cache->find(local_msisdn, offline_session_entry))
                {
                    AccountMonitor *accountMonitor =  it->second;
                    IPDRXDRSession *upload_entry = new IPDRXDRSession(*offline_session_entry);
                    ACCOUNTMonitorQueue::Instance.enqueue(upload_entry);
                    LOG_INFO(" find account at offline queque && enque :" +local_msisdn);
                    LOG_INFO(" find upload-msisdn : " +upload_entry->msisdn);
                }
            }
            else
            {
                if(_online_cache->find(local_msisdn, offline_session_entry, false))
                {
                    AccountMonitor *accountMonitor =  it->second;
                    IPDRXDRSession *upload_entry = new IPDRXDRSession(*offline_session_entry);
                    ACCOUNTMonitorQueue::Instance.enqueue(upload_entry);
                    LOG_INFO(" search on_line and find account && enque : " +local_msisdn);
                }
            }
        }
    
    }

    if(line_version == 1)
	{
        IPDRXDRlog     *ipdr_xdr_entry  = dynamic_cast<IPDRXDRlog*>(message);
        IPDRXDRSession *session_entry = NULL;
    	// first, look for the XDR in the offline cache.
    	if(_offline_cache->find(ipdr_xdr_entry->msisdn, session_entry, false))
    	{
	        if(ipdr_xdr_entry->msisdn == boce_tel)
    		{
    		    LOG_INFO(" jason offline==find old: " +session_entry->to_string(false));
                LOG_INFO(" jason offline==find new: " +ipdr_xdr_entry->to_string());
    		}
            
    		/* if lac/ci/pubip changed, create a on/off line msg*/
            if(session_entry->user_ip != ipdr_xdr_entry->private_ip||
                session_entry->lac != ipdr_xdr_entry->lac ||
                session_entry->ci != ipdr_xdr_entry->ci)
            {
                if(ipdr_xdr_entry->msisdn == boce_tel)
        		{
        		    LOG_INFO(" jason offline==diff, old : "+ session_entry->to_string(false));
        		    LOG_INFO(" jason offline==diff, new : " + ipdr_xdr_entry->to_string());
        		}
                _offline_cache->erase(ipdr_xdr_entry->msisdn);
                offline_ageing_ex(session_entry);
                if(_online_cache->find(ipdr_xdr_entry->msisdn, session_entry, false))
        	    {

        	        LOG_WARN(" jason  ?????? should not here, find in online_queue " + ipdr_xdr_entry->msisdn);
        	        _online_cache->destory(ipdr_xdr_entry->msisdn);
        	    }
    	        IPDRXDRSession * newline_session_entry = new IPDRXDRSession(*ipdr_xdr_entry);
    	        _online_cache->insert(ipdr_xdr_entry->msisdn, newline_session_entry);
    	        if(ipdr_xdr_entry->msisdn == boce_tel)
    	        {
    	            LOG_INFO(" jason from offline to online : ");
    	        }
            }
            else
            {
                if(ipdr_xdr_entry->msisdn == boce_tel)
        		{
        		    LOG_INFO(" jason offline reset_etime old: " + format_time(session_entry->etime));
        		    LOG_INFO(" jason offline reset_etime new: " + format_time(ipdr_xdr_entry->btime));
                }
                if(session_entry->etime < ipdr_xdr_entry->btime)
        		{
        		    session_entry->etime = ipdr_xdr_entry->btime;
        		    if(ipdr_xdr_entry->msisdn == boce_tel)
        		    {
        		        LOG_INFO(" jason offline reset_etime succ " +format_time(session_entry->etime));
        		    }
        		}

                _offline_cache->reset_timestamp(ipdr_xdr_entry->msisdn);
            }
    	}
    	
    	// If not found in the offline cache, and look for the XDR in the online cache.
    	else if(_online_cache->find(ipdr_xdr_entry->msisdn, session_entry, false))
    	{
	        if(ipdr_xdr_entry->msisdn == boce_tel)
    		{
    		    LOG_INFO(" jason online--find old: " +session_entry->to_string(true));
    		    LOG_INFO(" jason online--find new: " +ipdr_xdr_entry->to_string());
    		}
    	    
    		if(session_entry->user_ip != ipdr_xdr_entry->private_ip||
                session_entry->lac != ipdr_xdr_entry->lac ||
                session_entry->ci != ipdr_xdr_entry->ci)
            {
                if(ipdr_xdr_entry->msisdn == boce_tel)
        		{
        		    LOG_INFO(" jason online---diff old: "+ session_entry->to_string(true));
        		    
        		    LOG_INFO(" jason online---diff new: " + ipdr_xdr_entry->to_string());
        		}
                /* online old*/
                IPDRXDRSession * old_online = new IPDRXDRSession(*session_entry);
                online_ageing_ex(old_online);

                /* offline old*/
                _online_cache->erase(session_entry->msisdn);
                offline_ageing_ex(session_entry);

                /* new entry online */
                IPDRXDRSession * new_entry_online = new IPDRXDRSession(*ipdr_xdr_entry);
    	        _online_cache->insert(new_entry_online->msisdn, new_entry_online);
    	        if(ipdr_xdr_entry->msisdn == boce_tel)
    	        {
    	            LOG_INFO(" jason insert new to online : ");
    	        }

        	    
            }
            else
            {
            

                if(session_entry->btime > ipdr_xdr_entry->btime)
        		{
        		    if(ipdr_xdr_entry->msisdn == boce_tel)
                    {
                        LOG_INFO(" jason -- online reset_btime old: " + format_time(session_entry->btime));
                        LOG_INFO(" jason -- online reset_btime new: " + format_time(ipdr_xdr_entry->btime));
                    }
        		    session_entry->btime = ipdr_xdr_entry->btime;
        			//_online_cache->reset_ageing(ipdr_xdr_entry->msisdn);
        		}
        		
        		if(session_entry->etime < ipdr_xdr_entry->btime)
        		{
        		    if(ipdr_xdr_entry->msisdn == boce_tel)
                    {
                        LOG_INFO(" jason -- online reset_etime old: " + format_time(session_entry->etime));
                        LOG_INFO(" jason -- online reset_etime new: " + format_time(ipdr_xdr_entry->btime));
                    }
        		    session_entry->etime = ipdr_xdr_entry->btime; 
        		}
            }
    	}
    	else
    	{
    	    // New session.
    	    session_entry = new IPDRXDRSession(*ipdr_xdr_entry);
    		_online_cache->insert(ipdr_xdr_entry->msisdn, session_entry);
    		if(ipdr_xdr_entry->msisdn == boce_tel)
    		{
    		    LOG_INFO(" jason online---entry new_session" +ipdr_xdr_entry->to_string());
    		}
    	}
    	
    	time_t now = time(NULL);
    	if(now != _last_do_ageing)
    	{
    	    // do ageing every second.
            _online_cache->do_ageing(now);
    	    _offline_cache->do_ageing(now);
    		_last_do_ageing = now;
    		
    		if((now % 100) == 0)
    		{
    		    LOG_DEBUG("_incoming_msgs        = " + std::to_string(_incoming_msgs));
    			LOG_DEBUG("_online_msgs          = " + std::to_string(_online_msgs));
    			LOG_DEBUG("_online_discard_msgs  = " + std::to_string(_online_discard_msgs));
    			LOG_DEBUG("_offline_msgs         = " + std::to_string(_offline_msgs));
    			LOG_DEBUG("_offline_discard_msgs = " + std::to_string(_offline_discard_msgs));
    			LOG_DEBUG("_online_cache_size    = " + std::to_string(_online_cache->size()));
    			LOG_DEBUG("_offline_cache_size   = " + std::to_string(_offline_cache->size()));
    		}
    	}
    }
    else
    {
           // if monitor, filter every new msg 
        if(_monitor_conditon_map.size() > 0)
        {

            for(it = _monitor_conditon_map.begin(); it != _monitor_conditon_map.end(); ++it)
            {
                 local_msisdn = it->first;
                if(local_msisdn == sess_entry->msisdn)
                {
                    LOG_INFO(" this msg is which we want it: " +local_msisdn);
                    IPDRXDRSession *upload_entry = new IPDRXDRSession(*sess_entry);
                    ACCOUNTMonitorQueue::Instance.enqueue(upload_entry);
                    break;
                }
            }
        }
    }
}

bool SessionHandle::online_ageing(IPDRXDRSession *session)
{
    IPDRXDRSession *clone = new IPDRXDRSession(*session);
    clone->online = true;

    if(!_write_queue.enqueue(clone))
	{
	    LOG_WARN(" jason Enqueue online log " +clone->msisdn +"to the writing queue failed.");
	    safe_delete(clone);
		_online_discard_msgs++;
	}
	else
	{
        if(session->msisdn == boce_tel)
        {
            LOG_INFO(" jason online --- timeup " +session->to_string(true));
        }
	    _online_msgs++;
	}
	// online already

	tMonitorMap::iterator item = _monitor_conditon_map.find(session->msisdn);
    if(item != _monitor_conditon_map.end())
    {
        AccountMonitor *accountMonitor =  item->second;
   	    IPDRXDRSession *upload_entry = new IPDRXDRSession(*session);
        ACCOUNTMonitorQueue::Instance.enqueue(upload_entry);
        LOG_INFO(" deque online &&  enque monitor : " +session->msisdn);
	}
	
	IPDRXDRSession *old = NULL;
	if(_offline_cache->find(session->msisdn, old, false))
	{
	    // Found the log in the offline cache, and ignore this.
	    LOG_INFO(" jason !!! offline---find new_session" +session->to_string(true));
	    if(old->etime < session->etime)
	    {
	        old->etime = session->etime;
	    }
	    safe_delete(session);
	}
	else
	{
	    // Move the log from online cache to offline cache.
	    _offline_cache->insert(session->msisdn, session);
	    if(_offline_cache->find(session->msisdn, old, false))
	    {
    	    if(session->msisdn == boce_tel)
            {
    	        LOG_INFO(" jason  -------- Move to offline : " + std::to_string(_write_queue.pending()));
    	    } 
	    }
	}
	return true;
}

bool SessionHandle::offline_ageing(IPDRXDRSession *session)
{
    // Mark offline.
    session->online = false;
    if(!_write_queue.enqueue(session))
	{
	    LOG_WARN(" jason Enqueue offline log " +session->msisdn +" to the writing queue failed.");
	    safe_delete(session);
		_offline_discard_msgs++;
	}
	else
	{
	    if(session->msisdn == boce_tel)
        {
	        LOG_INFO(" jason offline === timeup : " + std::to_string(_write_queue.pending()) + " ===  " + session->to_string(false));
	    }
	    _offline_msgs++;
	}
	
	return true;
}

bool SessionHandle::offline_ageing_ex(IPDRXDRSession *session)
{
    // Mark offline.
    session->online = false;
    if(!_write_queue.enqueue(session))
	{
	    LOG_WARN(" jason Enqueue offline log " +session->msisdn +"to the writing queue failed.");
	    safe_delete(session);
		_offline_discard_msgs++;
	}
	else
	{
	    if(session->msisdn == boce_tel)
        {
	        LOG_INFO(" jason  === offline_ex enqueue wq :" + std::to_string(_write_queue.pending()) + " ===  " + session->to_string(false));
	    }
	    _offline_msgs++;
	}
	
	return true;
}


bool SessionHandle::online_ageing_ex(IPDRXDRSession *session)
{
    // Mark online.
    session->online = true;
    if(!_write_queue.enqueue(session))
	{
	    LOG_WARN("Enqueue offline log " +session->msisdn +"to the writing queue failed.");
		_online_discard_msgs++;
	}
	else
	{
		if(session->msisdn == boce_tel)
        {
	        LOG_INFO(" jason  --- online_ex enqueue wq :" + std::to_string(_write_queue.pending()) + " ===  " + session->to_string(true));
	    }
	    _online_msgs++;
	}
	
	return true;
}


void SessionHandle::run()
{

    while (!_isStop)
    {
	    IPDRMessage *message = NULL;
	    if (!_session_queue.try_dequeue(message))
        {
            Poco::Thread::sleep(10);
            continue;
        }
        
        switch (message->get_message_type())
        {
            case IPDR_XDR:
            case IPDR_SESSION:
            {  
                update_session_cache(message);
				_incoming_msgs++;
                break;
            }
            
            default:
            {
			    LOG_WARN("Receiving a log entry with unknown message type " + std::to_string(message->get_message_type()));
                break;
            }
        }
        
	    safe_delete(message);
    }
}

