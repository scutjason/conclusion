//
// Created by 10209409 on 3/22/2017.
//

#include <ipdrlogen/sftp_worker.hxx>
#include <ipdrlogen/queue.hxx>
#include <Poco/StringTokenizer.h>

#include <Poco/File.h>
#include <cub/os_utils.hxx>
#include <cub/string_utils.hxx>
#include "ipdrlogen/protocol.hxx"
#include <ipdrlogen/perform_stats.hxx>


using Poco::File;
using Poco::StringTokenizer;

LoopQueue<UploadInfo*> SFTPUploadQueue::Instance;
LoopQueue<IPDRMessage*> FILElistQueue::Instance;
std::vector<LoopQueue<IPDRMessage*> *> FILElistQueue::ins;

SFTPWorker::SFTPWorker(std::string& sftp_server,
                       std::string& sftp_port,
                       std::string& sftp_user,
                       std::string& sftp_password)
{
    _line_remote_path   = app_config.getString(UPLOAD_SFTP_LINE_PATH);
    _access_remote_path = app_config.getString(UPLOAD_SFTP_ACCESS_PATH);
    _nat_remote_path    = app_config.getString(UPLOAD_SFTP_NAT_PATH);
    _fl_remote_path     = app_config.getString(UPLOAD_SFTP_FILE_LIST_PATH);
    _kf_remote_path     = app_config.getString(UPLOAD_SFTP_KEYWORK_FILTER_PATH);
    _re_line_remote_path   = app_config.getString(REUPLOAD_SFTP_LINE_PATH);
    _re_access_remote_path = app_config.getString(REUPLOAD_SFTP_ACCESS_PATH);
    _re_nat_remote_path    = app_config.getString(REUPLOAD_SFTP_NAT_PATH);
    _re_fl_remote_path     = app_config.getString(REUPLOAD_SFTP_FILE_LIST_PATH);
    _re_kf_remote_path     = app_config.getString(REUPLOAD_SFTP_KEYWORK_FILTER_PATH);

    StringTokenizer server(sftp_server, ",");
    StringTokenizer port(sftp_port, ",");
    StringTokenizer user(sftp_user, ",");
    StringTokenizer password(sftp_password, ",");
    _sever_num = server.count();
    for(int i = 0; i < server.count(); i++)
    {
        SFTPClient *client = new SFTPClient(server[i], static_cast<uint16>(std::stoi(port[i])), user[i], password[i]);
        sftpClient.push_back(client);
    }

}

SFTPWorker::~SFTPWorker()
{
    for(int i; i < sftpClient.size(); i++)
    {
        if (sftpClient[i]->connected())
        {
            sftpClient[i]->close();
        }
        std::vector<SFTPClient *>::iterator it = sftpClient.begin()+i;
        sftpClient.erase(it);
    }
}

std::string SFTPWorker::get_remote_path(std::string type, uint8 srvNo, bool isReload)
{
    std::string remote_path;

    if(isReload){
        if("13" == type)
        {
            StringTokenizer path(_re_line_remote_path, ",");
            remote_path = path[srvNo];
        }
        else if("14" == type)
        {
            StringTokenizer path(_re_access_remote_path, ",");
            remote_path = path[srvNo];
        }
        else if("15" == type)
        {
            StringTokenizer path(_re_nat_remote_path, ",");
            remote_path = path[srvNo];
        }else if("16" == type)
        {
            StringTokenizer path(_re_kf_remote_path, ",");
            remote_path = path[srvNo];
        }else if("17" == type)
        {
            StringTokenizer path(_re_fl_remote_path, ",");
            remote_path = path[srvNo];
        }
    }else{
        if("13" == type)
        {
            StringTokenizer path(_line_remote_path, ",");
            remote_path = path[srvNo];
        }
        else if("14" == type)
        {
            StringTokenizer path(_access_remote_path, ",");
            remote_path = path[srvNo];
        }
        else if("15" == type)
        {
            StringTokenizer path(_nat_remote_path, ",");
            remote_path = path[srvNo];
        }else if("16" == type)
        {
            StringTokenizer path(_kf_remote_path, ",");
            remote_path = path[srvNo];
        }else if("17" == type)
        {
            StringTokenizer path(_fl_remote_path, ",");
            remote_path = path[srvNo];
        }
    }       
    return remote_path;
}

void SFTPWorker::run()
{
    UploadInfo* uploadInfo;
    bool result;
    std::string file_type;
    std::string file_size;
    while (true)
    {
        if (!SFTPUploadQueue::Instance.try_dequeue(uploadInfo))
        {
        
            Poco::Thread::sleep(10);
            continue;
        }
        
        IPDRFileList *ipdr_fl_entry = new IPDRFileList;
        Timestamp btimestamp;        
        LocalDateTime begin_time(btimestamp);
        std::string fileMd5 = uploadInfo->get_file_md5(); 
        std::string sftp_remote_path;
        ipdr_fl_entry->uploadStartTime = DateTimeFormatter::format(begin_time, NAME_DATE_FORMAT);
        std::string local_file_name =  cub::basename(uploadInfo->get_local_file());
        StringTokenizer fields(local_file_name, NAME_FILED_DELIMITER);
        ipdr_fl_entry->fileMd5 = fields[fields.count() - 2];
        
        uint64 count = static_cast<uint64>(std::stoi(fields[2]));
        uint8 serverNo = count%_sever_num;
        
        file_type = fields[0];
        if("re_transfer" == fileMd5){
            sftp_remote_path = get_remote_path(file_type, serverNo, true);
        }else{
            sftp_remote_path = get_remote_path(file_type, serverNo, false);
        }
        result = sftpClient[serverNo]->put(uploadInfo->get_local_file(),
                                sftp_remote_path,
                                true);
        
        if (result)
        {
            // upload succ , put it to filelistQueque
            ipdr_fl_entry->sftp_No = serverNo;
            ipdr_fl_entry->filename = local_file_name;
            Timestamp etimestamp;
            LocalDateTime end_time(etimestamp);
            ipdr_fl_entry->uploadEndTime = DateTimeFormatter::format(end_time, NAME_DATE_FORMAT);
            ipdr_fl_entry->fileNum = uploadInfo->get_file_num();
            
            
            std::string last_fields  = fields[fields.count() - 1];
            StringTokenizer size_fields(last_fields, ".");
            file_size = size_fields[0];
            //__interlocked_add_exchange64(&PerformStats::_sftp_ok_num, 1);
            //__interlocked_add_exchange64(&PerformStats::_sftp_all_bytes, std::stoi(file_size));
            //__interlocked_add_exchange64(&PerformStats::_sftp_all_cost, (etimestamp.epochMicroseconds()- btimestamp.epochMicroseconds())/1000000);
            if(!FILElistQueue::ins[serverNo]->enqueue(ipdr_fl_entry))
            {
                LOG_DEBUG("re_transter or Error enqueing ipdr_fl_entry to FILElistQueue"); 
                //fileMd5 = ipdr_fl_entry->fileMd5;
                safe_delete(ipdr_fl_entry);
            }
            
            std::string ok_path = uploadInfo->get_local_file();
            ok_path.append(OK_SUFFIX);
            File ok(ok_path);

            if (ok.createFile() || 
                "re_transfer" == fileMd5)
            {
                result = sftpClient[serverNo]->put(ok_path,
                                        sftp_remote_path,
                                        true);
            }

            if (!result)
            {
                //__interlocked_add_exchange64(&PerformStats::_sftp_err_num, 1);
                LOG_WARN("Uploading check ok file failed : " + ok_path);
            }
            safe_delete(uploadInfo);
        }
        else
        {
            //__interlocked_add_exchange64(&PerformStats::_sftp_err_num, 1);
            /* upload fail */
            if(!SFTPUploadQueue::Instance.enqueue(uploadInfo))
            {
                LOG_ERROR("Failed re_enqueing to SFTPUploadQueue"); 
                safe_delete(uploadInfo);
            }
            safe_delete(ipdr_fl_entry);
        }
    }
}
