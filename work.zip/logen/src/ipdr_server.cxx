#include <cub/os_utils.hxx>
#include <ipdrlogen/queue.hxx>
#include <ipdrlogen/ipdr_server.hxx>
#include <ipdrlogen/ipdr_server_handler.hxx>
#include <ipdrlogen/ipdr_interface_handler.hxx>
#include <ipdrlogen/file_writer.hxx>
#include <ipdrlogen/north_face.hxx>
#include <ipdrlogen/sftp_worker.hxx>
#include <ipdrlogen/perform_stats.hxx>

#include <Poco/StringTokenizer.h>
#include <Poco/SplitterChannel.h>
#include <Poco/FileChannel.h>
#include <Poco/Formatter.h>
#include <Poco/PatternFormatter.h>
#include <Poco/FormattingChannel.h>
#include <Poco/SimpleFileChannel.h>
#include <Poco/Util/IniFileConfiguration.h>
#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/SocketAcceptor.h>
#include <Poco/Net/ParallelSocketAcceptor.h>
#include <Poco/Net/HTTPServer.h>
#include <ipdrlogen/counter.hxx>
#include <signal.h>

using Poco::Channel;
using Poco::SplitterChannel;
using Poco::FileChannel;
using Poco::Formatter;
using Poco::PatternFormatter;
using Poco::FormattingChannel;
using Poco::SimpleFileChannel;
using Poco::Util::IniFileConfiguration;
using Poco::Message;
using Poco::Path;
using Poco::SystemException;
using Poco::Net::SocketAddress;
using Poco::Net::ServerSocket;
using Poco::Net::SocketAcceptor;
using Poco::Net::ParallelSocketAcceptor;
using Poco::Net::HTTPServer;
using Poco::Net::HTTPServerParams;
using Poco::Thread;
using Poco::ThreadPool;
using Poco::SharedPtr;
using Poco::StringTokenizer;

std::string appName("ipdrlogen");
std::string ACCOUNT_TYPE("2");

IPDRServer::IPDRServer()
{
}

IPDRServer::~IPDRServer()
{
}

void IPDRServer::initLogger()
{
    std::string  log_dir = config().getString(LOGGER);
    cub::mkdir(log_dir);
    AutoPtr<FileChannel> pChannel(new FileChannel);
    pChannel->setProperty(Poco::FileChannel::PROP_PATH,
                          log_dir + app_config.getString(APPLICATION) + LOG_FILE_EXT);
    pChannel->setProperty(Poco::FileChannel::PROP_ROTATION, "10 M");
    pChannel->setProperty(Poco::FileChannel::PROP_COMPRESS, "true");

    AutoPtr<Formatter> pformatter(new PatternFormatter(LOG_FORMAT));

    AutoPtr<Channel> formattingChannel(new FormattingChannel(pformatter,
                                       pChannel));

    Logger::root().setChannel(formattingChannel);

    Logger& logger = Logger::get(app_config.getString(
                                     APPLICATION)); // inherits root channel

    logger.setLevel(config().getString(COMMON_LOG_LEVEL, DEFAULT_LOG_LEVEL));
    logger.setChannel(formattingChannel);

    Application::setLogger(logger);
}

void IPDRServer::beDaemon()
{
    pid_t pid;

    if ((pid = fork()) < 0)
    {
        throw SystemException("cannot fork daemon process");
    }

    else if (pid != 0)
    {
        exit(0);
    }

    setsid();
    umask(027);

    // attach stdin, stdout, stderr to /dev/null instead of just closing them. This avoids
    // issues with third party/legacy code writing stuff to stdout/stderr.
    FILE* fin  = freopen("/dev/null", "r+", stdin);

    if (!fin)
    {
        throw Poco::OpenFileException("Cannot attach stdin to /dev/null");
    }

    std::string _stdout  = config().getString(LOGGER) + STDOUT;

    FILE* fout = freopen(_stdout.c_str(), "w+", stdout);

    if (!fout)
    {
        throw Poco::OpenFileException("Cannot attach stdout to /dev/null");
    }

    std::string _stderr  = config().getString(LOGGER) + STDERR;

    FILE* ferr = freopen(_stderr.c_str(), "w+", stderr);

    if (!ferr)
    {
        throw Poco::OpenFileException("Cannot attach stderr to /dev/null");
    }
}

void IPDRServer::loadConfiguration(int argc, char * argv[])
{
    Path exe(argv[0]);
    std::string basename = exe.getBaseName();
    std::string exe_path = cub::get_exec_path();
    Path confPath;

    confPath.assign( exe_path + CONFIG_DIR + basename + CONFIG_FILE_EXT);

    AutoPtr<IniFileConfiguration> pConf(new IniFileConfiguration(
                                            confPath.toString()));
    pConf->setString(APPLICATION, basename);

    uint32 log_entry_num = pConf->getUInt(LOGEN_FILE_ENTRY_NUM, LOG_ENTRY_NUM_MAX);

    if (log_entry_num > LOG_ENTRY_NUM_MAX)
    {
        log_entry_num = LOG_ENTRY_NUM_MAX;
    }

    pConf->setString(LOGGER, exe_path + LOG_DIR);

    pConf->setUInt(LOGEN_FILE_ENTRY_NUM, log_entry_num);

    config().add(pConf);
}

void IPDRServer::initialize(Application& self)
{
    beDaemon();
    initLogger();
    ServerApplication::initialize(self);
}

void IPDRServer::uninitialize()
{
    ServerApplication::uninitialize();
}

int IPDRServer::main(const std::vector<std::string>& args)
{
    // Step 1 : restore counter
    Counter::Instance().read_counter();

    // Step 2 : start up log generation server
    // get parameters from configuration file
    std::string logen_address = app_config.getString(LOGEN_SERVER_ADDRESS,
                                "0.0.0.0:1024");

    SocketAddress socketAddress(logen_address);

    // set-up a server socket
    ServerSocket logen_socket(socketAddress);

    // set-up a SocketReactor...
    SocketReactor reactor;

    // ... and a SocketAcceptor
    SocketAcceptor<IPDRServerHandler> acceptor(logen_socket, reactor);

    // run the reactor in its own thread so that we can wait for
    // a termination request
    Thread logen_thread;
    logen_thread.start(reactor);
    LOG_INFO("IPDR Logen server started at " +  logen_socket.address().toString());

    // Step 3: Start Interface Server
    std::string interface_address = app_config.getString(INTERFACE_SERVER_ADDRESS,
                                    DEFAULT_INTERFACE_SERVER_ADDRESS);

    // set-up a server socket
    SocketAddress address(interface_address);
    ServerSocket interface_socket(address);

    // set-up a HTTPServer instance
    HTTPServer httpServer(new IPDRInterfaceHandlerFactory, interface_socket,
                          new HTTPServerParams);

    // start the HTTPServer
    httpServer.start();

    LOG_INFO("HTTP Restful server started at http://" + interface_address);


    std::string sftp_server    = app_config.getString(UPLOAD_SFTP_SERVER);
    std::string sftp_port      = app_config.getString(UPLOAD_SFTP_PORT);
    std::string sftp_user      = app_config.getString(UPLOAD_SFTP_USER);
    std::string sftp_password  = app_config.getString(UPLOAD_SFTP_PASSWORD);

    Thread sftp_thread;
    SFTPWorker sftpWorker(sftp_server, sftp_port, sftp_user, sftp_password);

    sftp_thread.start(sftpWorker);

    LOG_INFO("SFTP upload thread started, tid = " + std::to_string(
                 sftp_thread.id()));

    // file list thread
    ThreadPool                      fl_thrd_pool;
    std::vector<FileWriter *>       fl_handles;
    uint32 switch_interval  = app_config.getUInt(LOGEN_FILE_LIST_UPLOAD_INTERVAL, 3600);
    std::string device_id = app_config.getString(LOGEN_FILE_DEVICE_ID,
                            DEFAULT_DEVICE_ID);         
    uint16 isStop = 0;
    uint16 type = IPDR_FILE_LIST;
    uint64 file_list_upload_num = 40000000; // a large num��that should not reached
    uint16 flag = 1;
    StringTokenizer server(sftp_server, ",");
    for(int i = 0; i < server.count(); i++)
    {
        LoopQueue<IPDRMessage*> *queque = new LoopQueue<IPDRMessage*>;
        FILElistQueue::ins.push_back(queque);
        
        FileWriter* fl_handle = new FileWriter(switch_interval, *FILElistQueue::ins[i], file_list_upload_num, device_id, isStop, type, flag, i);
        fl_handles.push_back(fl_handle);
    }
    
    for (auto worker : fl_handles)
    {
        fl_thrd_pool.start(*worker);
    }
    LOG_INFO("File list thread started " );
    
    // init counter
    for(int i = 0; i < server.count(); i++)
    {
        std::atomic<uint64> *counter_fl = new std::atomic<uint64>(server.count()-i);
        CounterFL::ins.push_back(counter_fl);
        
        std::atomic<uint64> *counter_kf = new std::atomic<uint64>(server.count()-i);
        CounterKF::ins.push_back(counter_kf);
    }
    CounterFL::num = server.count();
    CounterKF::num = server.count();
                 
    // accout monitor thread
    Thread monitor_thread;
    MoniorHandle monitor_worker(ACCOUNTMonitorQueue::Instance);

    monitor_thread.start(monitor_worker);

    LOG_INFO("accout monitor thread started, tid = " + std::to_string(
                 monitor_thread.id()));

    // keyword filter data_handle  thread
    
    Thread kf_dh_thread;
    FilterContext filter_context_worker(KEYWORDfilterContextQueue::Instance, server.count());

    kf_dh_thread.start(filter_context_worker);

    LOG_INFO("keyword filter data handle thread started, tid = " + std::to_string(
                 kf_dh_thread.id()));


    // keyword filter fw thread
    uint16 _isStop = 0;
    ThreadPool                         _filter_thread_pool;
    std::vector <FileWriter*>          _filter_workers;
    uint32 kf_switch_interval  = app_config.getUInt(LOGEN_FILTERFILE_SWITCH_INTERVAL, 15 * 60);
    
    uint32 kf_filter_entries   = app_config.getUInt(LOGEN_FILTERFILE_ENTRIES, 100);
    
    for(int i = 0; i < server.count(); i++)
    {
        uint16 type = IPDR_KEYWORD_FILTER;
        LoopQueue<IPDRMessage*> *queque = new LoopQueue<IPDRMessage*>;
        KEYWORDfilterFWQueue::ins.push_back(queque);
        
        FileWriter* kf_handle = new FileWriter(kf_switch_interval, *KEYWORDfilterFWQueue::ins[i], kf_filter_entries, device_id, _isStop, type, flag, i);
        _filter_workers.push_back(kf_handle);
    }
    
    for (auto worker : _filter_workers)
    {
        _filter_thread_pool.start(*worker);
    }
    LOG_INFO("keyword filter thread_pool started");

    #if 0
    // create stats timer
    PerformStats statsTimer; 
    uint32 timer_interval = 1000*300; /* 5 min*/
    Timer timer(0,  timer_interval);  
    timer.start(TimerCallback<PerformStats>(statsTimer, &PerformStats::onTimer));
    LOG_INFO("Perform Stats started");
    #endif
    
    Timestamp timestamp;
    LocalDateTime localDateTime(timestamp);

    LOG_INFO("IPDRlogen started at " + DateTimeFormatter::format(localDateTime,
             TIME_FORMAT));

    waitForTerminationRequest();

    LOG_INFO("Closing graceful");

    // Stop the SocketReactor
    reactor.stop();
    logen_thread.join();
    kf_dh_thread.join();
    monitor_thread.join();
    sftp_thread.join();
    fl_thrd_pool.joinAll();
    fl_thrd_pool.stopAll();
    
    _filter_thread_pool.joinAll();
    _filter_thread_pool.stopAll();

    // finally, store the counter
    Counter::Instance().write_counter();

    return Application::EXIT_OK;
}


