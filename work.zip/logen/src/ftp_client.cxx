//
// Created by 10209409 on 3/17/2017.
//

#include <fstream>
#include <sstream>
#include <cub/os_utils.hxx>
#include <Poco/StreamCopier.h>

#include <ipdrlogen/ftp_client.hxx>
#include <ipdrlogen/common.hxx>

using Poco::StreamCopier;

FTPClient::FTPClient(const std::string& remote,
                     const std::string& username,
                     const std::string& password) :
    _remote(remote),
    _port(FTP_PORT),
    _username(username),
    _password(password),
    ftpClientSession(nullptr)
{
}

FTPClient::FTPClient(const std::string& remote, uint16 port,
                     const std::string& username,
                     const std::string& password) :
    _remote(remote),
    _port(port),
    _username(username),
    _password(password),
    ftpClientSession(nullptr)
{
}

FTPClient::~FTPClient()
{
    close();
}

bool FTPClient::put(const std::string& local_path,
                    const std::string& remote_dir,
                    const std::string& remote_filename)
{
    std::stringstream remote;

    remote << remote_dir;

    if (remote_dir.at(remote_dir.length() - 1) != '/')
    {
        remote << '/';
    }

    remote << remote_filename;
    return put(local_path, remote.str());
}

bool FTPClient::put(const std::string& local_path,
                    const std::string& remote_path)
{
    if(!ftpClientSession)
    {
        ftpClientSession = new FTPClientSession(_remote, _port, _username, _password);
    }
    if (!ftpClientSession->isOpen() || !ftpClientSession->isLoggedIn())
    {
        try
        {
            ftpClientSession->open(_remote, _port, _username, _password);
            ftpClientSession->setPassive(false);
        }

        catch (Poco::Exception ex)
        {
            LOG_WARN(ex.displayText());
            return false;
        }
    }
    if (!ftpClientSession->isOpen())
    {
        LOG_WARN("Login to FTP " + to_string() + " failed.");
        close();
        return false;
    }
    
    std::string file_name        = cub::basename(local_path);
    std::string remote_directory = cub::dirname(remote_path);
    std::string remote_file      = cub::basename(remote_path);
    std::string remote_root;

    try
    {
        remote_root = ftpClientSession->getWorkingDirectory();
    }

    catch (Poco::Exception ex)
    {
        LOG_ERROR(ex.displayText());
        close();
        return false;
    }

    try
    {
        ftpClientSession->setWorkingDirectory(remote_directory);

        LOG_INFO("FTP uploading : " + local_path + " -> " + remote_path);
        std::ifstream in(local_path, std::ios::binary);

        std::ostream& stream = ftpClientSession->beginUpload(remote_file);
        stream << in.rdbuf();
        ftpClientSession->endUpload();
        in.close();

        ftpClientSession->setWorkingDirectory(remote_root);
        close();
        return true;
    }

    catch (Poco::Exception ex)
    {
        LOG_WARN(ex.displayText());
        close();
    }

    catch (...)
    {
        LOG_ERROR("Unknown error occurred when uploading");
        close();
    }
    return false;
}

bool FTPClient::get(const std::string& remote_path,
                    const std::string& local_path)
{
    if (!ftpClientSession->isOpen())
    {
        try
        {
            ftpClientSession->open(_remote, _port, _username, _password);
            ftpClientSession->setPassive(false);
        }

        catch (Poco::Exception ex)
        {
            LOG_WARN(ex.displayText());
            return false;
        }
    }

    if (!ftpClientSession->isOpen())
    {
        LOG_WARN("Login to FTP " + to_string() + " failed.");
        close();
        return false;
    }

    std::string remote_directory = cub::dirname(remote_path);
    std::string remote_file      = cub::basename(remote_path);
    std::string remote_root;

    try
    {
        remote_root = ftpClientSession->getWorkingDirectory();
    }

    catch (Poco::Exception ex)
    {
        LOG_ERROR(ex.displayText());
        close();
        return false;
    }

    try
    {
        ftpClientSession->setWorkingDirectory(remote_directory);

        LOG_DEBUG("FTP downloading : " + remote_path + " -> " + local_path);

        std::ofstream out(local_path, std::ios::binary);

        std::istream& stream = ftpClientSession->beginDownload(remote_file);
        StreamCopier::copyStream(stream, out);
        ftpClientSession->endDownload();

        out.close();
        ftpClientSession->setWorkingDirectory(remote_root);
        return  true;
    }

    catch (Poco::Exception ex)
    {
        LOG_WARN(ex.displayText());
        close();
    }

    return false;
}

void FTPClient::close()
{
    try
    {
        if(ftpClientSession)
        {
            ftpClientSession->close();
        }
    }
    
    catch (Poco::Exception ex)
    {
        LOG_WARN(ex.displayText());
    }

    catch (...)
    {
        LOG_ERROR("Unknown error occurred when closing FTPClient");
    }

    
    safe_delete(ftpClientSession);
}

std::string FTPClient::to_string()
{
    std::stringstream out;
    out << "{ ";
    out << "host : " << _remote   << ", ";
    out << "port : " <<  _port    << ", ";
    out << "user : " << _username;
    out << " }";
    return out.str();
}