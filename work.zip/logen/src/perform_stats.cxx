//
// Created by 10171618 on 4/14/2017.
//
#include <cub/os_utils.hxx>
#include <ipdrlogen/perform_stats.hxx>
#include <ipdrlogen/common.hxx>
#include <Poco/DigestStream.h>
#include <Poco/StreamCopier.h>
#include <Poco/FileStream.h>
#include <Poco/DateTimeFormatter.h>
#include <Poco/LocalDateTime.h>
#include <Poco/DateTimeFormatter.h>
#include <sstream>
#include <ipdrlogen/queue.hxx>
#include <iomanip>


#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <Poco/StringTokenizer.h>

using Poco::Timer;
using Poco::TimerCallback;
using Poco::DigestOutputStream;
using Poco::StreamCopier;
using Poco::FileStream;

using Poco::LocalDateTime;
using Poco::DateTime;

using Poco::DateTimeFormatter;

using Poco::StringTokenizer;



unsigned long PerformStats::_rx_xdr_bytes = 0;
unsigned long PerformStats::_rx_nat_bytes = 0;
unsigned long PerformStats::_rx_line_bytes = 0;

unsigned long PerformStats::_en_access_nums = 0;
unsigned long PerformStats::_en_nat_nums = 0;
unsigned long PerformStats::_en_line_nums = 0;

unsigned long PerformStats::_de_access_nums = 0;
unsigned long PerformStats::_de_nat_nums = 0;
unsigned long PerformStats::_de_line_nums = 0;

unsigned long PerformStats::_wq_access_nums = 0;
unsigned long PerformStats::_wq_nat_nums = 0;
unsigned long PerformStats::_wq_line_nums = 0;
unsigned long PerformStats::_wq_fl_nums = 0;
unsigned long PerformStats::_wq_kf_nums = 0;

unsigned long PerformStats::_fw_access_nums = 0;
unsigned long PerformStats::_fw_nat_nums = 0;
unsigned long PerformStats::_fw_line_nums = 0;
unsigned long PerformStats::_fw_fl_nums = 0;
unsigned long PerformStats::_fw_kf_nums = 0;

unsigned long PerformStats::_fw_access_bytes = 0;
unsigned long PerformStats::_fw_nat_bytes = 0;
unsigned long PerformStats::_fw_line_bytes = 0;

unsigned long PerformStats::_gz_access_bytes = 0;
unsigned long PerformStats::_gz_nat_bytes = 0;
unsigned long PerformStats::_gz_line_bytes = 0;
unsigned long PerformStats::_sftp_access_nums = 0;
unsigned long PerformStats::_sftp_nat_nums = 0;
unsigned long PerformStats::_sftp_line_nums = 0;
unsigned long PerformStats::_sftp_kf_nums = 0;
unsigned long PerformStats::_sftp_fl_nums = 0;

unsigned long PerformStats::_sftp_access_bytes = 0;
unsigned long PerformStats::_sftp_nat_bytes = 0;
unsigned long PerformStats::_sftp_line_bytes = 0;
unsigned long PerformStats::_sftp_kf_bytes = 0;
unsigned long PerformStats::_sftp_fl_bytes = 0;


unsigned long  PerformStats::_fw_ok_num = 0;
unsigned long  PerformStats::_fw_all_bytes = 0;
unsigned long  PerformStats::_fw_err_num = 0;

unsigned long  PerformStats::_sftp_ok_num = 0;
unsigned long  PerformStats::_sftp_err_num = 0;
unsigned long  PerformStats::_sftp_all_cost = 0;
unsigned long  PerformStats::_sftp_all_bytes = 0;
unsigned long  PerformStats::_sftp_conn_re = 0;


PerformStats::PerformStats():
    _file_name_time(0),
    _hasHead(0)
{

}

PerformStats::~PerformStats()
{
    
}

std::string PerformStats::inStringFormat()
{
    std::stringstream input;
    
    _ctl_time.update();
    LocalDateTime ctrl_time(_ctl_time);
    input << DateTimeFormatter::format(ctrl_time, DEFAULT_TIME_FORMAT);
    input << "\n\t";

    input << "rx_mb:    ";
    input << (PerformStats::_rx_xdr_bytes >> 20);
    input << "(xdr)  ";
    input << (PerformStats::_rx_nat_bytes >> 20);
    input << "(nat)  ";
    input << (PerformStats::_rx_line_bytes >> 20);
    input << "(line)\n\t";

    input << "eq_num:   ";
    input << PerformStats::_en_access_nums;
    input << "(xdr)  ";
    input << PerformStats::_en_nat_nums;
    input << "(nat)  ";
    input << PerformStats::_en_line_nums;
    input << "(line)\n\t";
    
    input << "dq_num:   ";
    input << PerformStats::_de_access_nums;
    input << "(xdr)  ";
    input << PerformStats::_de_nat_nums;
    input << "(nat)  ";
    input << PerformStats::_de_line_nums;
    input << "(line)\n\twq_num:   ";
    
    input << PerformStats::_wq_access_nums;
    input << "(xdr)  ";
    input << PerformStats::_wq_nat_nums;
    input << "(nat)  ";
    input << PerformStats::_wq_line_nums;
    input << "(line)  ";
    
    input << "\n\tfw_num:   ";
    input << PerformStats::_fw_access_nums;
    input << "(xdr)  ";
    input << PerformStats::_fw_nat_nums;
    input << "(nat)  ";
    input << PerformStats::_fw_line_nums;
    input << "(line)  ";
    #if 0
    input << "\n\tfw_mb:  ";
    input << PerformStats::_fw_access_bytes >> 20;
    input << "(xdr)  ";
    input << PerformStats::_fw_nat_bytes >> 20;
    input << "(nat)  ";
    input << PerformStats::_fw_line_bytes >> 20;
    input << "(line)  ";
    #endif
    input << "\n\tgz_mb:    ";
    input << (PerformStats::_gz_access_bytes >> 10);
    input << "(xdr)  ";
    input << (PerformStats::_gz_nat_bytes >> 10);
    input << "(nat)  ";
    input << (PerformStats::_gz_line_bytes >> 10);
    input << "(line)  ";
        
    input << "\n\tsftp_num: ";
    input << PerformStats::_sftp_access_nums;
    input << "(xdr)  ";
    input << PerformStats::_sftp_nat_nums;      
    input << "(nat)  ";
    input << PerformStats::_sftp_line_nums;
    input << "(line)  ";
    input << PerformStats::_sftp_kf_nums;      
    input << "(kf)  ";
    input << PerformStats::_sftp_fl_nums;
    input << "(fl)  ";

    input << "\n\tsftp_mb:  ";
    input << (PerformStats::_sftp_access_bytes >> 10);
    input << "(xdr)  ";
    input << (PerformStats::_sftp_nat_bytes >> 10);
    input << "(nat)  ";
    input << (PerformStats::_sftp_line_bytes >> 10);
    input << "(line)  ";
    input << (PerformStats::_sftp_kf_bytes >> 10);
    input << "(kf)  ";
    input << (PerformStats::_sftp_fl_bytes >> 10);
    input << "(fl)  ";
    input << "\n";
    return input.str();
}

std::string PerformStats::xdrInStringFormat()
{
    std::stringstream input;

    /* head */
    input << "collect_time\t";
    input << "duration\t";
    input << "hostname\t";
    input << "xdr_rc\t";
    input << "natlog_rc\t";
    input << "xdr_write\t";
    input << "natlog_write\t";
    input << "file_write\t";
    input << "file_write_size\t";
    input << "file_write_error\t";
    input << "file_send\t";
    input << "file_send_error\t";
    input << "file_trans_time\t";
    input << "file_trans_size\t";
    input << "sftp_conn\t\n";

    /* content */
    input << _kpi_time;
    input << "\t";
    input << "5";
    input << "\t";
    input << device_id;
    input << "\t";
    input << PerformStats::_en_access_nums;
    input << "\t";
    input << PerformStats::_en_nat_nums;
    input << "\t";
    input << PerformStats::_wq_access_nums;
    input << "\t";
    input << PerformStats::_wq_nat_nums;
    input << "\t";
    input << PerformStats::_fw_ok_num;
    input << "\t";
    input << PerformStats::_fw_all_bytes;
    input << "\t";
    input << PerformStats::_fw_err_num;
    input << "\t";
    input << PerformStats::_sftp_ok_num;
    input << "\t";
    input << PerformStats::_sftp_err_num;
    input << "\t";
    input << PerformStats::_sftp_all_cost;
    input << "\t";
    input << (PerformStats::_sftp_all_bytes >> 10);
    input << "\t";
    input << PerformStats::_sftp_conn_re;
    input << "\t\n";
    return input.str();
}

std::string PerformStats::fileInStringFormat()
{
    std::stringstream input;

    /* head */
    input << "collect_time\t";
    input << "duration\t";
    input << "hostname\t";
    input << "access_write\t";
    input << "access_send\t";
    input << "line_write\t";
    input << "line_send\t";
    input << "natlog_write\t";
    input << "natlog_send\t";
    input << "file_trans_time\t";
    input << "file_trans_size\t";

    /* content */
    input << _kpi_time;
    input << "\t";
    input << "5";
    input << "\t";
    input << device_id;
    input << "\t";
    input << PerformStats::_fw_access_nums;
    input << "\t";
    input << PerformStats::_sftp_access_nums;
    input << "\t";
    input << PerformStats::_fw_line_nums;
    input << "\t";
    input << PerformStats::_sftp_line_nums;
    input << "\t";
    input << PerformStats::_fw_nat_nums;
    input << "\t";
    input << PerformStats::_sftp_nat_nums;
    input << "\t";
    input << PerformStats::_sftp_all_cost;
    input << "\t";
    input << (PerformStats::_sftp_all_bytes >> 10);
    input << "\t\n"; 

    
    return input.str();
}

void PerformStats::clearIndexOfStars()
{
    PerformStats::_rx_xdr_bytes = 0;
    PerformStats::_rx_nat_bytes = 0;
    PerformStats::_rx_line_bytes = 0;
    
    PerformStats::_en_access_nums = 0;
    PerformStats::_en_nat_nums = 0;
    PerformStats::_en_line_nums = 0;
    
    PerformStats::_de_access_nums = 0;
    PerformStats::_de_nat_nums = 0;
    PerformStats::_de_line_nums = 0;
    
    PerformStats::_wq_access_nums = 0;
    PerformStats::_wq_nat_nums = 0;
    PerformStats::_wq_line_nums = 0;
    PerformStats::_wq_fl_nums = 0;
    PerformStats::_wq_kf_nums = 0;
    
    PerformStats::_fw_access_nums = 0;
    PerformStats::_fw_nat_nums = 0;
    PerformStats::_fw_line_nums = 0;
    PerformStats::_fw_fl_nums = 0;
    PerformStats::_fw_kf_nums = 0;

    PerformStats::_fw_access_bytes = 0;
    PerformStats::_fw_nat_bytes = 0;
    PerformStats::_fw_line_bytes = 0;

    PerformStats::_gz_access_bytes = 0;
    PerformStats::_gz_nat_bytes = 0;
    PerformStats::_gz_line_bytes = 0;
    
    PerformStats::_sftp_access_nums = 0;
    PerformStats::_sftp_nat_nums = 0;
    PerformStats::_sftp_line_nums = 0;
    PerformStats::_sftp_kf_nums = 0;
    PerformStats::_sftp_fl_nums = 0;

    PerformStats::_sftp_access_bytes = 0;
    PerformStats::_sftp_nat_bytes = 0;
    PerformStats::_sftp_line_bytes = 0; 
    PerformStats::_sftp_kf_bytes = 0;
    PerformStats::_sftp_fl_bytes = 0; 
    

    PerformStats::_fw_ok_num = 0;
    PerformStats::_fw_all_bytes = 0;
    PerformStats::_fw_err_num = 0;
    
    PerformStats::_sftp_ok_num = 0;
    PerformStats::_sftp_err_num = 0;
    PerformStats::_sftp_conn_re = 0;
    PerformStats::_sftp_all_bytes = 0;
    PerformStats::_sftp_all_cost = 0; 
}

void PerformStats::onTimer(Timer &timer)
{
    #if 0
    int handle;
    ssize_t ret;
    //  if xdr is exist
    if (!cub::directory_exists(XDR_ROOT_DIR))
    {
        return ;
    }
    // open file   xdr/stats_20170414
    std::stringstream path;
    _file_name_time.update();
    LocalDateTime file_name_time(_file_name_time);
    path << XDR_ROOT_DIR;
    path << STATS_FILE_HEAD;
    path << DateTimeFormatter::format(file_name_time, STATS_FILE_FORMAT);
    std::string file_path = path.str();

    if (!access(file_path.c_str(), 0))
    {
        //exist
        _hasHead = 1;
    }else
    {
        //not exist
        _hasHead = 0;
    }
    // open
    handle = open(file_path.c_str(), O_WRONLY | O_CREAT| O_APPEND, (S_IRUSR | S_IWUSR ));
    if (handle == -1)
    {
        LOG_ERROR("Can not open file " + file_path + ": " + strerror(errno));
        return ;
    }
    
    std::string input = inStringFormat();
    size_t  input_size = input.size();
    // write stats to file
    ret = write(handle, input.c_str(), input_size);
    if (ret != input_size)
    {
        LOG_ERROR("write returns error, excepted : " + std::to_string(
                      input_size) + ", actual : "
                  + std::to_string(ret));
        close(handle);
        return ;
    }

    // clear stats
    clearIndexOfStars();
    // close file
    close(handle);

    #else
    int handle;
    ssize_t ret;
    if (!cub::directory_exists(KPI_FILE_DIR))
    {
        cub::mkdir(KPI_FILE_DIR);
    }
    
    _file_name_time.update();
    LocalDateTime file_name_time(_file_name_time);
    _kpi_time = DateTimeFormatter::format(file_name_time, DEFAULT_TIME_FORMAT);
    StringTokenizer fields(_kpi_time, " ");
    StringTokenizer fields2(fields[1], ":");
    int min = std::stoi(fields2[1]);
    std::stringstream s_min;
    if((min % 5) != 0)
    {
        min -= min % 5;
    }
    s_min << std::setfill('0') << std::setw(2) << min;
    std::string time_suffex = fields2[0] + "_" + s_min.str();

    /* kpi */
    std::stringstream xdr_path;
    xdr_path << KPI_FILE_DIR;
    xdr_path << KPI_FILE_NAME;
    xdr_path << time_suffex;
    xdr_path << KPI_SUFFIX;
    std::string path = xdr_path.str();
    if (!access(path.c_str(), 0))
    {
        //exist
        LOG_ERROR(" collect file is exit ! ready to write ->" +xdrInStringFormat());
        return;
    }
    handle = open(path.c_str(), O_WRONLY | O_CREAT| O_APPEND, (S_IRUSR | S_IWUSR ));
    if (handle == -1)
    {
        LOG_ERROR("Can not open kpi xdr file " + path + ": " + strerror(errno));
        return ;
    }
    std::string input = xdrInStringFormat();
    size_t  input_size = input.size();
    ret = write(handle, input.c_str(), input_size);
    if (ret != input_size)
    {
        LOG_ERROR("write returns error, excepted : " + std::to_string(
                      input_size) + ", actual : "
                  + std::to_string(ret));
        close(handle);
        return ;
    }
    close(handle);
    
    clearIndexOfStars();
    #endif
    
    return ;

}

