//
// Created by 10209409 on 3/20/2017.
//

#include <iosfwd>
#include <fstream>
#include <memory>
#include <iostream>

#include <ipdrlogen/common.hxx>
#include <ipdrlogen/http_client.hxx>
#include <Poco/Net/HTTPRequest.h>
#include <Poco/Net/HTTPResponse.h>
#include <Poco/Net/HTTPStreamFactory.h>
#include <Poco/Net/FTPStreamFactory.h>
#include <Poco/URIStreamOpener.h>
#include <Poco/StreamCopier.h>

using Poco::Net::HTTPClientSession;
using Poco::Net::HTTPRequest;
using Poco::Net::HTTPResponse;
using Poco::Net::HTTPMessage;
using Poco::Net::HTTPStreamFactory;
using Poco::Net::FTPStreamFactory;
using Poco::URIStreamOpener;
using Poco::StreamCopier;
using Poco::Path;


HTTPClient::HTTPClient(): _reg(false)
{

}

HTTPClient::~HTTPClient()
{
}


bool HTTPClient::set_uri(const std::string &uri)
{
    try
    {
        URI new_uri(uri);
        _uri.swap(new_uri);
        _url.swap(const_cast<std::string&>(uri));
        return true;
    }

    catch (Poco::Exception ex)
    {
        LOG_WARN(ex.displayText());
    }

    return false;
}

#if 0
bool HTTPClient::post(std::string& local_path)
{
    Path path(local_path);
    bool result = false;

    if (path.isFile())
    {
        LOG_DEBUG("HTTP uploading : " + local_path + " -> " + _url);
        std::ifstream stream(local_path, std::ios::binary);
        result = post(stream);
        stream.close();
    }

    return result;
}
#endif


bool HTTPClient::post(std::string& in)
{
    std::string path(_uri.getPathAndQuery());

    if (path.empty())
    {
        path = "/";
    }

    HTTPRequest request(HTTPRequest::HTTP_POST, path, HTTPMessage::HTTP_1_1);
    HTTPClientSession session(_uri.getHost(), _uri.getPort());
    session.setKeepAlive(true);
    request.setKeepAlive(true);

    HTTPResponse response;

    try
    {
        request.setContentLength(in.length());
        request.setContentType("application/json");
        std::ostream &stream = session.sendRequest(request);

        stream << in;

        LOG_DEBUG("Sending data " + in + " to " + _url);

        stream.flush();

        std::istream &resp = session.receiveResponse(response);

        LOG_INFO("Response from server: status = " + std::to_string(
                     response.getStatus()) + ", reason = " + response.getReason());

        return (response.getStatus() == Poco::Net::HTTPResponse::HTTP_OK);
    }

    catch (std::exception ex)
    {
        LOG_ERROR(ex.what());
    }

    return false;
}


bool HTTPClient::get(const std::string &out_file)
{
    LOG_INFO("HTTP downloading : " + _url + " -> " + out_file);

    std::ofstream out(out_file, std::ios::binary);

    bool result = get(out);

    out.close();

    return result;
}


bool HTTPClient::get(std::ostream &out)
{
    if (!_reg)
    {
        try
        {
            HTTPStreamFactory::registerFactory();
            FTPStreamFactory::registerFactory();
            _reg = true;
        }

        catch (Poco::Exception ex)
        {
            LOG_DEBUG(ex.displayText());
        }
    }

    try
    {
        std::unique_ptr<std::istream> stream((URIStreamOpener::defaultOpener().open(
                _uri)));
        StreamCopier::copyStream(*stream.get(), out);
    }

    catch (Poco::Exception& ex)
    {
        LOG_ERROR(ex.displayText());
        return false;
    }

    return true;
}
