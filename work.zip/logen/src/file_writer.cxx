//
// Created by 10209409 on 3/20/2017.
//
#include <cub/os_utils.hxx>
#include <ipdrlogen/file_writer.hxx>
#include <ipdrlogen/ipdr_interface_handler.hxx>
#include <ipdrlogen/LoopQueue.h>
#include <ipdrlogen/counter.hxx>
#include <ipdrlogen/perform_stats.hxx>
#include <Poco/FileStream.h>
#include <Poco/MD5Engine.h>
#include <Poco/DigestStream.h>
#include <Poco/StreamCopier.h>
#include <Poco/File.h>
#include <iomanip>
#include <time.h>

using Poco::TimerCallback;
using namespace std::chrono;

using Poco::MD5Engine;
using Poco::DigestEngine;
using Poco::DigestOutputStream;
using Poco::FileInputStream;
using Poco::StreamCopier;
using Poco::File;

std::vector<std::atomic<uint64>*> CounterFL::ins;
uint8 CounterFL::num = 1;

std::vector<std::atomic<uint64>*> CounterKF::ins;
uint8 CounterKF::num = 1;

FileWriter::FileWriter(uint32 switch_interval,
                        LoopQueue<IPDRMessage*>&  queue,
                       uint32 max_entry_num,
                       std::string& device_id,
                       uint16& is_stop,
                       uint16 &log_type,
                       uint16& _is_create_file,
                       uint8 svrNo):
    _switch_time_up(switch_interval),
    _gz_stream(nullptr),
    _filter_version(0),
    _log_type(log_type),
    _max_entry_num(max_entry_num),
    _queue(queue),
    _entry_count(0),
    _device_id(device_id),
    _is_stop(is_stop),
    _name_delimiter(NAME_FILED_DELIMITER),
    _filter_start(false),
    _create_time(0),
    _close_time(0),
    _srvNo(svrNo),
    _is_gen_file(_is_create_file)
{
     //_remote_path = app_config.getString(UPLOAD_SFTP_PATH);
    //_timer.start(TimerCallback<FileWriter>(*this, &FileWriter::on_timer));
}

FileWriter::~FileWriter()
{
    switch_file(false);
}

void FileWriter::run()
{
    if (!cub::directory_exists(XDR_ROOT_DIR))
    {
        cub::mkdir(XDR_ROOT_DIR);
    }

    if (!_gz_stream)
    {
        switch_file();
    }
    
    IPDRMessage* ipdrMessage;
    time_t time_up; 
    bool flag;
    std::string task_id;
    while (!_is_stop)
    {

        if(_filter_version != filter_version)
        {
            if(g_filter_mutex.tryLock())
            {
                _msisdn_set = g_filter_msisdn;
                _msdn_vec = _msisdn_set.filter_items;
                _url_set =  g_filter_url;
                _url_vec = _url_set.filter_items;
                _filter_version = filter_version;
                g_filter_mutex.unlock();
            }
        }

        if(_is_gen_file)
        {
            time_up = time(NULL);
            if(time_up >= _create_time.epochMicroseconds()/1000000 + _switch_time_up)
            {
                switch_file();
                _entry_count = 0;
            }
        }
        
        if (!_queue.try_dequeue(ipdrMessage))
        {
            Poco::Thread::sleep(10);
            continue;
        }
        flag = 1;
        

        

        _log_type = ipdrMessage->get_message_type();
        switch (ipdrMessage->get_message_type())
        {
            case IPDR_XDR:
            {
                // search filter map
                if(_msdn_vec.size() > 0 && 
                    _msisdn_set.find_match(((IPDRXDRlog *)ipdrMessage)->msisdn, task_id))
                {
                    flag = 0;
                }else if(_url_vec.size() > 0 && 
                    _url_set.find_substring(((IPDRXDRlog *)ipdrMessage)->url, task_id))
                {
                    flag = 0;
                }
                
                if(!flag)
                {
                    tIpdrFilterContext *context = new tIpdrFilterContext;
                    context->ipdr_entry = ipdrMessage;
                    context->trace_type = IPDR_FILTER_TRACE_ACCESS;
                    context->taskId = task_id;
                    _filter_context.push_back(context);
                }
                
                ipdrMessage->write(_gz_stream);
				if(_entry_count % 1000 == 0)
                    _gz_stream->flush();
                _entry_count++;

                if (_entry_count >= _max_entry_num)
                {
                    switch_file();
                    _entry_count = 0;
                }
                //__interlocked_add_exchange64(&PerformStats::_wq_access_nums, 1);
                break;
            }
            case IPDR_NAT:
            {
                ipdrMessage->write(_gz_stream);
				if(_entry_count % 1000 == 0)
                    _gz_stream->flush();
                _entry_count++;

                if (_entry_count >= _max_entry_num)
                {
                    switch_file();
                    _entry_count = 0;
                }
                //__interlocked_add_exchange64(&PerformStats::_wq_nat_nums, 1);
                break;
            }

            case IPDR_SESSION:
            {
                if(_msdn_vec.size() > 0 && 
                        _msisdn_set.find_match(((IPDRXDRSession *)ipdrMessage)->msisdn, task_id))
                {
                    flag = 0;
                }
                if(_boce_flag != 1 && ((IPDRXDRSession *)ipdrMessage)->msisdn == boce_tel)
                {
                    _boce_flag = 1;
                }
                if(!flag)
                {
                    tIpdrFilterContext *context = new tIpdrFilterContext;
                    context->ipdr_entry = ipdrMessage;
                    context->trace_type = IPDR_FILTER_TRACE_LINE;
                    context->taskId = task_id;
                    _filter_context.push_back(context);
                }

                ipdrMessage->write(_gz_stream);
				if(_entry_count % 1000 == 0)
                    _gz_stream->flush();
                _entry_count++;

                if (_entry_count >= _max_entry_num)
                {
                    switch_file();
                    if(_boce_flag == 1)
                    {
                        LOG_INFO(" jason ===== write2file : " +_filename);
                    }
                    _boce_flag = 0;
                    _entry_count = 0;
                }
                //__interlocked_add_exchange64(&PerformStats::_wq_line_nums, 1);
                break;
            }
            
            case IPDR_FILE_LIST:
            {
                ipdrMessage->write(_gz_stream);
				if(_entry_count % 1000 == 0)
                    _gz_stream->flush();
                _entry_count++;

                if (_entry_count >= _max_entry_num)
                {
                    switch_file();
                    _entry_count = 0;
                }
                _serverNoFL = ((IPDRFileList *)ipdrMessage)->sftp_No;
                //__interlocked_add_exchange64(&PerformStats::_wq_fl_nums, 1);
                break;
            }
            
            case IPDR_KEYWORD_FILTER:
            {
                ipdrMessage->write(_gz_stream);
				if(_entry_count % 1000 == 0)
                    _gz_stream->flush();
                _entry_count++;

                if (_entry_count >= _max_entry_num)
                {
                    switch_file();
                    _entry_count = 0;
                }
                uint8 trace_type = ((IPDRKeywordFilter *)ipdrMessage)->trace_type;
                if(trace_type == IPDR_FILTER_TRACE_LINE)
                {
                    safe_delete(((IPDRKeywordFilter *)ipdrMessage)->ipdr_msg_line);
                }
                else if(trace_type == IPDR_FILTER_TRACE_ACCESS)
                {
                    safe_delete(((IPDRKeywordFilter *)ipdrMessage)->ipdr_msg_access);
                }
                 _serverNoFL = ((IPDRKeywordFilter *)ipdrMessage)->kf_server_No;
                //__interlocked_add_exchange64(&PerformStats::_wq_kf_nums, 1);
                break;
            }

            default:
            {
                LOG_WARN("Unknown log type : " + std::to_string(
                             ipdrMessage->get_message_type()));
                break;
            }
        }
        if(flag == 1)
        {
            safe_delete(ipdrMessage);
        }
    }
}

void FileWriter::on_timer(Timer &timer)
{
}

void FileWriter::switch_file(bool create)
{
    if (_gz_stream)
    {
        if(_entry_count == 0)
        {
            *_gz_stream << "\r";
            _gz_stream->flush();
        }
        
        _close_time.update();
        _gz_stream->flush();
        _gz_stream->close();
        safe_delete(_gz_stream);

        File gz_file(_path);

        if (gz_file.exists())
        {
            std::string gz_path = get_file_name();
            _filename = gz_path;
            gz_file.renameTo(gz_path);
            LOG_DEBUG("File created : " + gz_path);
            std::string trace_file_name;
            uint32  vec_size = _filter_context.size();

            int i = 0;
            tIpdrFilterContext * context;
            for(i = vec_size -1; i >= 0; i--)
            {
                context = _filter_context[i];
                trace_file_name = context->trace_file_name;
                if(trace_file_name.length() == 0)
                {
                    context->trace_file_name = cub::basename(gz_path);
                    context->count = _file_count;
                }
                else
                {
                    break;
                }
            }
            std::vector<tIpdrFilterContext*>::iterator it;
            for(it = _filter_context.begin(); it != _filter_context.end();)
            {
                if(!KEYWORDfilterContextQueue::Instance.enqueue(*it))
                {
                    LOG_ERROR("Error enqueing keyword_filter context to KEYWORDfilterContextQueue"); 
                     ++it;
                }
                else{
                    it = _filter_context.erase(it);
                }
            }
            
            UploadInfo* uploadInfo = new UploadInfo;
            uploadInfo->set_local_file(gz_path);
            uploadInfo->set_remote_path(_remote_path);
            std::string md5 = md5sum(_path);
            uploadInfo->set_file_md5(md5);
            uploadInfo->set_file_num(_entry_count);
            uploadInfo->_serverNo = _serverNoFL;
            if(!SFTPUploadQueue::Instance.enqueue(uploadInfo))
            {
                LOG_ERROR("Error enqueing ipdr_fl_entry to SFTPUploadQueue"); 
                safe_delete(uploadInfo);
            }
        }
    }

    _stream.close();

    if (create)
    {
        std::stringstream path;
        path << XDR_FILE_PREFIX;
        path << hex << std::this_thread::get_id();
        path << XDR_FILE_SUFFIX;

        _path = path.str();

        _stream.open(_path, std::ios::out | std::ios::app);
        _create_time.update();
        _gz_stream = new DeflatingOutputStream(_stream,
                                               DeflatingStreamBuf::STREAM_GZIP, 2);
    }
}

std::string FileWriter::get_file_name()
{
    std::stringstream name;
    name << XDR_ROOT_DIR;
    LocalDateTime close_time(_close_time);
    name << DateTimeFormatter::format(close_time, XDR_DIR_FORMAT);
    uint64 size = file_size(_path);
    cub::mkdir(name.str());

    switch (_log_type)
    {
        case IPDR_XDR:
        {
            name << SERVICE_TYPE_ACCESS_LOG;
            _remote_path = app_config.getString(UPLOAD_SFTP_ACCESS_PATH);
            _file_count = Counter::Instance().get();
            break;
        }
        case IPDR_SESSION:
        {
            name << SERVICE_TYPE_LINE_LOG;
            _remote_path = app_config.getString(UPLOAD_SFTP_LINE_PATH);
            _file_count = Counter::Instance().get();
            break;
        }
        case IPDR_NAT:
        {
            name << SERVICE_TYPE_NAT_LOG;
            _remote_path = app_config.getString(UPLOAD_SFTP_NAT_PATH);
            _file_count = Counter::Instance().get();
            break;
        }
        case IPDR_FILE_LIST:
        {
            name << SERVICE_TYPE_FILE_LIST_LOG;
            _remote_path = app_config.getString(UPLOAD_SFTP_FILE_LIST_PATH);
            CounterFL CntFl;
            _file_count = CntFl.get(CounterFL::ins[_srvNo], CounterFL::num - _srvNo);
            break;
        }
        case IPDR_KEYWORD_FILTER:
        {
            name << SERVICE_TYPE_KEYWORD_FILTER_LOG;
            _remote_path = app_config.getString(UPLOAD_SFTP_KEYWORK_FILTER_PATH); 
            CounterKF CntKF;
            _file_count = CntKF.get(CounterKF::ins[_srvNo], CounterKF::num - _srvNo);
            break;
        }
        default :
        {
            if(0 == PerformStats::_wq_access_nums)
            {
                name << SERVICE_TYPE_ACCESS_LOG;
                _file_count = Counter::Instance().get();
            }
            else
            {
                name << SERVICE_TYPE_NAT_LOG;
                _file_count = Counter::Instance().get();
            }
            break;
        }
    }
    //__interlocked_add_exchange64(&PerformStats::_fw_all_bytes, size);
    //__interlocked_add_exchange64(&PerformStats::_fw_ok_num, 1);
    name << _name_delimiter;
    name << _device_id ;
    name << _name_delimiter;
    name << std::setfill('0') << std::setw(COUNTER_WIDTH) << _file_count;
         
    name << _name_delimiter;
    LocalDateTime create_time(_create_time);
    name << DateTimeFormatter::format(create_time, NAME_DATE_FORMAT);
    name << _name_delimiter;
    name << DateTimeFormatter::format(close_time, NAME_DATE_FORMAT);
    name << _name_delimiter;
    name << _entry_count;
    name << _name_delimiter;
    name << md5sum(_path);
    name << _name_delimiter;
    name << size;
    name << XDR_FILE_SUFFIX;
    return name.str();
}

inline uint64 FileWriter::file_size(const std::string& path)
{
    File file(path);

    if (file.exists() && file.isFile())
    {
        return file.getSize() >> 10; /* file size in k */
    }

    return 0;
}

std::string FileWriter::md5sum(const std::string& path)
{
    FileStream  in(path, std::ios::binary);

    MD5Engine md5;
    Poco::DigestOutputStream digest_stream(md5);
    StreamCopier::copyStream(in, digest_stream);

    digest_stream.flush(); //to pass everything to the digest engine

    const DigestEngine::Digest& digest = md5.digest();
    std::string md5string = DigestEngine::digestToHex(digest);
    return md5string;
}
