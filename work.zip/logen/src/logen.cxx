//
// Created by 10209409 on 3/12/2017.
//

#include <ipdrlogen/ipdr_server.hxx>
#include <ipdrlogen/http_client.hxx>

int main(int argc, char * argv[])
{
    IPDRServer ipdrServer;
    ipdrServer.loadConfiguration(argc, argv);
    ipdrServer.run(argc, argv);
}

