//
// Created by 10209409 on 3/21/2017.
//
#include <cub/os_utils.hxx>
#include <ipdrlogen/interface_message.hxx>
#include <ipdrlogen/north_face.hxx>
#include <ipdrlogen/queue.hxx>
#include <ipdrlogen/common.hxx>

using Poco::Path;

LoopQueue<IFNotify*> IFQueryQueue::Instance;

NorthFace::NorthFace(const std::string& server,
                     uint16 port,
                     const std::string& user,
                     const std::string& password,
                     const std::string& remote_path):
    _remote_path(remote_path),
    ftpClient(server, port, user, password),
    sftpClient(server, port, user, password)
{
}

NorthFace::~NorthFace()
{
    if (sftpClient.connected())
    {
        sftpClient.close();
    }
}

void NorthFace::run()
{
    IFNotify* notify;
    bool result = true;
    std::string remote_path;

    if (!cub::directory_exists(LOCAL_TEMP))
    {
        cub::mkdir(LOCAL_TEMP);
    }

    while (true)
    {
        if (!IFQueryQueue::Instance.try_dequeue(notify))
        {
            Poco::Thread::sleep(10);
            continue;
        }
        try
        {
            remote_path.clear();

            if (!notify->get_zip_url().empty())
            {
                httpClient.set_uri(notify->get_zip_url());

                std::string filename  = cub::basename(httpClient.get_url());
                std::string file_path = LOCAL_TEMP + filename;

                result = httpClient.get(file_path);

                if (result)
                {
                    if(DEFAULT_NORTH_UPLOAD_PROTOCOL == upload_protocol)
                    {
                        result = sftpClient.put(file_path,
                                                _remote_path,
                                                true);
                        if (result)
                        {
                            remote_path.append(SFTP_URL_SCHEME);
                            remote_path.append(sftpClient.get_host());
                            uint16  sftp_port = sftpClient.get_port();
                            remote_path.append(":");
                            remote_path.append(std::to_string(sftp_port));
                            remote_path.append("/");
                            remote_path.append(_remote_path);
                            remote_path.append("/");
                            remote_path.append(filename);
                        }                       
                        else
                        {
                            LOG_WARN("SFTP : Uploading north query result file failed : ");
                        }
                    }
                    else
                    {
                        result = ftpClient.put(file_path, _remote_path, filename);
                        if (result)
                        {
                            remote_path.append(FTP_URL_SCHEME);
                            remote_path.append(ftpClient.get_host());
                            uint16  ftp_port = ftpClient.get_port();
                            remote_path.append(":");
                            remote_path.append(std::to_string(ftp_port));
                            remote_path.append("/");
                            remote_path.append(_remote_path);
                            remote_path.append("/");
                            remote_path.append(filename);
                        }
                        else
                        {
                            LOG_WARN("FTP : Uploading north query result file failed : ");
                        }
                    }
                }
            }

            httpClient.set_uri(notify->get_notify_url());

            send_notification(result, notify, remote_path);
        }

        catch (std::exception ex)
        {
            LOG_ERROR(ex.what());
        }
        safe_delete(notify);
    }
}

bool NorthFace::send_notification(bool success,
                                  IFNotify * notify,
                                  std::string& remote_path)
{
    std::stringstream result;
    result << "{" << endl;
    result << "    \"EventID\"      : \"" << notify->get_event_id() << "\"," <<
           endl;
    result << "    \"NotifyResult\" : " << (success ? 1 : 2) << "," << endl;
    result << "    \"FTPPath\"      : \"" << remote_path << "\"" <<
           endl;
    result << "}" << endl;

    std::string data = result.str();
    httpClient.post(data);
}

